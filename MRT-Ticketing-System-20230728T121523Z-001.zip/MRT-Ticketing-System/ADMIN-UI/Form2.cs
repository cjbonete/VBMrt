﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ADMIN_UI
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (txtID.Text == "123" && txtEmail.Text == "admin@gmail.com" && txtPass.Text == "123")
            {



                this.Hide();

                Form1 frm1 = new Form1();

                frm1.ShowDialog();

            }
            else {

                MessageBox.Show("Login Failed.");
            }
            
            
       
      
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

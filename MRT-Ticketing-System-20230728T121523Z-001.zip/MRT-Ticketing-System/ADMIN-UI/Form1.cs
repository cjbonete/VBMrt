﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ADMIN_UI
{
    public partial class Form1 : Form
    {

        private OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\khyrex\Desktop\MRT-Ticketing-System\MRTDB.accdb");
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = con;

                string query = "select * from MRT";
                cmd.CommandText = query;

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                con.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);
            }

        }

     

        private void button16_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = con;

                string query = "select * from MRT";
                cmd.CommandText = query;

                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                con.Close();


            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = con;

                string query = "delete from MRT where ID="+txtDelete.Text+"";
                cmd.CommandText = query;



                cmd.ExecuteNonQuery();
                MessageBox.Show("Data Deleted");
                con.Close();
                btnShowData.PerformClick();

            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int count = 0;

            count = 0;

            con.Open();
            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from MRT where ID=" + txtSearch.Text + "";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            da.Fill(dt);
            count = Convert.ToInt32(dt.Rows.Count.ToString());
            dataGridView1.DataSource = dt;
            con.Close();

            if (count == 0)
            {

                MessageBox.Show("none");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sum = 0;

            //for (int i = 0; i < dataGridView1.Rows.Count; i++)
            //{

            //    label1.Text = Convert.ToString(double.Parse(label1.Text) + double.Parse(dataGridView1.Rows[i].Cells[1].Value.ToString()));
            //}
            dataGridView1.AllowUserToAddRows = false;
            for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
            {

                sum = sum + int.Parse(dataGridView1.Rows[i].Cells[6].Value.ToString());
            }

            MessageBox.Show("The Total profit is "+sum.ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 logout = new Form2();
            logout.ShowDialog();
        }
    }
}

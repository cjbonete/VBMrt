﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void SELECT_Click(object sender, EventArgs e)
        {
            this.Hide();

            MRT7_NA NA = new MRT7_NA();

            NA.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();

            MRT7_QC QC = new MRT7_QC();

            QC.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();

            MRT7_UA UA = new MRT7_UA();

            UA.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();

            MRT7_TS TS = new MRT7_TS();

            TS.ShowDialog();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();

            MRT7_DA DA = new MRT7_DA();

            DA.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();

            MRT7_BT BT = new MRT7_BT();

            BT.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();

            MRT7_MG MG = new MRT7_MG();

            MG.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();

            MRT7_DC DC = new MRT7_DC();

            DC.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();

            MRT7_RG RG = new MRT7_RG();

            RG.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
             this.Hide();

            MRT7_MA MA = new MRT7_MA();

            MA.ShowDialog();
        }

        private void button13_Click(object sender, EventArgs e)
        {

            this.Hide();

            MRT7_QR QR = new MRT7_QR();

            QR.ShowDialog();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            MRT7_SH SH = new MRT7_SH();

            SH.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            this.Hide();

            MRT7_TL TL = new MRT7_TL();

            TL.ShowDialog();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            this.Hide();

            MRT7_SJ SJ = new MRT7_SJ();

            SJ.ShowDialog();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            about_us Au = new about_us();

            Au.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

            guide gd = new guide();

            gd.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();

            SCONTACT CU = new SCONTACT();

            CU.ShowDialog();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Main2 home = new Main2();

            home.ShowDialog();
        }
    }
}
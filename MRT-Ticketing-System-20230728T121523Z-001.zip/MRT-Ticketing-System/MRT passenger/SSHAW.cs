﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SSHAW : Form
    {
        public SSHAW()
        {
            InitializeComponent();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Shaw_Load(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb7_Ortigas.Checked == true && lblPrice.Text != "0.00")
            {

                string ShawToOrtigas, fromShawToOrtigas, TotalPrice;

                ShawToOrtigas = lbl7Ortigas.Text;
                fromShawToOrtigas = lbl_Shaw.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromShawToOrtigas(ShawToOrtigas.ToString());
                TF.fromShawToOrtigas2(fromShawToOrtigas.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb7_Santolan.Checked == true && lblPrice.Text != "0.00")
            {

                string ShawToSantolan, fromShawToSantolan, TotalPrice;

                ShawToSantolan = lbl7Santolan.Text;
                fromShawToSantolan = lbl_Shaw.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromShawToSantolan(ShawToSantolan.ToString());
                TF.fromShawToSantolan2(fromShawToSantolan.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb7_AranetaCubao.Checked == true && lblPrice.Text != "0.00")
            {

                string ShawToAraneta, fromShawToAraneta, TotalPrice;

                ShawToAraneta = lbl7AranetaCubao.Text;
                fromShawToAraneta = lbl_Shaw.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromShawToAraneta(ShawToAraneta.ToString());
                TF.fromShawToAraneta2(fromShawToAraneta.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb7_GMA.Checked == true && lblPrice.Text != "0.00")
            {

                string ShawToGMAKamuning, fromShawToGMAKamuning, TotalPrice;

                ShawToGMAKamuning = lbl7GMAKAMUNING.Text;
                fromShawToGMAKamuning = lbl_Shaw.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromShawToGMAKamuning(ShawToGMAKamuning.ToString());
                TF.fromShawToGMAKamuning2(fromShawToGMAKamuning.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb7_QuezonAve.Checked == true && lblPrice.Text != "0.00")
            {

                string ShawToQuezonAve, fromShawToQuezonAve, TotalPrice;

                ShawToQuezonAve = lbl7QuezonAve.Text;
                fromShawToQuezonAve = lbl_Shaw.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();

                TF.fromShawToQuezonAve(ShawToQuezonAve.ToString());
                TF.fromShawToQuezonAve2(fromShawToQuezonAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();
            }

            else if (rb7_NorthAve.Checked == true && lblPrice.Text != "0.00")
            {

                string ShawToNorthAve, fromShawToNorthAve, TotalPrice;

                ShawToNorthAve = lbl7NorthAve.Text;
                fromShawToNorthAve = lbl_Shaw.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromShawToNorthAve(ShawToNorthAve.ToString());
                TF.fromShawToNorthAve2(fromShawToNorthAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            
        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void rb7_Ortigas_CheckedChanged(object sender, EventArgs e)
        {
            if (rb7_Ortigas.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb7_Santolan_CheckedChanged(object sender, EventArgs e)
        {
            if (rb7_Santolan.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb7_AranetaCubao_CheckedChanged(object sender, EventArgs e)
        {
            if (rb7_AranetaCubao.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb7_GMA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb7_GMA.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb7_QuezonAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb7_QuezonAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb7_NorthAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb7_NorthAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }
    }
}

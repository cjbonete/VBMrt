﻿namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    partial class MRT7_MA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label5;
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblSJ = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.rb_TL = new System.Windows.Forms.RadioButton();
            this.lblTL = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblSH = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.rb_QR = new System.Windows.Forms.RadioButton();
            this.lblQR = new System.Windows.Forms.Label();
            this.rb_SH = new System.Windows.Forms.RadioButton();
            this.rb_SJ = new System.Windows.Forms.RadioButton();
            this.lbl_MA = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.lblPrice = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label2.Location = new System.Drawing.Point(741, 153);
            label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(351, 29);
            label2.TabIndex = 1;
            label2.Text = "SELECT YOUR DESTINATION";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label3.Location = new System.Drawing.Point(904, 373);
            label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(132, 29);
            label3.TabIndex = 3;
            label3.Text = "Ticket fare:";
            label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label5.Location = new System.Drawing.Point(249, 336);
            label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(219, 46);
            label5.TabIndex = 3;
            label5.Text = "STATIONS";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(29, 95);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1768, 191);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ITZeyyyyy_TRAIN_TICKET_SYSTEM.Properties.Resources.metro_station;
            this.pictureBox2.Location = new System.Drawing.Point(191, 42);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(257, 123);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(472, 63);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1037, 91);
            this.label1.TabIndex = 0;
            this.label1.Text = "MINDANAO AVE STATION";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblSJ);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.rb_TL);
            this.panel2.Controls.Add(this.lblTL);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.lblSH);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.rb_QR);
            this.panel2.Controls.Add(this.lblQR);
            this.panel2.Controls.Add(this.rb_SH);
            this.panel2.Controls.Add(this.rb_SJ);
            this.panel2.Controls.Add(this.lbl_MA);
            this.panel2.Location = new System.Drawing.Point(81, 373);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(587, 528);
            this.panel2.TabIndex = 2;
            // 
            // lblSJ
            // 
            this.lblSJ.AutoSize = true;
            this.lblSJ.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblSJ.Location = new System.Drawing.Point(231, 326);
            this.lblSJ.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSJ.Name = "lblSJ";
            this.lblSJ.Size = new System.Drawing.Size(113, 17);
            this.lblSJ.TabIndex = 36;
            this.lblSJ.Text = "SJDM BULACAN";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel5.Location = new System.Drawing.Point(405, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(181, 1);
            this.panel5.TabIndex = 12;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel3.Location = new System.Drawing.Point(585, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1, 492);
            this.panel3.TabIndex = 11;
            // 
            // rb_TL
            // 
            this.rb_TL.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_TL.AutoSize = true;
            this.rb_TL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_TL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_TL.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_TL.ForeColor = System.Drawing.Color.White;
            this.rb_TL.Location = new System.Drawing.Point(177, 271);
            this.rb_TL.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_TL.Name = "rb_TL";
            this.rb_TL.Padding = new System.Windows.Forms.Padding(64, 0, 64, 0);
            this.rb_TL.Size = new System.Drawing.Size(207, 43);
            this.rb_TL.TabIndex = 45;
            this.rb_TL.TabStop = true;
            this.rb_TL.Text = "Tala";
            this.rb_TL.UseVisualStyleBackColor = false;
            this.rb_TL.CheckedChanged += new System.EventHandler(this.rb_TL_CheckedChanged);
            // 
            // lblTL
            // 
            this.lblTL.AutoSize = true;
            this.lblTL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblTL.Location = new System.Drawing.Point(259, 255);
            this.lblTL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTL.Name = "lblTL";
            this.lblTL.Size = new System.Drawing.Size(43, 17);
            this.lblTL.TabIndex = 46;
            this.lblTL.Text = "TALA";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 492);
            this.panel4.TabIndex = 10;
            // 
            // lblSH
            // 
            this.lblSH.AutoSize = true;
            this.lblSH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblSH.Location = new System.Drawing.Point(227, 185);
            this.lblSH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSH.Name = "lblSH";
            this.lblSH.Size = new System.Drawing.Size(115, 17);
            this.lblSH.TabIndex = 34;
            this.lblSH.Text = "SACRED HEART";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel6.Location = new System.Drawing.Point(4, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(181, 1);
            this.panel6.TabIndex = 11;
            // 
            // rb_QR
            // 
            this.rb_QR.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_QR.AutoSize = true;
            this.rb_QR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_QR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_QR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_QR.ForeColor = System.Drawing.Color.White;
            this.rb_QR.Location = new System.Drawing.Point(177, 122);
            this.rb_QR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_QR.Name = "rb_QR";
            this.rb_QR.Padding = new System.Windows.Forms.Padding(47, 0, 45, 0);
            this.rb_QR.Size = new System.Drawing.Size(205, 43);
            this.rb_QR.TabIndex = 43;
            this.rb_QR.TabStop = true;
            this.rb_QR.Text = "Quirino";
            this.rb_QR.UseVisualStyleBackColor = false;
            this.rb_QR.CheckedChanged += new System.EventHandler(this.rb_QR_CheckedChanged);
            // 
            // lblQR
            // 
            this.lblQR.AutoSize = true;
            this.lblQR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblQR.Location = new System.Drawing.Point(245, 106);
            this.lblQR.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQR.Name = "lblQR";
            this.lblQR.Size = new System.Drawing.Size(66, 17);
            this.lblQR.TabIndex = 44;
            this.lblQR.Text = "QUIRINO";
            // 
            // rb_SH
            // 
            this.rb_SH.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_SH.AutoSize = true;
            this.rb_SH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_SH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_SH.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_SH.ForeColor = System.Drawing.Color.White;
            this.rb_SH.Location = new System.Drawing.Point(177, 201);
            this.rb_SH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_SH.Name = "rb_SH";
            this.rb_SH.Padding = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.rb_SH.Size = new System.Drawing.Size(202, 43);
            this.rb_SH.TabIndex = 33;
            this.rb_SH.TabStop = true;
            this.rb_SH.Text = "Sacred Heart";
            this.rb_SH.UseVisualStyleBackColor = false;
            this.rb_SH.CheckedChanged += new System.EventHandler(this.rb_SH_CheckedChanged);
            // 
            // rb_SJ
            // 
            this.rb_SJ.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_SJ.AutoSize = true;
            this.rb_SJ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_SJ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_SJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_SJ.ForeColor = System.Drawing.Color.White;
            this.rb_SJ.Location = new System.Drawing.Point(176, 352);
            this.rb_SJ.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_SJ.Name = "rb_SJ";
            this.rb_SJ.Size = new System.Drawing.Size(205, 43);
            this.rb_SJ.TabIndex = 35;
            this.rb_SJ.TabStop = true;
            this.rb_SJ.Text = "SJDM Bulacan";
            this.rb_SJ.UseVisualStyleBackColor = false;
            this.rb_SJ.CheckedChanged += new System.EventHandler(this.rb_SJ_CheckedChanged);
            // 
            // lbl_MA
            // 
            this.lbl_MA.AutoSize = true;
            this.lbl_MA.Location = new System.Drawing.Point(204, 367);
            this.lbl_MA.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_MA.Name = "lbl_MA";
            this.lbl_MA.Size = new System.Drawing.Size(158, 17);
            this.lbl_MA.TabIndex = 32;
            this.lbl_MA.Text = "MRT 7 MINDANAO AVE";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1117, 489);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 54);
            this.label4.TabIndex = 8;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(1489, 725);
            this.button14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(187, 41);
            this.button14.TabIndex = 9;
            this.button14.Text = "CASH";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(845, 540);
            this.lblPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(310, 139);
            this.lblPrice.TabIndex = 30;
            this.lblPrice.Text = "0.00";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(909, 820);
            this.button13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(187, 41);
            this.button13.TabIndex = 7;
            this.button13.Text = "BACK";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Window;
            this.button1.Location = new System.Drawing.Point(1489, 820);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(187, 41);
            this.button1.TabIndex = 31;
            this.button1.Text = "CARD";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MRT7_MA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1827, 890);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(label5);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.label4);
            this.Controls.Add(label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MRT7_MA";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "xfdxds";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.North_Ave_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lbl_MA;
        private System.Windows.Forms.Label lblTL;
        private System.Windows.Forms.RadioButton rb_TL;
        private System.Windows.Forms.Label lblSH;
        private System.Windows.Forms.Label lblQR;
        private System.Windows.Forms.RadioButton rb_SH;
        private System.Windows.Forms.RadioButton rb_QR;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblSJ;
        private System.Windows.Forms.RadioButton rb_SJ;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class lblTotal : Form
    {
        private OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\khyrex\Desktop\MRT-Ticketing-System\MRTDB.accdb");

        public lblTotal()
        {
            InitializeComponent();

        }

        private void GMA2_Load(object sender, EventArgs e)
        {
            timer.Start();

            int randomNum;

            Random random = new Random();
            randomNum = random.Next(999999, 10000000);

            lblRand.Text = ("" + randomNum);

        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (lbl_FromLocation.Text == "TAFT AVENUE")
            {
                this.Hide();
                STAFT tAFT = new STAFT();
                tAFT.ShowDialog();

            }


            else if (lbl_FromLocation.Text == "MAGALLANES")
            {
                this.Hide();
                SMAGALLANES magallanes = new SMAGALLANES();
                magallanes.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "AYALA")
            {
                this.Hide();
                SAYALA ayala = new SAYALA();
                ayala.ShowDialog();
            }

            else if (lbl_FromLocation.Text == "BUENDIA")
            {
                this.Hide();
                SBUENDIA buendia = new SBUENDIA();
                buendia.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "GUADALUPE")
            {
                this.Hide();
                SGUADA sg = new SGUADA();
                sg.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "BONI AVENUE")
            {
                this.Hide();
                SBONI sb = new SBONI();
                sb.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "SHAW BOULEVARD")
            {
                this.Hide();
                SSHAW ss = new SSHAW();
                ss.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "ORTIGAS")
            {
                this.Hide();
                SORTIGAS sort = new SORTIGAS();
                sort.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "SANTOLAN")
            {
                this.Hide();
                SSANTOLAN sant = new SSANTOLAN();
                sant.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "ARANETA CUBAO")
            {
                this.Hide();
                SARANETA sar = new SARANETA();
                sar.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "GMA KAMUNING")
            {
                this.Hide();
                SGMA sgma = new SGMA();
                sgma.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "QUEZON AVENUE")
            {
                this.Hide();
                SQUEZONAVE sqc = new SQUEZONAVE();
                sqc.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "NORTH AVENUE")
            {
                this.Hide();
                SNORTHAVE snorth = new SNORTHAVE();
                snorth.ShowDialog();
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lbl_Location_Click(object sender, EventArgs e)
        {

        }

        //TAFT AVENUE

        public void fromTaftToMagallanes(string fromTaftToMagallanes)
        {

            fromTaftToMagallanes.ToString();
            lbl_Location.Text = fromTaftToMagallanes.ToString();

        }

        public void fromTaftToMagallanes2(string fromTaftToMagallanes2)
        {

            fromTaftToMagallanes2.ToString();
            lbl_FromLocation.Text = fromTaftToMagallanes2.ToString();

        }

        public void fromTaftToAyala(string fromTaftToAyala)
        {

            fromTaftToAyala.ToString();
            lbl_Location.Text = fromTaftToAyala.ToString();

        }

        public void fromTaftToAyala2(string fromTaftToAyala2)
        {

            fromTaftToAyala2.ToString();
            lbl_FromLocation.Text = fromTaftToAyala2.ToString();

        }

        public void fromTaftToBuendia(string fromTaftToBuendia)
        {

            fromTaftToBuendia.ToString();
            lbl_Location.Text = fromTaftToBuendia.ToString();

        }

        public void fromTaftToBuendia2(string fromTaftToBuendia2)
        {

            fromTaftToBuendia2.ToString();
            lbl_FromLocation.Text = fromTaftToBuendia2.ToString();

        }

        public void fromTaftToGuadalupe(string fromTaftToGuadalupe)
        {

            fromTaftToGuadalupe.ToString();
            lbl_Location.Text = fromTaftToGuadalupe.ToString();

        }

        public void fromTaftToGuadalupe2(string fromTaftToGuadalupe2)
        {

            fromTaftToGuadalupe2.ToString();
            lbl_FromLocation.Text = fromTaftToGuadalupe2.ToString();

        }

        public void fromTaftToBoniAve(string fromTaftToBoniAve)
        {

            fromTaftToBoniAve.ToString();
            lbl_Location.Text = fromTaftToBoniAve.ToString();

        }

        public void fromTaftToBoniAve2(string fromTaftToBoniAve2)
        {

            fromTaftToBoniAve2.ToString();
            lbl_FromLocation.Text = fromTaftToBoniAve2.ToString();

        }

        public void fromTaftToShawBoulevard(string fromTaftToShawBoulevard)
        {

            fromTaftToShawBoulevard.ToString();
            lbl_Location.Text = fromTaftToShawBoulevard.ToString();

        }

        public void fromTaftToShawBoulevard2(string fromTaftToShawBoulevard2)
        {

            fromTaftToShawBoulevard2.ToString();
            lbl_FromLocation.Text = fromTaftToShawBoulevard2.ToString();

        }

        public void fromTaftToOrtigas(string fromTaftToOrtigas)
        {

            fromTaftToOrtigas.ToString();
            lbl_Location.Text = fromTaftToOrtigas.ToString();

        }

        public void fromTaftToOrtigas2(string fromTaftToOrtigas2)
        {

            fromTaftToOrtigas2.ToString();
            lbl_FromLocation.Text = fromTaftToOrtigas2.ToString();

        }

        public void fromTaftToSantolan(string fromTaftToSantolan)
        {

            fromTaftToSantolan.ToString();
            lbl_Location.Text = fromTaftToSantolan.ToString();

        }

        public void fromTaftToSantolan2(string fromTaftToSantolan2)
        {

            fromTaftToSantolan2.ToString();
            lbl_FromLocation.Text = fromTaftToSantolan2.ToString();

        }

        public void fromTaftToAraneta(string fromTaftToAraneta)
        {

            fromTaftToAraneta.ToString();
            lbl_Location.Text = fromTaftToAraneta.ToString();

        }

        public void fromTaftToAraneta2(string fromTaftToAraneta2)
        {

            fromTaftToAraneta2.ToString();
            lbl_FromLocation.Text = fromTaftToAraneta2.ToString();

        }

        public void fromTaftToGMAKamuning(string fromTaftToGMAKamuning)
        {

            fromTaftToGMAKamuning.ToString();
            lbl_Location.Text = fromTaftToGMAKamuning.ToString();

        }

        public void fromTaftToGMAKamuning2(string fromTaftToGMAKamuning2)
        {

            fromTaftToGMAKamuning2.ToString();
            lbl_FromLocation.Text = fromTaftToGMAKamuning2.ToString();

        }

        public void fromTaftToQuezonAve(string fromTaftToQuezonAve)
        {

            fromTaftToQuezonAve.ToString();
            lbl_Location.Text = fromTaftToQuezonAve.ToString();

        }

        public void fromTaftToQuezonAve2(string fromTaftToQuezonAve2)
        {

            fromTaftToQuezonAve2.ToString();
            lbl_FromLocation.Text = fromTaftToQuezonAve2.ToString();

        }

        public void fromTaftToNorthAve(string fromTaftToNorthAve)
        {

            fromTaftToNorthAve.ToString();
            lbl_Location.Text = fromTaftToNorthAve.ToString();

        }

        public void fromTaftToNorthAve2(string fromTaftToNorthAve2)
        {

            fromTaftToNorthAve2.ToString();
            lbl_FromLocation.Text = fromTaftToNorthAve2.ToString();

        }
        
        //MAGALLANES

        public void fromMagToAyala(string fromMagToAyala)
        {

            fromMagToAyala.ToString();
            lbl_Location.Text = fromMagToAyala.ToString();

        }

        public void fromMagToAyala2(string fromMagToAyala2)
        {

            fromMagToAyala2.ToString();
            lbl_FromLocation.Text = fromMagToAyala2.ToString();

        }

        public void fromMagToBuendia(string fromMagToBuendia)
        {

            fromMagToBuendia.ToString();
            lbl_Location.Text = fromMagToBuendia.ToString();

        }

        public void fromMagToBuendia2(string fromMagToBuendia2)
        {

            fromMagToBuendia2.ToString();
            lbl_FromLocation.Text = fromMagToBuendia2.ToString();

        }

        public void fromMagToGuadalupe(string fromMagToGuadalupe)
        {

            fromMagToGuadalupe.ToString();
            lbl_Location.Text = fromMagToGuadalupe.ToString();

        }

        public void fromMagToGuadalupe2(string fromMagToGuadalupe2)
        {

            fromMagToGuadalupe2.ToString();
            lbl_FromLocation.Text = fromMagToGuadalupe2.ToString();

        }

        public void fromMagToBoniAve(string fromMagToBoniAve)
        {

            fromMagToBoniAve.ToString();
            lbl_Location.Text = fromMagToBoniAve.ToString();

        }

        public void fromMagToBoniAve2(string fromMagToBoniAve2)
        {

            fromMagToBoniAve2.ToString();
            lbl_FromLocation.Text = fromMagToBoniAve2.ToString();

        }

        public void fromMagToShawBoulevard(string fromMagToShawBoulevard)
        {

            fromMagToShawBoulevard.ToString();
            lbl_Location.Text = fromMagToShawBoulevard.ToString();

        }

        public void fromMagToShawBoulevard2(string fromMagToShawBoulevard2)
        {

            fromMagToShawBoulevard2.ToString();
            lbl_FromLocation.Text = fromMagToShawBoulevard2.ToString();

        }

        public void fromMagToOrtigas(string fromMagToOrtigas)
        {

            fromMagToOrtigas.ToString();
            lbl_Location.Text = fromMagToOrtigas.ToString();

        }

        public void fromMagToOrtigas2(string fromMagToOrtigas2)
        {

            fromMagToOrtigas2.ToString();
            lbl_FromLocation.Text = fromMagToOrtigas2.ToString();

        }

        public void fromMagToSantolan(string fromMagToSantolan)
        {

            fromMagToSantolan.ToString();
            lbl_Location.Text = fromMagToSantolan.ToString();

        }

        public void fromMagToSantolan2(string fromMagToSantolan2)
        {

            fromMagToSantolan2.ToString();
            lbl_FromLocation.Text = fromMagToSantolan2.ToString();

        }

        public void fromMagToAraneta(string fromMagToAraneta)
        {

            fromMagToAraneta.ToString();
            lbl_Location.Text = fromMagToAraneta.ToString();

        }

        public void fromMagToAraneta2(string fromMagToAraneta2)
        {

            fromMagToAraneta2.ToString();
            lbl_FromLocation.Text = fromMagToAraneta2.ToString();

        }

        public void fromMagToGMAKamuning(string fromMagToGMAKamuning)
        {

            fromMagToGMAKamuning.ToString();
            lbl_Location.Text = fromMagToGMAKamuning.ToString();

        }

        public void fromMagToGMAKamuning2(string fromMagToGMAKamuning2)
        {

            fromMagToGMAKamuning2.ToString();
            lbl_FromLocation.Text = fromMagToGMAKamuning2.ToString();

        }

        public void fromMagToQuezonAve(string fromMagToQuezonAve)
        {

            fromMagToQuezonAve.ToString();
            lbl_Location.Text = fromMagToQuezonAve.ToString();

        }

        public void fromMagToQuezonAve2(string fromMagToQuezonAve2)
        {

            fromMagToQuezonAve2.ToString();
            lbl_FromLocation.Text = fromMagToQuezonAve2.ToString();

        }

        public void fromMagToNorthAve(string fromMagToNorthAve)
        {

            fromMagToNorthAve.ToString();
            lbl_Location.Text = fromMagToNorthAve.ToString();

        }

        public void fromMagToNorthAve2(string fromMagToNorthAve2)
        {

            fromMagToNorthAve2.ToString();
            lbl_FromLocation.Text = fromMagToNorthAve2.ToString();

        }

        //AYALA

        public void fromAyalaToBuendia(string fromAyalaToBuendia)
        {

            fromAyalaToBuendia.ToString();
            lbl_Location.Text = fromAyalaToBuendia.ToString();

        }

        public void fromAyalaToBuendia2(string fromAyalaToBuendia2)
        {

            fromAyalaToBuendia2.ToString();
            lbl_FromLocation.Text = fromAyalaToBuendia2.ToString();

        }

        public void fromAyalaToGuadalupe(string fromAyalaToGuadalupe)
        {

            fromAyalaToGuadalupe.ToString();
            lbl_Location.Text = fromAyalaToGuadalupe.ToString();

        }

        public void fromAyalaToGuadalupe2(string fromAyalaToGuadalupe2)
        {

            fromAyalaToGuadalupe2.ToString();
            lbl_FromLocation.Text = fromAyalaToGuadalupe2.ToString();

        }

        public void fromAyalaToBoniAve(string fromAyalaToBoniAve)
        {

            fromAyalaToBoniAve.ToString();
            lbl_Location.Text = fromAyalaToBoniAve.ToString();

        }

        public void fromAyalaToBoniAve2(string fromAyalaToBoniAve2)
        {

            fromAyalaToBoniAve2.ToString();
            lbl_FromLocation.Text = fromAyalaToBoniAve2.ToString();

        }

        public void fromAyalaToShawBoulevard(string fromAyalaToShawBoulevard)
        {

            fromAyalaToShawBoulevard.ToString();
            lbl_Location.Text = fromAyalaToShawBoulevard.ToString();

        }

        public void fromAyalaToShawBoulevard2(string fromAyalaToShawBoulevard2)
        {

            fromAyalaToShawBoulevard2.ToString();
            lbl_FromLocation.Text = fromAyalaToShawBoulevard2.ToString();

        }

        public void fromAyalaToOrtigas(string fromAyalaToOrtigas)
        {

            fromAyalaToOrtigas.ToString();
            lbl_Location.Text = fromAyalaToOrtigas.ToString();

        }

        public void fromAyalaToOrtigas2(string fromAyalaToOrtigas2)
        {

            fromAyalaToOrtigas2.ToString();
            lbl_FromLocation.Text = fromAyalaToOrtigas2.ToString();

        }

        public void fromAyalaToSantolan(string fromAyalaToSantolan)
        {

            fromAyalaToSantolan.ToString();
            lbl_Location.Text = fromAyalaToSantolan.ToString();

        }

        public void fromAyalaToSantolan2(string fromAyalaToSantolan2)
        {

            fromAyalaToSantolan2.ToString();
            lbl_FromLocation.Text = fromAyalaToSantolan2.ToString();

        }

        public void fromAyalaToAraneta(string fromAyalaToAraneta)
        {

            fromAyalaToAraneta.ToString();
            lbl_Location.Text = fromAyalaToAraneta.ToString();

        }

        public void fromAyalaToAraneta2(string fromAyalaToAraneta2)
        {

            fromAyalaToAraneta2.ToString();
            lbl_FromLocation.Text = fromAyalaToAraneta2.ToString();

        }

        public void fromAyalaToGMAKamuning(string fromAyalaToGMAKamuning)
        {

            fromAyalaToGMAKamuning.ToString();
            lbl_Location.Text = fromAyalaToGMAKamuning.ToString();

        }

        public void fromAyalaToGMAKamuning2(string fromAyalaToGMAKamuning2)
        {

            fromAyalaToGMAKamuning2.ToString();
            lbl_FromLocation.Text = fromAyalaToGMAKamuning2.ToString();

        }

        public void fromAyalaToQuezonAve(string fromAyalaToQuezonAve)
        {

            fromAyalaToQuezonAve.ToString();
            lbl_Location.Text = fromAyalaToQuezonAve.ToString();

        }

        public void fromAyalaToQuezonAve2(string fromAyalaToQuezonAve2)
        {

            fromAyalaToQuezonAve2.ToString();
            lbl_FromLocation.Text = fromAyalaToQuezonAve2.ToString();

        }

        public void fromAyalaToNorthAve(string fromAyalaToNorthAve)
        {

            fromAyalaToNorthAve.ToString();
            lbl_Location.Text = fromAyalaToNorthAve.ToString();

        }

        public void fromAyalaToNorthAve2(string fromAyalaToNorthAve2)
        {

            fromAyalaToNorthAve2.ToString();
            lbl_FromLocation.Text = fromAyalaToNorthAve2.ToString();

        }
        
        //BUENDIA

        public void fromBuendiaToGuadalupe(string fromBuendiaToGuadalupe)
        {

            fromBuendiaToGuadalupe.ToString();
            lbl_Location.Text = fromBuendiaToGuadalupe.ToString();

        }

        public void fromBuendiaToGuadalupe2(string fromBuendiaToGuadalupe2)
        {

            fromBuendiaToGuadalupe2.ToString();
            lbl_FromLocation.Text = fromBuendiaToGuadalupe2.ToString();

        }

        public void fromBuendiaToBoniAve(string fromBuendiaToBoniAve)
        {

            fromBuendiaToBoniAve.ToString();
            lbl_Location.Text = fromBuendiaToBoniAve.ToString();

        }

        public void fromBuendiaToBoniAve2(string fromBuendiaToBoniAve2)
        {

            fromBuendiaToBoniAve2.ToString();
            lbl_FromLocation.Text = fromBuendiaToBoniAve2.ToString();

        }

        public void fromBuendiaToShawBoulevard(string fromBuendiaToShawBoulevard)
        {

            fromBuendiaToShawBoulevard.ToString();
            lbl_Location.Text = fromBuendiaToShawBoulevard.ToString();

        }

        public void fromBuendiaToShawBoulevard2(string fromBuendiaToShawBoulevard2)
        {

            fromBuendiaToShawBoulevard2.ToString();
            lbl_FromLocation.Text = fromBuendiaToShawBoulevard2.ToString();

        }

        public void fromBuendiaToOrtigas(string fromBuendiaToOrtigas)
        {

            fromBuendiaToOrtigas.ToString();
            lbl_Location.Text = fromBuendiaToOrtigas.ToString();

        }

        public void fromBuendiaToOrtigas2(string fromBuendiaToOrtigas2)
        {

            fromBuendiaToOrtigas2.ToString();
            lbl_FromLocation.Text = fromBuendiaToOrtigas2.ToString();

        }

        public void fromBuendiaToSantolan(string fromBuendiaToSantolan)
        {

            fromBuendiaToSantolan.ToString();
            lbl_Location.Text = fromBuendiaToSantolan.ToString();

        }

        public void fromBuendiaToSantolan2(string fromBuendiaToSantolan2)
        {

            fromBuendiaToSantolan2.ToString();
            lbl_FromLocation.Text = fromBuendiaToSantolan2.ToString();

        }

        public void fromBuendiaToAraneta(string fromBuendiaToAraneta)
        {

            fromBuendiaToAraneta.ToString();
            lbl_Location.Text = fromBuendiaToAraneta.ToString();

        }

        public void fromBuendiaToAraneta2(string fromBuendiaToAraneta2)
        {

            fromBuendiaToAraneta2.ToString();
            lbl_FromLocation.Text = fromBuendiaToAraneta2.ToString();

        }

        public void fromBuendiaToGMAKamuning(string fromBuendiaToGMAKamuning)
        {

            fromBuendiaToGMAKamuning.ToString();
            lbl_Location.Text = fromBuendiaToGMAKamuning.ToString();

        }

        public void fromBuendiaToGMAKamuning2(string fromBuendiaToGMAKamuning2)
        {

            fromBuendiaToGMAKamuning2.ToString();
            lbl_FromLocation.Text = fromBuendiaToGMAKamuning2.ToString();

        }

        public void fromBuendiaToQuezonAve(string fromBuendiaToQuezonAve)
        {

            fromBuendiaToQuezonAve.ToString();
            lbl_Location.Text = fromBuendiaToQuezonAve.ToString();

        }

        public void fromBuendiaToQuezonAve2(string fromBuendiaToQuezonAve2)
        {

            fromBuendiaToQuezonAve2.ToString();
            lbl_FromLocation.Text = fromBuendiaToQuezonAve2.ToString();

        }

        public void fromBuendiaToNorthAve(string fromBuendiaToNorthAve)
        {

            fromBuendiaToNorthAve.ToString();
            lbl_Location.Text = fromBuendiaToNorthAve.ToString();

        }

        public void fromBuendiaToNorthAve2(string fromBuendiaToNorthAve2)
        {

            fromBuendiaToNorthAve2.ToString();
            lbl_FromLocation.Text = fromBuendiaToNorthAve2.ToString();

        }


        //GUADALUPE

        public void fromGuadaToBoniAve(string fromGuadaToBoniAve)
        {

            fromGuadaToBoniAve.ToString();
            lbl_Location.Text = fromGuadaToBoniAve.ToString();

        }

        public void fromGuadaToBoniAve2(string fromGuadaToBoniAve2)
        {

            fromGuadaToBoniAve2.ToString();
            lbl_FromLocation.Text = fromGuadaToBoniAve2.ToString();

        }

        public void fromGuadaToShawBoulevard(string fromGuadaToShawBoulevard)
        {

            fromGuadaToShawBoulevard.ToString();
            lbl_Location.Text = fromGuadaToShawBoulevard.ToString();

        }

        public void fromGuadaToShawBoulevard2(string fromGuadaToShawBoulevard2)
        {

            fromGuadaToShawBoulevard2.ToString();
            lbl_FromLocation.Text = fromGuadaToShawBoulevard2.ToString();

        }

        public void fromGuadaToOrtigas(string fromGuadaToOrtigas)
        {

            fromGuadaToOrtigas.ToString();
            lbl_Location.Text = fromGuadaToOrtigas.ToString();

        }

        public void fromGuadaToOrtigas2(string fromGuadaToOrtigas2)
        {

            fromGuadaToOrtigas2.ToString();
            lbl_FromLocation.Text = fromGuadaToOrtigas2.ToString();

        }

        public void fromGuadaToSantolan(string fromGuadaToSantolan)
        {

            fromGuadaToSantolan.ToString();
            lbl_Location.Text = fromGuadaToSantolan.ToString();

        }

        public void fromGuadaToSantolan2(string fromGuadaToSantolan2)
        {

            fromGuadaToSantolan2.ToString();
            lbl_FromLocation.Text = fromGuadaToSantolan2.ToString();

        }

        public void fromGuadaToAraneta(string fromGuadaToAraneta)
        {

            fromGuadaToAraneta.ToString();
            lbl_Location.Text = fromGuadaToAraneta.ToString();

        }

        public void fromGuadaToAraneta2(string fromGuadaToAraneta2)
        {

            fromGuadaToAraneta2.ToString();
            lbl_FromLocation.Text = fromGuadaToAraneta2.ToString();

        }

        public void fromGuadaToGMAKamuning(string fromGuadaToGMAKamuning)
        {

            fromGuadaToGMAKamuning.ToString();
            lbl_Location.Text = fromGuadaToGMAKamuning.ToString();

        }

        public void fromGuadaToGMAKamuning2(string fromGuadaToGMAKamuning2)
        {

            fromGuadaToGMAKamuning2.ToString();
            lbl_FromLocation.Text = fromGuadaToGMAKamuning2.ToString();

        }

        public void fromGuadaToQuezonAve(string fromGuadaToQuezonAve)
        {

            fromGuadaToQuezonAve.ToString();
            lbl_Location.Text = fromGuadaToQuezonAve.ToString();

        }

        public void fromGuadaToQuezonAve2(string fromGuadaToQuezonAve2)
        {

            fromGuadaToQuezonAve2.ToString();
            lbl_FromLocation.Text = fromGuadaToQuezonAve2.ToString();

        }

        public void fromGuadaToNorthAve(string fromGuadaToNorthAve)
        {

            fromGuadaToNorthAve.ToString();
            lbl_Location.Text = fromGuadaToNorthAve.ToString();

        }

        public void fromGuadaToNorthAve2(string fromGuadaToNorthAve2)
        {

            fromGuadaToNorthAve2.ToString();
            lbl_FromLocation.Text = fromGuadaToNorthAve2.ToString();

        }

        //BONI AVENUE

        public void fromBoniToShawBoulevard(string fromBoniToShawBoulevard)
        {

            fromBoniToShawBoulevard.ToString();
            lbl_Location.Text = fromBoniToShawBoulevard.ToString();

        }

        public void fromBoniToShawBoulevard2(string fromBoniToShawBoulevard2)
        {

            fromBoniToShawBoulevard2.ToString();
            lbl_FromLocation.Text = fromBoniToShawBoulevard2.ToString();

        }

        public void fromBoniToOrtigas(string fromBoniToOrtigas)
        {

            fromBoniToOrtigas.ToString();
            lbl_Location.Text = fromBoniToOrtigas.ToString();

        }

        public void fromBoniToOrtigas2(string fromBoniToOrtigas2)
        {

            fromBoniToOrtigas2.ToString();
            lbl_FromLocation.Text = fromBoniToOrtigas2.ToString();

        }

        public void fromBoniToSantolan(string fromBoniToSantolan)
        {

            fromBoniToSantolan.ToString();
            lbl_Location.Text = fromBoniToSantolan.ToString();

        }

        public void fromBoniToSantolan2(string fromBoniToSantolan2)
        {

            fromBoniToSantolan2.ToString();
            lbl_FromLocation.Text = fromBoniToSantolan2.ToString();

        }

        public void fromBoniToAraneta(string fromBoniToAraneta)
        {

            fromBoniToAraneta.ToString();
            lbl_Location.Text = fromBoniToAraneta.ToString();

        }

        public void fromBoniToAraneta2(string fromBoniToAraneta2)
        {

            fromBoniToAraneta2.ToString();
            lbl_FromLocation.Text = fromBoniToAraneta2.ToString();

        }

        public void fromBoniToGMAKamuning(string fromBoniToGMAKamuning)
        {

            fromBoniToGMAKamuning.ToString();
            lbl_Location.Text = fromBoniToGMAKamuning.ToString();

        }

        public void fromBoniToGMAKamuning2(string fromBoniToGMAKamuning2)
        {

            fromBoniToGMAKamuning2.ToString();
            lbl_FromLocation.Text = fromBoniToGMAKamuning2.ToString();

        }

        public void fromBoniToQuezonAve(string fromBoniToQuezonAve)
        {

            fromBoniToQuezonAve.ToString();
            lbl_Location.Text = fromBoniToQuezonAve.ToString();

        }

        public void fromBoniToQuezonAve2(string fromBoniToQuezonAve2)
        {

            fromBoniToQuezonAve2.ToString();
            lbl_FromLocation.Text = fromBoniToQuezonAve2.ToString();

        }

        public void fromBoniToNorthAve(string fromBoniToNorthAve)
        {

            fromBoniToNorthAve.ToString();
            lbl_Location.Text = fromBoniToNorthAve.ToString();

        }

        public void fromBoniToNorthAve2(string fromBoniToNorthAve2)
        {

            fromBoniToNorthAve2.ToString();
            lbl_FromLocation.Text = fromBoniToNorthAve2.ToString();

        }

        //SHAW

        public void fromShawToOrtigas(string fromShawToOrtigas)
        {

            fromShawToOrtigas.ToString();
            lbl_Location.Text = fromShawToOrtigas.ToString();

        }

        public void fromShawToOrtigas2(string fromShawToOrtigas2)
        {

            fromShawToOrtigas2.ToString();
            lbl_FromLocation.Text = fromShawToOrtigas2.ToString();

        }

        public void fromShawToSantolan(string fromShawToSantolan)
        {

            fromShawToSantolan.ToString();
            lbl_Location.Text = fromShawToSantolan.ToString();

        }

        public void fromShawToSantolan2(string fromShawToSantolan2)
        {

            fromShawToSantolan2.ToString();
            lbl_FromLocation.Text = fromShawToSantolan2.ToString();

        }

        public void fromShawToAraneta(string fromShawToAraneta)
        {

            fromShawToAraneta.ToString();
            lbl_Location.Text = fromShawToAraneta.ToString();

        }

        public void fromShawToAraneta2(string fromShawToAraneta2)
        {

            fromShawToAraneta2.ToString();
            lbl_FromLocation.Text = fromShawToAraneta2.ToString();

        }

        public void fromShawToGMAKamuning(string fromShawToGMAKamuning)
        {

            fromShawToGMAKamuning.ToString();
            lbl_Location.Text = fromShawToGMAKamuning.ToString();

        }

        public void fromShawToGMAKamuning2(string fromShawToGMAKamuning2)
        {

            fromShawToGMAKamuning2.ToString();
            lbl_FromLocation.Text = fromShawToGMAKamuning2.ToString();

        }

        public void fromShawToQuezonAve(string fromShawToQuezonAve)
        {

            fromShawToQuezonAve.ToString();
            lbl_Location.Text = fromShawToQuezonAve.ToString();

        }

        public void fromShawToQuezonAve2(string fromShawToQuezonAve2)
        {

            fromShawToQuezonAve2.ToString();
            lbl_FromLocation.Text = fromShawToQuezonAve2.ToString();

        }

        public void fromShawToNorthAve(string fromShawToNorthAve)
        {

            fromShawToNorthAve.ToString();
            lbl_Location.Text = fromShawToNorthAve.ToString();

        }

        public void fromShawToNorthAve2(string fromShawToNorthAve2)
        {

            fromShawToNorthAve2.ToString();
            lbl_FromLocation.Text = fromShawToNorthAve2.ToString();

        }

        //OR"TIGAS"

        public void fromOrtToSantolan(string fromOrtToSantolan)
        {

            fromOrtToSantolan.ToString();
            lbl_Location.Text = fromOrtToSantolan.ToString();

        }

        public void fromOrtToSantolan2(string fromOrtToSantolan2)
        {

            fromOrtToSantolan2.ToString();
            lbl_FromLocation.Text = fromOrtToSantolan2.ToString();

        }

        public void fromOrtToAraneta(string fromOrtToAraneta)
        {

            fromOrtToAraneta.ToString();
            lbl_Location.Text = fromOrtToAraneta.ToString();

        }

        public void fromOrtToAraneta2(string fromOrtToAraneta2)
        {

            fromOrtToAraneta2.ToString();
            lbl_FromLocation.Text = fromOrtToAraneta2.ToString();

        }

        public void fromOrtToGMAKamuning(string fromOrtToGMAKamuning)
        {

            fromOrtToGMAKamuning.ToString();
            lbl_Location.Text = fromOrtToGMAKamuning.ToString();

        }

        public void fromOrtToGMAKamuning2(string fromOrtToGMAKamuning2)
        {

            fromOrtToGMAKamuning2.ToString();
            lbl_FromLocation.Text = fromOrtToGMAKamuning2.ToString();

        }

        public void fromOrtToQuezonAve(string fromOrtToQuezonAve)
        {

            fromOrtToQuezonAve.ToString();
            lbl_Location.Text = fromOrtToQuezonAve.ToString();

        }

        public void fromOrtToQuezonAve2(string fromOrtToQuezonAve2)
        {

            fromOrtToQuezonAve2.ToString();
            lbl_FromLocation.Text = fromOrtToQuezonAve2.ToString();

        }

        public void fromOrtToNorthAve(string fromOrtToNorthAve)
        {

            fromOrtToNorthAve.ToString();
            lbl_Location.Text = fromOrtToNorthAve.ToString();

        }

        public void fromOrtToNorthAve2(string fromOrtToNorthAve2)
        {

            fromOrtToNorthAve2.ToString();
            lbl_FromLocation.Text = fromOrtToNorthAve2.ToString();

        }
        
        //SANTOLAN

        public void fromSantolanToAraneta(string fromSantolanToAraneta)
        {

            fromSantolanToAraneta.ToString();
            lbl_Location.Text = fromSantolanToAraneta.ToString();

        }

        public void fromSantolanToAraneta2(string fromSantolanToAraneta2)
        {

            fromSantolanToAraneta2.ToString();
            lbl_FromLocation.Text = fromSantolanToAraneta2.ToString();

        }

        public void fromSantolanToGMAKamuning(string fromSantolanToGMAKamuning)
        {

            fromSantolanToGMAKamuning.ToString();
            lbl_Location.Text = fromSantolanToGMAKamuning.ToString();

        }

        public void fromSantolanToGMAKamuning2(string fromSantolanToGMAKamuning2)
        {

            fromSantolanToGMAKamuning2.ToString();
            lbl_FromLocation.Text = fromSantolanToGMAKamuning2.ToString();

        }

        public void fromSantolanToQuezonAve(string fromSantolanToQuezonAve)
        {

            fromSantolanToQuezonAve.ToString();
            lbl_Location.Text = fromSantolanToQuezonAve.ToString();

        }

        public void fromSantolanToQuezonAve2(string fromSantolanToQuezonAve2)
        {

            fromSantolanToQuezonAve2.ToString();
            lbl_FromLocation.Text = fromSantolanToQuezonAve2.ToString();

        }

        public void fromSantolanToNorthAve(string fromSantolanToNorthAve)
        {

            fromSantolanToNorthAve.ToString();
            lbl_Location.Text = fromSantolanToNorthAve.ToString();

        }

        public void fromSantolanToNorthAve2(string fromSantolanToNorthAve2)
        {

            fromSantolanToNorthAve2.ToString();
            lbl_FromLocation.Text = fromSantolanToNorthAve2.ToString();

        }

        //ARANETA

        public void fromAranetaToGMAKamuning(string fromAranetaToGMAKamuning)
        {

            fromAranetaToGMAKamuning.ToString();
            lbl_Location.Text = fromAranetaToGMAKamuning.ToString();

        }

        public void fromAranetaToGMAKamuning2(string fromAranetaToGMAKamuning2)
        {

            fromAranetaToGMAKamuning2.ToString();
            lbl_FromLocation.Text = fromAranetaToGMAKamuning2.ToString();

        }

        public void fromAranetaToQuezonAve(string fromAranetaToQuezonAve)
        {

            fromAranetaToQuezonAve.ToString();
            lbl_Location.Text = fromAranetaToQuezonAve.ToString();

        }

        public void fromAranetaToQuezonAve2(string fromAranetaToQuezonAve2)
        {

            fromAranetaToQuezonAve2.ToString();
            lbl_FromLocation.Text = fromAranetaToQuezonAve2.ToString();

        }

        public void fromAranetaToNorthAve(string fromAranetaToNorthAve)
        {

            fromAranetaToNorthAve.ToString();
            lbl_Location.Text = fromAranetaToNorthAve.ToString();

        }

        public void fromAranetaToNorthAve2(string fromAranetaToNorthAve2)
        {

            fromAranetaToNorthAve2.ToString();
            lbl_FromLocation.Text = fromAranetaToNorthAve2.ToString();

        }

        //GMA KAMUNING

        public void fromGMAToQuezonAve(string fromGMAToQuezonAve)
        {

            fromGMAToQuezonAve.ToString();
            lbl_Location.Text = fromGMAToQuezonAve.ToString();

        }

        public void fromGMAToQuezonAve2(string fromGMAToQuezonAve2)
        {

            fromGMAToQuezonAve2.ToString();
            lbl_FromLocation.Text = fromGMAToQuezonAve2.ToString();

        }

        public void fromGMAToNorthAve(string fromGMAToNorthAve)
        {

            fromGMAToNorthAve.ToString();
            lbl_Location.Text = fromGMAToNorthAve.ToString();

        }

        public void fromGMAToNorthAve2(string fromGMAToNorthAve2)
        {

            fromGMAToNorthAve2.ToString();
            lbl_FromLocation.Text = fromGMAToNorthAve2.ToString();

        }

        //QUEZON AVENUE

        public void fromQuezonAveToNorthAve(string fromQuezonAveToNorthAve)
        {

            fromQuezonAveToNorthAve.ToString();
            lbl_Location.Text = fromQuezonAveToNorthAve.ToString();

        }

        public void fromQuezonAveToNorthAve2(string fromQuezonAveToNorthAve2)
        {

            fromQuezonAveToNorthAve2.ToString();
            lbl_FromLocation.Text = fromQuezonAveToNorthAve2.ToString();

        }

        public void TotalPrice(string TotalPrice) {

            TotalPrice.ToString();
            lblPrice.Text = TotalPrice.ToString();
            lblPurchase.Text = lblPrice.Text.ToString() ;
            txtTot.Text = TotalPrice.ToString();
            
          
        }


        private void lbl_FromLocation_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Plus_Click(object sender, EventArgs e)
        {
            Double ticket = Convert.ToDouble(lblTicketTot.Text);

            Double sum = ticket + 1;

            lblTicketTot.Text = sum.ToString();



            Double price = Convert.ToDouble(lblPrice.Text);

            Double PurchaseValue = sum * price;
            lblPurchase.Text = PurchaseValue.ToString() + ".00";
            txtTot.Text = PurchaseValue.ToString() + ".00";


        }

        private void Minus_Click(object sender, EventArgs e)
        {
            Double ticket = Convert.ToDouble(lblTicketTot.Text);

            if (lblTicketTot.Text == "1")
            {
                MessageBox.Show("Your Total Ticket is 1 ");
            }
            else {
                Double diff = ticket - 1;
                lblTicketTot.Text = diff.ToString();


                Double price = Convert.ToDouble(lblPrice.Text);

                Double PurchaseValue = diff * price;
                lblPurchase.Text = PurchaseValue.ToString() + ".00";
                txtTot.Text = PurchaseValue.ToString() + ".00";
            }
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
          

           Double PurchaseValue = Convert.ToDouble(lblPurchase.Text);
           Double AmountInserted = Convert.ToDouble(txtAmountInserted.Text);

           if (PurchaseValue <= AmountInserted)
           {

               Double changed = AmountInserted - PurchaseValue;

               lblChange.Text = changed.ToString() + ".00";
                txtResult.Clear();
                txtResult.Text += "\n\t\t\tITZ'ey MRT\n";
                txtResult.Text += "\t\t\t   RECEIPT\n\n";
                txtResult.Text += "\t Receipt No:             \t\t" + lblRand.Text + "\n";
                txtResult.Text += "\t Date and Time \t\t" + lblTimeDate.Text + "\n";
                txtResult.Text += "\t Station Name: \t\t" + lbl_Location.Text + "\n";
                txtResult.Text += "\t ----------------------------------------------\n\n";
                txtResult.Text += "\t TRANSACTION RECEIPT\n\n";
                txtResult.Text += "\t -----------------------------------------------\n\n\n\n";
                txtResult.Text += "\t AMOUNT INSERTED: \t\t" + txtAmountInserted.Text + ".00\n";
                txtResult.Text += "\t TOTAL AMOUNT:  \t\t" + lblPurchase.Text + "\n";
                txtResult.Text += "\t CHANGE: \t\t\t" + lblChange.Text + "\n\n";
                txtResult.Text += "\t ------------------------------------------------\n";
                txtResult.Text += "\t Have a nice day!\n\n";
                txtResult.Text += "\t ------------------------------------------------\n";
                txtResult.Text += "\t CUSTOMER'S COPY\n\n";

                printPreviewDialog1.Document = printDocument1;
                printPreviewDialog1.ShowDialog();
                insertdata();

            }

           else {
               MessageBox.Show("Insufficient Funds");
           
           }

        }

        private void lblPurchaseValue_Click(object sender, EventArgs e)
        {

        }


        private void timer_Tick(object sender, EventArgs e)
        {
            lblTimeDate.Text = DateTime.Now.ToString("MMM dd yyyy,hh:mm");
           
        }

        private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            
        }

   

        private void Receipt_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void btnTravel_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form2 f2 = new Form2();

            f2.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(txtResult.Text, new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(10, 10));
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }
        public void insertdata()
        {

            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = con;
                cmd.CommandText = "insert into MRT(Station,Destination,Price,Tickets,AmountPaid,Total,Change,ReceiptNo,DateAndTime)values('" + lbl_FromLocation.Text + "','" + lbl_Location.Text + "','" + lblPrice.Text + "','" + lblTicketTot.Text + "','" + txtAmountInserted.Text + "','" + lblPurchase.Text + "','" + lblChange.Text + "','" + lblRand.Text + "','" + lblTimeDate.Text + "')";

                cmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);
            }
        }
    }
}

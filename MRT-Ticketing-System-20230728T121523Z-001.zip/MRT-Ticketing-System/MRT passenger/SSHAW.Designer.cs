﻿namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    partial class SSHAW
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label6;
            this.label4 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl7QuezonAve = new System.Windows.Forms.Label();
            this.rb7_QuezonAve = new System.Windows.Forms.RadioButton();
            this.lbl7GMAKAMUNING = new System.Windows.Forms.Label();
            this.rb7_GMA = new System.Windows.Forms.RadioButton();
            this.lbl7NorthAve = new System.Windows.Forms.Label();
            this.rb7_NorthAve = new System.Windows.Forms.RadioButton();
            this.lbl7AranetaCubao = new System.Windows.Forms.Label();
            this.rb7_AranetaCubao = new System.Windows.Forms.RadioButton();
            this.lbl7Ortigas = new System.Windows.Forms.Label();
            this.rb7_Ortigas = new System.Windows.Forms.RadioButton();
            this.lbl7Santolan = new System.Windows.Forms.Label();
            this.rb7_Santolan = new System.Windows.Forms.RadioButton();
            this.lblPrice = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.lbl_Shaw = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label2.Location = new System.Drawing.Point(556, 118);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(272, 24);
            label2.TabIndex = 1;
            label2.Text = "SELECT YOUR DESTINATION";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label3.Location = new System.Drawing.Point(672, 286);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(101, 24);
            label3.TabIndex = 12;
            label3.Text = "Ticket fare:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label6.Location = new System.Drawing.Point(165, 256);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(178, 37);
            label6.TabIndex = 64;
            label6.Text = "STATIONS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(832, 380);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 42);
            this.label4.TabIndex = 16;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(1171, 629);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(140, 33);
            this.button14.TabIndex = 17;
            this.button14.Text = "PROCEED";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(16, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1326, 155);
            this.panel1.TabIndex = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ITZeyyyyy_TRAIN_TICKET_SYSTEM.Properties.Resources.metro_station;
            this.pictureBox2.Location = new System.Drawing.Point(143, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(193, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(314, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(972, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = " SHAW BOULEVARD STATION";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel5.Location = new System.Drawing.Point(35, 286);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 400);
            this.panel5.TabIndex = 68;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel9.Location = new System.Drawing.Point(447, 286);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1, 400);
            this.panel9.TabIndex = 67;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel4.Location = new System.Drawing.Point(35, 286);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(136, 1);
            this.panel4.TabIndex = 66;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel8.Location = new System.Drawing.Point(312, 286);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(136, 1);
            this.panel8.TabIndex = 65;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl7QuezonAve);
            this.panel2.Controls.Add(this.rb7_QuezonAve);
            this.panel2.Controls.Add(this.lbl7GMAKAMUNING);
            this.panel2.Controls.Add(this.rb7_GMA);
            this.panel2.Controls.Add(this.lbl7NorthAve);
            this.panel2.Controls.Add(this.rb7_NorthAve);
            this.panel2.Controls.Add(this.lbl7AranetaCubao);
            this.panel2.Controls.Add(this.rb7_AranetaCubao);
            this.panel2.Controls.Add(this.lbl7Ortigas);
            this.panel2.Controls.Add(this.rb7_Ortigas);
            this.panel2.Controls.Add(this.lbl7Santolan);
            this.panel2.Controls.Add(this.rb7_Santolan);
            this.panel2.Location = new System.Drawing.Point(35, 286);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(413, 429);
            this.panel2.TabIndex = 63;
            // 
            // lbl7QuezonAve
            // 
            this.lbl7QuezonAve.AutoSize = true;
            this.lbl7QuezonAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl7QuezonAve.Location = new System.Drawing.Point(245, 77);
            this.lbl7QuezonAve.Name = "lbl7QuezonAve";
            this.lbl7QuezonAve.Size = new System.Drawing.Size(100, 13);
            this.lbl7QuezonAve.TabIndex = 132;
            this.lbl7QuezonAve.Text = "QUEZON AVENUE";
            // 
            // rb7_QuezonAve
            // 
            this.rb7_QuezonAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb7_QuezonAve.AutoSize = true;
            this.rb7_QuezonAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb7_QuezonAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb7_QuezonAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb7_QuezonAve.ForeColor = System.Drawing.Color.White;
            this.rb7_QuezonAve.Location = new System.Drawing.Point(220, 94);
            this.rb7_QuezonAve.Name = "rb7_QuezonAve";
            this.rb7_QuezonAve.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb7_QuezonAve.Size = new System.Drawing.Size(158, 37);
            this.rb7_QuezonAve.TabIndex = 131;
            this.rb7_QuezonAve.TabStop = true;
            this.rb7_QuezonAve.Text = "Quezon Ave.";
            this.rb7_QuezonAve.UseVisualStyleBackColor = false;
            this.rb7_QuezonAve.CheckedChanged += new System.EventHandler(this.rb7_QuezonAve_CheckedChanged);
            // 
            // lbl7GMAKAMUNING
            // 
            this.lbl7GMAKAMUNING.AutoSize = true;
            this.lbl7GMAKAMUNING.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl7GMAKAMUNING.Location = new System.Drawing.Point(252, 8);
            this.lbl7GMAKAMUNING.Name = "lbl7GMAKAMUNING";
            this.lbl7GMAKAMUNING.Size = new System.Drawing.Size(92, 13);
            this.lbl7GMAKAMUNING.TabIndex = 134;
            this.lbl7GMAKAMUNING.Text = "GMA KAMUNING";
            // 
            // rb7_GMA
            // 
            this.rb7_GMA.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb7_GMA.AutoSize = true;
            this.rb7_GMA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb7_GMA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb7_GMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb7_GMA.ForeColor = System.Drawing.Color.White;
            this.rb7_GMA.Location = new System.Drawing.Point(220, 30);
            this.rb7_GMA.Name = "rb7_GMA";
            this.rb7_GMA.Size = new System.Drawing.Size(156, 36);
            this.rb7_GMA.TabIndex = 133;
            this.rb7_GMA.TabStop = true;
            this.rb7_GMA.Text = "GMA Kamuning";
            this.rb7_GMA.UseVisualStyleBackColor = false;
            this.rb7_GMA.CheckedChanged += new System.EventHandler(this.rb7_GMA_CheckedChanged);
            // 
            // lbl7NorthAve
            // 
            this.lbl7NorthAve.AutoSize = true;
            this.lbl7NorthAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl7NorthAve.Location = new System.Drawing.Point(254, 144);
            this.lbl7NorthAve.Name = "lbl7NorthAve";
            this.lbl7NorthAve.Size = new System.Drawing.Size(93, 13);
            this.lbl7NorthAve.TabIndex = 130;
            this.lbl7NorthAve.Text = "NORTH AVENUE";
            // 
            // rb7_NorthAve
            // 
            this.rb7_NorthAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb7_NorthAve.AutoSize = true;
            this.rb7_NorthAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb7_NorthAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb7_NorthAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb7_NorthAve.ForeColor = System.Drawing.Color.White;
            this.rb7_NorthAve.Location = new System.Drawing.Point(219, 162);
            this.rb7_NorthAve.Name = "rb7_NorthAve";
            this.rb7_NorthAve.Padding = new System.Windows.Forms.Padding(17, 0, 17, 0);
            this.rb7_NorthAve.Size = new System.Drawing.Size(159, 37);
            this.rb7_NorthAve.TabIndex = 129;
            this.rb7_NorthAve.TabStop = true;
            this.rb7_NorthAve.Text = "North Ave.";
            this.rb7_NorthAve.UseVisualStyleBackColor = false;
            this.rb7_NorthAve.CheckedChanged += new System.EventHandler(this.rb7_NorthAve_CheckedChanged);
            // 
            // lbl7AranetaCubao
            // 
            this.lbl7AranetaCubao.AutoSize = true;
            this.lbl7AranetaCubao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl7AranetaCubao.Location = new System.Drawing.Point(60, 142);
            this.lbl7AranetaCubao.Name = "lbl7AranetaCubao";
            this.lbl7AranetaCubao.Size = new System.Drawing.Size(98, 13);
            this.lbl7AranetaCubao.TabIndex = 128;
            this.lbl7AranetaCubao.Text = "ARANETA CUBAO";
            // 
            // rb7_AranetaCubao
            // 
            this.rb7_AranetaCubao.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb7_AranetaCubao.AutoSize = true;
            this.rb7_AranetaCubao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb7_AranetaCubao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb7_AranetaCubao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb7_AranetaCubao.ForeColor = System.Drawing.Color.White;
            this.rb7_AranetaCubao.Location = new System.Drawing.Point(29, 163);
            this.rb7_AranetaCubao.Name = "rb7_AranetaCubao";
            this.rb7_AranetaCubao.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb7_AranetaCubao.Size = new System.Drawing.Size(158, 36);
            this.rb7_AranetaCubao.TabIndex = 127;
            this.rb7_AranetaCubao.TabStop = true;
            this.rb7_AranetaCubao.Text = "Araneta Cubao";
            this.rb7_AranetaCubao.UseVisualStyleBackColor = false;
            this.rb7_AranetaCubao.CheckedChanged += new System.EventHandler(this.rb7_AranetaCubao_CheckedChanged);
            // 
            // lbl7Ortigas
            // 
            this.lbl7Ortigas.AutoSize = true;
            this.lbl7Ortigas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl7Ortigas.Location = new System.Drawing.Point(81, 11);
            this.lbl7Ortigas.Name = "lbl7Ortigas";
            this.lbl7Ortigas.Size = new System.Drawing.Size(55, 13);
            this.lbl7Ortigas.TabIndex = 124;
            this.lbl7Ortigas.Text = "ORTIGAS";
            // 
            // rb7_Ortigas
            // 
            this.rb7_Ortigas.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb7_Ortigas.AutoSize = true;
            this.rb7_Ortigas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb7_Ortigas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb7_Ortigas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb7_Ortigas.ForeColor = System.Drawing.Color.White;
            this.rb7_Ortigas.Location = new System.Drawing.Point(34, 31);
            this.rb7_Ortigas.Name = "rb7_Ortigas";
            this.rb7_Ortigas.Padding = new System.Windows.Forms.Padding(37, 0, 37, 0);
            this.rb7_Ortigas.Size = new System.Drawing.Size(155, 36);
            this.rb7_Ortigas.TabIndex = 123;
            this.rb7_Ortigas.TabStop = true;
            this.rb7_Ortigas.Text = "Ortigas";
            this.rb7_Ortigas.UseVisualStyleBackColor = false;
            this.rb7_Ortigas.CheckedChanged += new System.EventHandler(this.rb7_Ortigas_CheckedChanged);
            // 
            // lbl7Santolan
            // 
            this.lbl7Santolan.AutoSize = true;
            this.lbl7Santolan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl7Santolan.Location = new System.Drawing.Point(76, 74);
            this.lbl7Santolan.Name = "lbl7Santolan";
            this.lbl7Santolan.Size = new System.Drawing.Size(65, 13);
            this.lbl7Santolan.TabIndex = 122;
            this.lbl7Santolan.Text = "SANTOLAN";
            // 
            // rb7_Santolan
            // 
            this.rb7_Santolan.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb7_Santolan.AutoSize = true;
            this.rb7_Santolan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb7_Santolan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb7_Santolan.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb7_Santolan.ForeColor = System.Drawing.Color.White;
            this.rb7_Santolan.Location = new System.Drawing.Point(33, 94);
            this.rb7_Santolan.Name = "rb7_Santolan";
            this.rb7_Santolan.Padding = new System.Windows.Forms.Padding(30, 0, 30, 0);
            this.rb7_Santolan.Size = new System.Drawing.Size(155, 36);
            this.rb7_Santolan.TabIndex = 121;
            this.rb7_Santolan.TabStop = true;
            this.rb7_Santolan.Text = "Santolan";
            this.rb7_Santolan.UseVisualStyleBackColor = false;
            this.rb7_Santolan.CheckedChanged += new System.EventHandler(this.rb7_Santolan_CheckedChanged);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(637, 422);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(248, 111);
            this.lblPrice.TabIndex = 73;
            this.lblPrice.Text = "0.00";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(676, 629);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(140, 33);
            this.button13.TabIndex = 74;
            this.button13.Text = "BACK";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click_1);
            // 
            // lbl_Shaw
            // 
            this.lbl_Shaw.AutoSize = true;
            this.lbl_Shaw.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl_Shaw.Location = new System.Drawing.Point(212, 234);
            this.lbl_Shaw.Name = "lbl_Shaw";
            this.lbl_Shaw.Size = new System.Drawing.Size(109, 13);
            this.lbl_Shaw.TabIndex = 82;
            this.lbl_Shaw.Text = "SHAW BOULEVARD";
            // 
            // SSHAW
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1354, 703);
            this.Controls.Add(this.lbl_Shaw);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel8);
            this.Controls.Add(label6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button14);
            this.Controls.Add(label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SSHAW";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Shaw";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Shaw_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lbl7QuezonAve;
        private System.Windows.Forms.RadioButton rb7_QuezonAve;
        private System.Windows.Forms.Label lbl7GMAKAMUNING;
        private System.Windows.Forms.RadioButton rb7_GMA;
        private System.Windows.Forms.Label lbl7NorthAve;
        private System.Windows.Forms.RadioButton rb7_NorthAve;
        private System.Windows.Forms.Label lbl7AranetaCubao;
        private System.Windows.Forms.RadioButton rb7_AranetaCubao;
        private System.Windows.Forms.Label lbl7Ortigas;
        private System.Windows.Forms.RadioButton rb7_Ortigas;
        private System.Windows.Forms.Label lbl7Santolan;
        private System.Windows.Forms.RadioButton rb7_Santolan;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label lbl_Shaw;
    }
}
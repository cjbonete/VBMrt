﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SGMA : Form
    {
        public SGMA()
        {
            InitializeComponent();
        }

        private void Ayala_Load(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb11_QuezonAve.Checked == true && lblPrice.Text != "0.00")
            {

                string GMAToQuezonAve, fromGMAToQuezonAve, TotalPrice;

                GMAToQuezonAve = lbl11QuezonAve.Text;
                fromGMAToQuezonAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();

                TF.fromGMAToQuezonAve(GMAToQuezonAve.ToString());
                TF.fromGMAToQuezonAve2(fromGMAToQuezonAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();
            }

            else if (rb11_NorthAve.Checked == true && lblPrice.Text != "0.00")
            {

                string GMAToNorthAve, fromGMAToNorthAve, TotalPrice;

                GMAToNorthAve = lbl11NorthAve.Text;
                fromGMAToNorthAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromAranetaToNorthAve(GMAToNorthAve.ToString());
                TF.fromAranetaToNorthAve2(fromGMAToNorthAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void rb11_QuezonAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb11_QuezonAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb11_NorthAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb11_NorthAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }
    }
}

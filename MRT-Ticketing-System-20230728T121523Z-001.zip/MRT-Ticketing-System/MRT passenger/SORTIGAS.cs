﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SORTIGAS : Form
    {
        public SORTIGAS()
        {
            InitializeComponent();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb8_Santolan.Checked == true && lblPrice.Text != "0.00")
            {

                string OrtToSantolan, fromOrtToSantolan, TotalPrice;

                OrtToSantolan = lbl8Santolan.Text;
                fromOrtToSantolan = lbl_Ortigas.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromOrtToSantolan(OrtToSantolan.ToString());
                TF.fromOrtToSantolan2(fromOrtToSantolan.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb8_AranetaCubao.Checked == true && lblPrice.Text != "0.00")
            {

                string OrtToAraneta, fromOrtToAraneta, TotalPrice;

                OrtToAraneta = lbl8AranetaCubao.Text;
                fromOrtToAraneta = lbl_Ortigas.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromOrtToAraneta(OrtToAraneta.ToString());
                TF.fromOrtToAraneta2(fromOrtToAraneta.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb8_GMA.Checked == true && lblPrice.Text != "0.00")
            {

                string OrtToGMAKamuning, fromOrtToGMAKamuning, TotalPrice;

                OrtToGMAKamuning = lbl8GMAKAMUNING.Text;
                fromOrtToGMAKamuning = lbl_Ortigas.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromOrtToGMAKamuning(OrtToGMAKamuning.ToString());
                TF.fromOrtToGMAKamuning2(fromOrtToGMAKamuning.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb8_QuezonAve.Checked == true && lblPrice.Text != "0.00")
            {

                string OrtToQuezonAve, fromOrtToQuezonAve, TotalPrice;

                OrtToQuezonAve = lbl8QuezonAve.Text;
                fromOrtToQuezonAve = lbl_Ortigas.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();

                TF.fromOrtToQuezonAve(OrtToQuezonAve.ToString());
                TF.fromOrtToQuezonAve2(fromOrtToQuezonAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();
            }

            else if (rb8_NorthAve.Checked == true && lblPrice.Text != "0.00")
            {

                string OrtToNorthAve, fromOrtToNorthAve, TotalPrice;

                OrtToNorthAve = lbl8NorthAve.Text;
                fromOrtToNorthAve = lbl_Ortigas.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromOrtToNorthAve(OrtToNorthAve.ToString());
                TF.fromOrtToNorthAve2(fromOrtToNorthAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void rb8_Santolan_CheckedChanged(object sender, EventArgs e)
        {
            if (rb8_Santolan.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb8_AranetaCubao_CheckedChanged(object sender, EventArgs e)
        {
            if (rb8_AranetaCubao.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb8_GMA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb8_GMA.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb8_QuezonAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb8_QuezonAve.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb8_NorthAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb8_NorthAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }
    }
}

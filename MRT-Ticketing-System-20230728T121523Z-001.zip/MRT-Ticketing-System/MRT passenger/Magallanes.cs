﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Magallanes : Form
    {
        public Magallanes()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb12_TaftAve.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl12TaftAve.Text;
                fromQuezonAve = lbl_Magallanes.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();

                lblTot GMA2 = new lblTot();
                GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());
                GMA2.ShowDialog();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void rb12_TaftAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb12_TaftAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }
    }
}

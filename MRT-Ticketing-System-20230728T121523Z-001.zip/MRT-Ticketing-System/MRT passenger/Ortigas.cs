﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Ortigas : Form
    {
        public Ortigas()
        {
            InitializeComponent();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb6_ShawBoulevard.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl6ShawBoulevard.Text;
                fromQuezonAve = lbl_Ortigas.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();

                lblTot GMA2 = new lblTot();
                GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());
                GMA2.ShowDialog();
            }
            else if (rb6_BoniAve.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl6BoniAve.Text;
                fromQuezonAve = lbl_Ortigas.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();

                lblTot GMA2 = new lblTot();
                GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());
                GMA2.ShowDialog();
            }
            else if (rb6_Guadalupe.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl6Guadalupe.Text;
                fromQuezonAve = lbl_Ortigas.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();

                lblTot GMA2 = new lblTot();
                GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());
                GMA2.ShowDialog();
            }
            else if (rb6_Buendia.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl6Buendia.Text;
                fromQuezonAve = lbl_Ortigas.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();

                lblTot GMA2 = new lblTot();
                GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());
                GMA2.ShowDialog();
            }
            else if (rb6_AyalaAve.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl6AyalaAve.Text;
                fromQuezonAve = lbl_Ortigas.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();

                lblTot GMA2 = new lblTot();
                GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());
                GMA2.ShowDialog();
            }
            else if (rb6_Magallanes.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl6Magallanes.Text;
                fromQuezonAve = lbl_Ortigas.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();

                lblTot GMA2 = new lblTot();
                GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());
                GMA2.ShowDialog();
            }
            else if (rb6_TaftAve.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl6TaftAve.Text;
                fromQuezonAve = lbl_Ortigas.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();

                lblTot GMA2 = new lblTot();
                GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());
                GMA2.ShowDialog();
            }
        }

        private void Ortigas_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void rb6_ShawBoulevard_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_ShawBoulevard.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb6_BoniAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_BoniAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb6_Guadalupe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_Guadalupe.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb6_Buendia_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_Buendia.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb6_AyalaAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_AyalaAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb6_Magallanes_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_Magallanes.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb6_TaftAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_TaftAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }
    }
}

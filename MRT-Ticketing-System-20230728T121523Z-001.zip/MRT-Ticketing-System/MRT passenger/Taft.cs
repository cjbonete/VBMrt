﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Taft : Form
    {
        public Taft()
        {
            InitializeComponent();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            //this.Hide();

            //TA taft = new TA();

            //taft.ShowDialog();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnTravel_Click(object sender, EventArgs e)
        {

            this.Hide();
            STAFT rail = new STAFT();
            rail.ShowDialog();


        }
    }
}

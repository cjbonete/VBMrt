﻿namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    partial class SGUADA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label6;
            this.label4 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl5QuezonAve = new System.Windows.Forms.Label();
            this.rb5_QuezonAve = new System.Windows.Forms.RadioButton();
            this.lbl5GMAKAMUNING = new System.Windows.Forms.Label();
            this.rb5_GMA = new System.Windows.Forms.RadioButton();
            this.lbl5NorthAve = new System.Windows.Forms.Label();
            this.rb5_NorthAve = new System.Windows.Forms.RadioButton();
            this.lbl5AranetaCubao = new System.Windows.Forms.Label();
            this.rb5_AranetaCubao = new System.Windows.Forms.RadioButton();
            this.lbl5ShawBoulevard = new System.Windows.Forms.Label();
            this.lbl5Ortigas = new System.Windows.Forms.Label();
            this.rb5_Ortigas = new System.Windows.Forms.RadioButton();
            this.rb5_ShawBoulevard = new System.Windows.Forms.RadioButton();
            this.lbl5Santolan = new System.Windows.Forms.Label();
            this.rb5_Santolan = new System.Windows.Forms.RadioButton();
            this.lbl5BoniAve = new System.Windows.Forms.Label();
            this.rb5_BoniAve = new System.Windows.Forms.RadioButton();
            this.lblPrice = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.lbl_Guadalupe = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label2.Location = new System.Drawing.Point(556, 118);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(272, 24);
            label2.TabIndex = 1;
            label2.Text = "SELECT YOUR DESTINATION";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label3.Location = new System.Drawing.Point(688, 306);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(101, 24);
            label3.TabIndex = 12;
            label3.Text = "Ticket fare:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label6.Location = new System.Drawing.Point(190, 267);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(178, 37);
            label6.TabIndex = 50;
            label6.Text = "STATIONS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(848, 400);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 42);
            this.label4.TabIndex = 16;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(1164, 634);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(140, 33);
            this.button14.TabIndex = 17;
            this.button14.Text = "PROCEED";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(32, 80);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1326, 155);
            this.panel1.TabIndex = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ITZeyyyyy_TRAIN_TICKET_SYSTEM.Properties.Resources.metro_station;
            this.pictureBox2.Location = new System.Drawing.Point(143, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(193, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(321, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(740, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "GUADALUPE STATION";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel5.Location = new System.Drawing.Point(60, 297);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 400);
            this.panel5.TabIndex = 54;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel9.Location = new System.Drawing.Point(472, 297);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1, 400);
            this.panel9.TabIndex = 53;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel4.Location = new System.Drawing.Point(60, 297);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(136, 1);
            this.panel4.TabIndex = 52;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel8.Location = new System.Drawing.Point(337, 297);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(136, 1);
            this.panel8.TabIndex = 51;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl5QuezonAve);
            this.panel2.Controls.Add(this.rb5_QuezonAve);
            this.panel2.Controls.Add(this.lbl5GMAKAMUNING);
            this.panel2.Controls.Add(this.rb5_GMA);
            this.panel2.Controls.Add(this.lbl5NorthAve);
            this.panel2.Controls.Add(this.rb5_NorthAve);
            this.panel2.Controls.Add(this.lbl5AranetaCubao);
            this.panel2.Controls.Add(this.rb5_AranetaCubao);
            this.panel2.Controls.Add(this.lbl5ShawBoulevard);
            this.panel2.Controls.Add(this.lbl5Ortigas);
            this.panel2.Controls.Add(this.rb5_Ortigas);
            this.panel2.Controls.Add(this.rb5_ShawBoulevard);
            this.panel2.Controls.Add(this.lbl5Santolan);
            this.panel2.Controls.Add(this.rb5_Santolan);
            this.panel2.Controls.Add(this.lbl5BoniAve);
            this.panel2.Controls.Add(this.rb5_BoniAve);
            this.panel2.Location = new System.Drawing.Point(60, 297);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(413, 429);
            this.panel2.TabIndex = 49;
            // 
            // lbl5QuezonAve
            // 
            this.lbl5QuezonAve.AutoSize = true;
            this.lbl5QuezonAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl5QuezonAve.Location = new System.Drawing.Point(250, 162);
            this.lbl5QuezonAve.Name = "lbl5QuezonAve";
            this.lbl5QuezonAve.Size = new System.Drawing.Size(100, 13);
            this.lbl5QuezonAve.TabIndex = 102;
            this.lbl5QuezonAve.Text = "QUEZON AVENUE";
            // 
            // rb5_QuezonAve
            // 
            this.rb5_QuezonAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb5_QuezonAve.AutoSize = true;
            this.rb5_QuezonAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb5_QuezonAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb5_QuezonAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb5_QuezonAve.ForeColor = System.Drawing.Color.White;
            this.rb5_QuezonAve.Location = new System.Drawing.Point(225, 179);
            this.rb5_QuezonAve.Name = "rb5_QuezonAve";
            this.rb5_QuezonAve.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb5_QuezonAve.Size = new System.Drawing.Size(158, 37);
            this.rb5_QuezonAve.TabIndex = 101;
            this.rb5_QuezonAve.TabStop = true;
            this.rb5_QuezonAve.Text = "Quezon Ave.";
            this.rb5_QuezonAve.UseVisualStyleBackColor = false;
            this.rb5_QuezonAve.CheckedChanged += new System.EventHandler(this.rb5_QuezonAve_CheckedChanged);
            // 
            // lbl5GMAKAMUNING
            // 
            this.lbl5GMAKAMUNING.AutoSize = true;
            this.lbl5GMAKAMUNING.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl5GMAKAMUNING.Location = new System.Drawing.Point(257, 93);
            this.lbl5GMAKAMUNING.Name = "lbl5GMAKAMUNING";
            this.lbl5GMAKAMUNING.Size = new System.Drawing.Size(92, 13);
            this.lbl5GMAKAMUNING.TabIndex = 104;
            this.lbl5GMAKAMUNING.Text = "GMA KAMUNING";
            // 
            // rb5_GMA
            // 
            this.rb5_GMA.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb5_GMA.AutoSize = true;
            this.rb5_GMA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb5_GMA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb5_GMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb5_GMA.ForeColor = System.Drawing.Color.White;
            this.rb5_GMA.Location = new System.Drawing.Point(225, 115);
            this.rb5_GMA.Name = "rb5_GMA";
            this.rb5_GMA.Size = new System.Drawing.Size(156, 36);
            this.rb5_GMA.TabIndex = 103;
            this.rb5_GMA.TabStop = true;
            this.rb5_GMA.Text = "GMA Kamuning";
            this.rb5_GMA.UseVisualStyleBackColor = false;
            this.rb5_GMA.CheckedChanged += new System.EventHandler(this.rb5_GMA_CheckedChanged);
            // 
            // lbl5NorthAve
            // 
            this.lbl5NorthAve.AutoSize = true;
            this.lbl5NorthAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl5NorthAve.Location = new System.Drawing.Point(259, 224);
            this.lbl5NorthAve.Name = "lbl5NorthAve";
            this.lbl5NorthAve.Size = new System.Drawing.Size(93, 13);
            this.lbl5NorthAve.TabIndex = 100;
            this.lbl5NorthAve.Text = "NORTH AVENUE";
            // 
            // rb5_NorthAve
            // 
            this.rb5_NorthAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb5_NorthAve.AutoSize = true;
            this.rb5_NorthAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb5_NorthAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb5_NorthAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb5_NorthAve.ForeColor = System.Drawing.Color.White;
            this.rb5_NorthAve.Location = new System.Drawing.Point(224, 242);
            this.rb5_NorthAve.Name = "rb5_NorthAve";
            this.rb5_NorthAve.Padding = new System.Windows.Forms.Padding(17, 0, 17, 0);
            this.rb5_NorthAve.Size = new System.Drawing.Size(159, 37);
            this.rb5_NorthAve.TabIndex = 99;
            this.rb5_NorthAve.TabStop = true;
            this.rb5_NorthAve.Text = "North Ave.";
            this.rb5_NorthAve.UseVisualStyleBackColor = false;
            this.rb5_NorthAve.CheckedChanged += new System.EventHandler(this.rb5_NorthAve_CheckedChanged);
            // 
            // lbl5AranetaCubao
            // 
            this.lbl5AranetaCubao.AutoSize = true;
            this.lbl5AranetaCubao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl5AranetaCubao.Location = new System.Drawing.Point(257, 29);
            this.lbl5AranetaCubao.Name = "lbl5AranetaCubao";
            this.lbl5AranetaCubao.Size = new System.Drawing.Size(98, 13);
            this.lbl5AranetaCubao.TabIndex = 98;
            this.lbl5AranetaCubao.Text = "ARANETA CUBAO";
            // 
            // rb5_AranetaCubao
            // 
            this.rb5_AranetaCubao.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb5_AranetaCubao.AutoSize = true;
            this.rb5_AranetaCubao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb5_AranetaCubao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb5_AranetaCubao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb5_AranetaCubao.ForeColor = System.Drawing.Color.White;
            this.rb5_AranetaCubao.Location = new System.Drawing.Point(226, 50);
            this.rb5_AranetaCubao.Name = "rb5_AranetaCubao";
            this.rb5_AranetaCubao.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb5_AranetaCubao.Size = new System.Drawing.Size(158, 36);
            this.rb5_AranetaCubao.TabIndex = 97;
            this.rb5_AranetaCubao.TabStop = true;
            this.rb5_AranetaCubao.Text = "Araneta Cubao";
            this.rb5_AranetaCubao.UseVisualStyleBackColor = false;
            this.rb5_AranetaCubao.CheckedChanged += new System.EventHandler(this.rb5_AranetaCubao_CheckedChanged);
            // 
            // lbl5ShawBoulevard
            // 
            this.lbl5ShawBoulevard.AutoSize = true;
            this.lbl5ShawBoulevard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl5ShawBoulevard.Location = new System.Drawing.Point(55, 96);
            this.lbl5ShawBoulevard.Name = "lbl5ShawBoulevard";
            this.lbl5ShawBoulevard.Size = new System.Drawing.Size(109, 13);
            this.lbl5ShawBoulevard.TabIndex = 93;
            this.lbl5ShawBoulevard.Text = "SHAW BOULEVARD";
            // 
            // lbl5Ortigas
            // 
            this.lbl5Ortigas.AutoSize = true;
            this.lbl5Ortigas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl5Ortigas.Location = new System.Drawing.Point(82, 160);
            this.lbl5Ortigas.Name = "lbl5Ortigas";
            this.lbl5Ortigas.Size = new System.Drawing.Size(55, 13);
            this.lbl5Ortigas.TabIndex = 91;
            this.lbl5Ortigas.Text = "ORTIGAS";
            // 
            // rb5_Ortigas
            // 
            this.rb5_Ortigas.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb5_Ortigas.AutoSize = true;
            this.rb5_Ortigas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb5_Ortigas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb5_Ortigas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb5_Ortigas.ForeColor = System.Drawing.Color.White;
            this.rb5_Ortigas.Location = new System.Drawing.Point(35, 180);
            this.rb5_Ortigas.Name = "rb5_Ortigas";
            this.rb5_Ortigas.Padding = new System.Windows.Forms.Padding(37, 0, 37, 0);
            this.rb5_Ortigas.Size = new System.Drawing.Size(155, 36);
            this.rb5_Ortigas.TabIndex = 90;
            this.rb5_Ortigas.TabStop = true;
            this.rb5_Ortigas.Text = "Ortigas";
            this.rb5_Ortigas.UseVisualStyleBackColor = false;
            this.rb5_Ortigas.CheckedChanged += new System.EventHandler(this.rb5_Ortigas_CheckedChanged);
            // 
            // rb5_ShawBoulevard
            // 
            this.rb5_ShawBoulevard.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb5_ShawBoulevard.AutoSize = true;
            this.rb5_ShawBoulevard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb5_ShawBoulevard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb5_ShawBoulevard.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb5_ShawBoulevard.ForeColor = System.Drawing.Color.White;
            this.rb5_ShawBoulevard.Location = new System.Drawing.Point(34, 115);
            this.rb5_ShawBoulevard.Name = "rb5_ShawBoulevard";
            this.rb5_ShawBoulevard.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.rb5_ShawBoulevard.Size = new System.Drawing.Size(155, 36);
            this.rb5_ShawBoulevard.TabIndex = 92;
            this.rb5_ShawBoulevard.TabStop = true;
            this.rb5_ShawBoulevard.Text = "Shaw Blvd.";
            this.rb5_ShawBoulevard.UseVisualStyleBackColor = false;
            this.rb5_ShawBoulevard.CheckedChanged += new System.EventHandler(this.rb5_ShawBoulevard_CheckedChanged);
            // 
            // lbl5Santolan
            // 
            this.lbl5Santolan.AutoSize = true;
            this.lbl5Santolan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl5Santolan.Location = new System.Drawing.Point(77, 223);
            this.lbl5Santolan.Name = "lbl5Santolan";
            this.lbl5Santolan.Size = new System.Drawing.Size(65, 13);
            this.lbl5Santolan.TabIndex = 89;
            this.lbl5Santolan.Text = "SANTOLAN";
            // 
            // rb5_Santolan
            // 
            this.rb5_Santolan.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb5_Santolan.AutoSize = true;
            this.rb5_Santolan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb5_Santolan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb5_Santolan.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb5_Santolan.ForeColor = System.Drawing.Color.White;
            this.rb5_Santolan.Location = new System.Drawing.Point(34, 243);
            this.rb5_Santolan.Name = "rb5_Santolan";
            this.rb5_Santolan.Padding = new System.Windows.Forms.Padding(30, 0, 30, 0);
            this.rb5_Santolan.Size = new System.Drawing.Size(155, 36);
            this.rb5_Santolan.TabIndex = 88;
            this.rb5_Santolan.TabStop = true;
            this.rb5_Santolan.Text = "Santolan";
            this.rb5_Santolan.UseVisualStyleBackColor = false;
            this.rb5_Santolan.CheckedChanged += new System.EventHandler(this.rb5_Santolan_CheckedChanged);
            // 
            // lbl5BoniAve
            // 
            this.lbl5BoniAve.AutoSize = true;
            this.lbl5BoniAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl5BoniAve.Location = new System.Drawing.Point(69, 28);
            this.lbl5BoniAve.Name = "lbl5BoniAve";
            this.lbl5BoniAve.Size = new System.Drawing.Size(80, 13);
            this.lbl5BoniAve.TabIndex = 95;
            this.lbl5BoniAve.Text = "BONI AVENUE";
            // 
            // rb5_BoniAve
            // 
            this.rb5_BoniAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb5_BoniAve.AutoSize = true;
            this.rb5_BoniAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb5_BoniAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb5_BoniAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb5_BoniAve.ForeColor = System.Drawing.Color.White;
            this.rb5_BoniAve.Location = new System.Drawing.Point(34, 48);
            this.rb5_BoniAve.Name = "rb5_BoniAve";
            this.rb5_BoniAve.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.rb5_BoniAve.Size = new System.Drawing.Size(156, 37);
            this.rb5_BoniAve.TabIndex = 94;
            this.rb5_BoniAve.TabStop = true;
            this.rb5_BoniAve.Text = "Boni Ave.";
            this.rb5_BoniAve.UseVisualStyleBackColor = false;
            this.rb5_BoniAve.CheckedChanged += new System.EventHandler(this.rb5_BoniAve_CheckedChanged);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(635, 439);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(248, 111);
            this.lblPrice.TabIndex = 71;
            this.lblPrice.Text = "0.00";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(654, 634);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(140, 33);
            this.button13.TabIndex = 72;
            this.button13.Text = "BACK";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click_1);
            // 
            // lbl_Guadalupe
            // 
            this.lbl_Guadalupe.AutoSize = true;
            this.lbl_Guadalupe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl_Guadalupe.Location = new System.Drawing.Point(240, 245);
            this.lbl_Guadalupe.Name = "lbl_Guadalupe";
            this.lbl_Guadalupe.Size = new System.Drawing.Size(73, 13);
            this.lbl_Guadalupe.TabIndex = 80;
            this.lbl_Guadalupe.Text = "GUADALUPE";
            // 
            // SGUADA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1370, 723);
            this.Controls.Add(this.lbl_Guadalupe);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel8);
            this.Controls.Add(label6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button14);
            this.Controls.Add(label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SGUADA";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Santolan";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Santolan_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lbl5QuezonAve;
        private System.Windows.Forms.RadioButton rb5_QuezonAve;
        private System.Windows.Forms.Label lbl5GMAKAMUNING;
        private System.Windows.Forms.RadioButton rb5_GMA;
        private System.Windows.Forms.Label lbl5NorthAve;
        private System.Windows.Forms.RadioButton rb5_NorthAve;
        private System.Windows.Forms.Label lbl5AranetaCubao;
        private System.Windows.Forms.RadioButton rb5_AranetaCubao;
        private System.Windows.Forms.Label lbl5ShawBoulevard;
        private System.Windows.Forms.RadioButton rb5_ShawBoulevard;
        private System.Windows.Forms.Label lbl5Ortigas;
        private System.Windows.Forms.RadioButton rb5_Ortigas;
        private System.Windows.Forms.Label lbl5Santolan;
        private System.Windows.Forms.RadioButton rb5_Santolan;
        private System.Windows.Forms.Label lbl5BoniAve;
        private System.Windows.Forms.RadioButton rb5_BoniAve;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label lbl_Guadalupe;
    }
}
﻿namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    partial class MRT7_TS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label5;
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblDC = new System.Windows.Forms.Label();
            this.rb_DC = new System.Windows.Forms.RadioButton();
            this.lblSJ = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.rb_TL = new System.Windows.Forms.RadioButton();
            this.lblMG = new System.Windows.Forms.Label();
            this.rb_MG = new System.Windows.Forms.RadioButton();
            this.lblBT = new System.Windows.Forms.Label();
            this.rb_BT = new System.Windows.Forms.RadioButton();
            this.lblDA = new System.Windows.Forms.Label();
            this.rb_DA = new System.Windows.Forms.RadioButton();
            this.lblTL = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblSH = new System.Windows.Forms.Label();
            this.rb_RG = new System.Windows.Forms.RadioButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.rb_QR = new System.Windows.Forms.RadioButton();
            this.lblQR = new System.Windows.Forms.Label();
            this.lblMA = new System.Windows.Forms.Label();
            this.rb_MA = new System.Windows.Forms.RadioButton();
            this.rb_SH = new System.Windows.Forms.RadioButton();
            this.lblRG = new System.Windows.Forms.Label();
            this.rb_SJ = new System.Windows.Forms.RadioButton();
            this.lbl_TS = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.lblPrice = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label2.Location = new System.Drawing.Point(741, 153);
            label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(351, 29);
            label2.TabIndex = 1;
            label2.Text = "SELECT YOUR DESTINATION";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label3.Location = new System.Drawing.Point(904, 373);
            label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(132, 29);
            label3.TabIndex = 3;
            label3.Text = "Ticket fare:";
            label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label5.Location = new System.Drawing.Point(249, 336);
            label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(219, 46);
            label5.TabIndex = 3;
            label5.Text = "STATIONS";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(29, 95);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1768, 191);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ITZeyyyyy_TRAIN_TICKET_SYSTEM.Properties.Resources.metro_station;
            this.pictureBox2.Location = new System.Drawing.Point(191, 42);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(257, 123);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(472, 63);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1064, 91);
            this.label1.TabIndex = 0;
            this.label1.Text = "TANDANG SORA STATION";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblDC);
            this.panel2.Controls.Add(this.rb_DC);
            this.panel2.Controls.Add(this.lblSJ);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.rb_TL);
            this.panel2.Controls.Add(this.lblMG);
            this.panel2.Controls.Add(this.rb_MG);
            this.panel2.Controls.Add(this.lblBT);
            this.panel2.Controls.Add(this.rb_SJ);
            this.panel2.Controls.Add(this.rb_BT);
            this.panel2.Controls.Add(this.lblDA);
            this.panel2.Controls.Add(this.rb_DA);
            this.panel2.Controls.Add(this.lblTL);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.lblSH);
            this.panel2.Controls.Add(this.rb_RG);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.rb_QR);
            this.panel2.Controls.Add(this.lblQR);
            this.panel2.Controls.Add(this.lblMA);
            this.panel2.Controls.Add(this.rb_MA);
            this.panel2.Controls.Add(this.rb_SH);
            this.panel2.Controls.Add(this.lblRG);
            this.panel2.Controls.Add(this.lbl_TS);
            this.panel2.Location = new System.Drawing.Point(81, 373);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(587, 528);
            this.panel2.TabIndex = 2;
            // 
            // lblDC
            // 
            this.lblDC.AutoSize = true;
            this.lblDC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblDC.Location = new System.Drawing.Point(103, 261);
            this.lblDC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDC.Name = "lblDC";
            this.lblDC.Size = new System.Drawing.Size(110, 17);
            this.lblDC.TabIndex = 42;
            this.lblDC.Text = "DONA CARMEN";
            // 
            // rb_DC
            // 
            this.rb_DC.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_DC.AutoSize = true;
            this.rb_DC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_DC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_DC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_DC.ForeColor = System.Drawing.Color.White;
            this.rb_DC.Location = new System.Drawing.Point(52, 277);
            this.rb_DC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_DC.Name = "rb_DC";
            this.rb_DC.Padding = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.rb_DC.Size = new System.Drawing.Size(202, 43);
            this.rb_DC.TabIndex = 47;
            this.rb_DC.TabStop = true;
            this.rb_DC.Text = "Dona Carmen";
            this.rb_DC.UseVisualStyleBackColor = false;
            this.rb_DC.CheckedChanged += new System.EventHandler(this.rb_DC_CheckedChanged);
            // 
            // lblSJ
            // 
            this.lblSJ.AutoSize = true;
            this.lblSJ.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblSJ.Location = new System.Drawing.Point(371, 340);
            this.lblSJ.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSJ.Name = "lblSJ";
            this.lblSJ.Size = new System.Drawing.Size(113, 17);
            this.lblSJ.TabIndex = 36;
            this.lblSJ.Text = "SJDM BULACAN";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel5.Location = new System.Drawing.Point(405, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(181, 1);
            this.panel5.TabIndex = 12;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel3.Location = new System.Drawing.Point(585, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1, 492);
            this.panel3.TabIndex = 11;
            // 
            // rb_TL
            // 
            this.rb_TL.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_TL.AutoSize = true;
            this.rb_TL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_TL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_TL.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_TL.ForeColor = System.Drawing.Color.White;
            this.rb_TL.Location = new System.Drawing.Point(317, 279);
            this.rb_TL.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_TL.Name = "rb_TL";
            this.rb_TL.Padding = new System.Windows.Forms.Padding(64, 0, 64, 0);
            this.rb_TL.Size = new System.Drawing.Size(207, 43);
            this.rb_TL.TabIndex = 45;
            this.rb_TL.TabStop = true;
            this.rb_TL.Text = "Tala";
            this.rb_TL.UseVisualStyleBackColor = false;
            this.rb_TL.CheckedChanged += new System.EventHandler(this.rb_TL_CheckedChanged);
            // 
            // lblMG
            // 
            this.lblMG.AutoSize = true;
            this.lblMG.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblMG.Location = new System.Drawing.Point(109, 191);
            this.lblMG.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMG.Name = "lblMG";
            this.lblMG.Size = new System.Drawing.Size(98, 17);
            this.lblMG.TabIndex = 40;
            this.lblMG.Text = "MANGGAHAN";
            // 
            // rb_MG
            // 
            this.rb_MG.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_MG.AutoSize = true;
            this.rb_MG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_MG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_MG.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_MG.Location = new System.Drawing.Point(52, 207);
            this.rb_MG.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_MG.Name = "rb_MG";
            this.rb_MG.Padding = new System.Windows.Forms.Padding(27, 0, 25, 0);
            this.rb_MG.Size = new System.Drawing.Size(203, 41);
            this.rb_MG.TabIndex = 39;
            this.rb_MG.TabStop = true;
            this.rb_MG.Text = "Manggahan";
            this.rb_MG.UseVisualStyleBackColor = false;
            this.rb_MG.CheckedChanged += new System.EventHandler(this.rb_MG_CheckedChanged);
            // 
            // lblBT
            // 
            this.lblBT.AutoSize = true;
            this.lblBT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblBT.Location = new System.Drawing.Point(119, 119);
            this.lblBT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBT.Name = "lblBT";
            this.lblBT.Size = new System.Drawing.Size(72, 17);
            this.lblBT.TabIndex = 38;
            this.lblBT.Text = "BATASAN";
            // 
            // rb_BT
            // 
            this.rb_BT.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_BT.AutoSize = true;
            this.rb_BT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_BT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_BT.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_BT.Location = new System.Drawing.Point(52, 135);
            this.rb_BT.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_BT.Name = "rb_BT";
            this.rb_BT.Padding = new System.Windows.Forms.Padding(49, 0, 49, 0);
            this.rb_BT.Size = new System.Drawing.Size(209, 41);
            this.rb_BT.TabIndex = 37;
            this.rb_BT.TabStop = true;
            this.rb_BT.Text = "Batasan";
            this.rb_BT.UseVisualStyleBackColor = false;
            this.rb_BT.CheckedChanged += new System.EventHandler(this.rb_BT_CheckedChanged);
            // 
            // lblDA
            // 
            this.lblDA.AutoSize = true;
            this.lblDA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblDA.Location = new System.Drawing.Point(107, 46);
            this.lblDA.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDA.Name = "lblDA";
            this.lblDA.Size = new System.Drawing.Size(106, 17);
            this.lblDA.TabIndex = 36;
            this.lblDA.Text = "DON ANTONIO";
            // 
            // rb_DA
            // 
            this.rb_DA.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_DA.AutoSize = true;
            this.rb_DA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_DA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_DA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_DA.ForeColor = System.Drawing.Color.White;
            this.rb_DA.Location = new System.Drawing.Point(52, 62);
            this.rb_DA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_DA.Name = "rb_DA";
            this.rb_DA.Padding = new System.Windows.Forms.Padding(23, 0, 24, 0);
            this.rb_DA.Size = new System.Drawing.Size(203, 41);
            this.rb_DA.TabIndex = 35;
            this.rb_DA.TabStop = true;
            this.rb_DA.Text = "Don Antonio";
            this.rb_DA.UseVisualStyleBackColor = false;
            this.rb_DA.CheckedChanged += new System.EventHandler(this.rb_DA_CheckedChanged);
            // 
            // lblTL
            // 
            this.lblTL.AutoSize = true;
            this.lblTL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblTL.Location = new System.Drawing.Point(399, 263);
            this.lblTL.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTL.Name = "lblTL";
            this.lblTL.Size = new System.Drawing.Size(43, 17);
            this.lblTL.TabIndex = 46;
            this.lblTL.Text = "TALA";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 492);
            this.panel4.TabIndex = 10;
            // 
            // lblSH
            // 
            this.lblSH.AutoSize = true;
            this.lblSH.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblSH.Location = new System.Drawing.Point(367, 192);
            this.lblSH.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSH.Name = "lblSH";
            this.lblSH.Size = new System.Drawing.Size(115, 17);
            this.lblSH.TabIndex = 34;
            this.lblSH.Text = "SACRED HEART";
            // 
            // rb_RG
            // 
            this.rb_RG.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_RG.AutoSize = true;
            this.rb_RG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_RG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_RG.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_RG.ForeColor = System.Drawing.Color.White;
            this.rb_RG.Location = new System.Drawing.Point(52, 356);
            this.rb_RG.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_RG.Name = "rb_RG";
            this.rb_RG.Padding = new System.Windows.Forms.Padding(31, 0, 31, 0);
            this.rb_RG.Size = new System.Drawing.Size(204, 43);
            this.rb_RG.TabIndex = 33;
            this.rb_RG.TabStop = true;
            this.rb_RG.Text = "Regalado";
            this.rb_RG.UseVisualStyleBackColor = false;
            this.rb_RG.CheckedChanged += new System.EventHandler(this.rb_RG_CheckedChanged);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel6.Location = new System.Drawing.Point(4, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(181, 1);
            this.panel6.TabIndex = 11;
            // 
            // rb_QR
            // 
            this.rb_QR.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_QR.AutoSize = true;
            this.rb_QR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_QR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_QR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_QR.ForeColor = System.Drawing.Color.White;
            this.rb_QR.Location = new System.Drawing.Point(317, 134);
            this.rb_QR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_QR.Name = "rb_QR";
            this.rb_QR.Padding = new System.Windows.Forms.Padding(47, 0, 45, 0);
            this.rb_QR.Size = new System.Drawing.Size(205, 43);
            this.rb_QR.TabIndex = 43;
            this.rb_QR.TabStop = true;
            this.rb_QR.Text = "Quirino";
            this.rb_QR.UseVisualStyleBackColor = false;
            this.rb_QR.CheckedChanged += new System.EventHandler(this.rb_QR_CheckedChanged);
            // 
            // lblQR
            // 
            this.lblQR.AutoSize = true;
            this.lblQR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblQR.Location = new System.Drawing.Point(385, 118);
            this.lblQR.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQR.Name = "lblQR";
            this.lblQR.Size = new System.Drawing.Size(66, 17);
            this.lblQR.TabIndex = 44;
            this.lblQR.Text = "QUIRINO";
            // 
            // lblMA
            // 
            this.lblMA.AutoSize = true;
            this.lblMA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblMA.Location = new System.Drawing.Point(371, 43);
            this.lblMA.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMA.Name = "lblMA";
            this.lblMA.Size = new System.Drawing.Size(112, 17);
            this.lblMA.TabIndex = 34;
            this.lblMA.Text = "MINDANAO AVE";
            // 
            // rb_MA
            // 
            this.rb_MA.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_MA.AutoSize = true;
            this.rb_MA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_MA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_MA.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_MA.ForeColor = System.Drawing.Color.White;
            this.rb_MA.Location = new System.Drawing.Point(317, 59);
            this.rb_MA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_MA.Name = "rb_MA";
            this.rb_MA.Size = new System.Drawing.Size(198, 43);
            this.rb_MA.TabIndex = 33;
            this.rb_MA.TabStop = true;
            this.rb_MA.Text = "Mindanao Ave";
            this.rb_MA.UseVisualStyleBackColor = false;
            this.rb_MA.CheckedChanged += new System.EventHandler(this.rb_MA_CheckedChanged);
            // 
            // rb_SH
            // 
            this.rb_SH.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_SH.AutoSize = true;
            this.rb_SH.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_SH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_SH.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_SH.ForeColor = System.Drawing.Color.White;
            this.rb_SH.Location = new System.Drawing.Point(317, 208);
            this.rb_SH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_SH.Name = "rb_SH";
            this.rb_SH.Padding = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.rb_SH.Size = new System.Drawing.Size(202, 43);
            this.rb_SH.TabIndex = 33;
            this.rb_SH.TabStop = true;
            this.rb_SH.Text = "Sacred Heart";
            this.rb_SH.UseVisualStyleBackColor = false;
            this.rb_SH.CheckedChanged += new System.EventHandler(this.rb_SH_CheckedChanged);
            // 
            // lblRG
            // 
            this.lblRG.AutoSize = true;
            this.lblRG.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblRG.Location = new System.Drawing.Point(111, 340);
            this.lblRG.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRG.Name = "lblRG";
            this.lblRG.Size = new System.Drawing.Size(85, 17);
            this.lblRG.TabIndex = 34;
            this.lblRG.Text = "REGALADO";
            // 
            // rb_SJ
            // 
            this.rb_SJ.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_SJ.AutoSize = true;
            this.rb_SJ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_SJ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_SJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_SJ.ForeColor = System.Drawing.Color.White;
            this.rb_SJ.Location = new System.Drawing.Point(317, 356);
            this.rb_SJ.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_SJ.Name = "rb_SJ";
            this.rb_SJ.Size = new System.Drawing.Size(205, 43);
            this.rb_SJ.TabIndex = 35;
            this.rb_SJ.TabStop = true;
            this.rb_SJ.Text = "SJDM Bulacan";
            this.rb_SJ.UseVisualStyleBackColor = false;
            this.rb_SJ.CheckedChanged += new System.EventHandler(this.rb_SJ_CheckedChanged);
            // 
            // lbl_TS
            // 
            this.lbl_TS.AutoSize = true;
            this.lbl_TS.Location = new System.Drawing.Point(341, 376);
            this.lbl_TS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_TS.Name = "lbl_TS";
            this.lbl_TS.Size = new System.Drawing.Size(165, 17);
            this.lbl_TS.TabIndex = 32;
            this.lbl_TS.Text = "MRT 7 TANDANG SORA";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1117, 489);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 54);
            this.label4.TabIndex = 8;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(1489, 725);
            this.button14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(187, 41);
            this.button14.TabIndex = 9;
            this.button14.Text = "CASH";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(845, 540);
            this.lblPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(310, 139);
            this.lblPrice.TabIndex = 30;
            this.lblPrice.Text = "0.00";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(909, 820);
            this.button13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(187, 41);
            this.button13.TabIndex = 7;
            this.button13.Text = "BACK";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Window;
            this.button1.Location = new System.Drawing.Point(1489, 820);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(187, 41);
            this.button1.TabIndex = 31;
            this.button1.Text = "CARD";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MRT7_TS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1827, 890);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(label5);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.label4);
            this.Controls.Add(label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MRT7_TS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "xfdxds";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.North_Ave_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lbl_TS;
        private System.Windows.Forms.Label lblMG;
        private System.Windows.Forms.RadioButton rb_MG;
        private System.Windows.Forms.Label lblBT;
        private System.Windows.Forms.RadioButton rb_BT;
        private System.Windows.Forms.Label lblDA;
        private System.Windows.Forms.RadioButton rb_DA;
        private System.Windows.Forms.Label lblTL;
        private System.Windows.Forms.RadioButton rb_TL;
        private System.Windows.Forms.Label lblSH;
        private System.Windows.Forms.Label lblQR;
        private System.Windows.Forms.RadioButton rb_SH;
        private System.Windows.Forms.RadioButton rb_QR;
        private System.Windows.Forms.Label lblMA;
        private System.Windows.Forms.Label lblRG;
        private System.Windows.Forms.RadioButton rb_MA;
        private System.Windows.Forms.Label lblDC;
        private System.Windows.Forms.RadioButton rb_RG;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.RadioButton rb_DC;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblSJ;
        private System.Windows.Forms.RadioButton rb_SJ;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SGUIDE : Form
    {
        public SGUIDE()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void SGUIDE_Load(object sender, EventArgs e)
        {
          
        }

        private void radiob1_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob1.Checked == true)
            {
                lblPlace.Text = " The first station in the South, Taft Avenue \n is connected  to Metropoint Mall and LRT-1’s EDSA Station.";
            }
        }

        private void radiob2_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob2.Checked == true)
            {
                lblPlace.Text = "Located near the ABS-CBN Broadcastong \n Corporation, Quezon Avenue station is Connected to Centris";
            }
        }

        private void radiob3_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob3.Checked == true)
            {
                lblPlace.Text = "This station is located near East Ave.\n and Timog Ave., PAG IBIG Fund, GMA Network Studios Annex,  \n and Department of Public Works and Highways. ";
            }
        }

        private void radiob4_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob4.Checked == true)
            {
                lblPlace.Text = "Located near Farmer’s Market, Araneta Coliseum, \n Gateway Mall, PNP General Hospital, and Quezon Medical Center,\n this station is also near the LRT-2’s (Purple Line) Cubao station. ";
            }
        }

        private void radiob5_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob5.Checked == true)
            {
                lblPlace.Text = "This station is located near Greenhills Shopping Center,\n Promenade, Xavier School, Immaculate Conception Academy (ICA),\n Camp Aguinaldo Golf Course, and Camp Crame.";
            }
        }

        private void radiob6_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob6.Checked == true)
            {
                lblPlace.Text = "One of the busiest stations in the morning, Ortigas station \n is near the Ortigas Business District and malls such as SM Megamall, \n Robinsons Galleria Mall, The Podium and St. Francis Square.";
            }
        }

        private void radiob7_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob7.Checked == true)
            {
                lblPlace.Text = "Connected to Shangri-La Mall, Shaw Boulevard station is located \n near Starmall Shaw,EDSA Shangri-La Hotel, \n EDSA Central Shopping Mall, and St. Francis Church.";
            }
        }

        private void radiob8_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob8.Checked == true)
            {
                lblPlace.Text = "This station is located near Pioneer Center,\n Robinsons Place Pioneer, The Legend Villas,  Horizon EDSA Hotel, \n and Globe Telecom Plaza Tower.";
            }
        }

        private void radiob9_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob9.Checked == true)
            {
                lblPlace.Text = "Located near Dr. Jose P. Rizal Ave.,\n Rockwell Center, and Our Lady of Guadalupe Memorial Chapel,\n this station is in front of Guadalupe Commercial Center.";
            }
        }

        private void radiob10_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob10.Checked == true)
            {
                lblPlace.Text = "Located North of Forbes Park Gate, Buendia \n station is near the Makati Business District.";
            }
        }

        private void radiob11_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob11.Checked == true)
            {
                lblPlace.Text = "Connected to SM Makati, Ayala station \n is located near Glorietta 3,  Glorietta 4, The Landmark, Rustan’s,\n Dusit Thani Hotel Manila, and InterContinental Hotel Manila.";
            }
        }

        private void radiob12_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob12.Checked == true)
            {
                lblPlace.Text = "Located North of Magallanes Flyover, this station is near \n the South Luzon Expressway (SLEX), Pasong Tamo Extension,\n Chino Roces Ave., and Don Bosco Makati.";
            }
        }

        private void radiob13_CheckedChanged(object sender, EventArgs e)
        {
            if (radiob13.Checked == true)
            {
                lblPlace.Text = " The last station in the Mrt North line, this station is \n connected to Trinoma Mall just across SM North EDSA";
            }
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void SELECT_Click(object sender, EventArgs e)
        {
            this.Hide();

            STAFT TA = new STAFT();

            TA.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMAGALLANES SMAG = new SMAGALLANES();

            SMAG.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
          this.Hide();

          SAYALA SA = new SAYALA();

          SA.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();

            SBUENDIA SB = new SBUENDIA();

            SB.ShowDialog();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();

            SGUADA SG = new SGUADA();

            SG.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();

            SBONI SO = new SBONI();

            SO.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();

            SSHAW SH = new SSHAW();

            SH.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();

            SORTIGAS ST = new SORTIGAS();

            ST.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();

            SSANTOLAN SS = new SSANTOLAN();

            SS.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
             this.Hide();

            SARANETA SR = new SARANETA();

            SR.ShowDialog();
        }

        private void button13_Click(object sender, EventArgs e)
        {

            this.Hide();

            SGMA SM = new SGMA();

            SM.ShowDialog();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            SQUEZONAVE SQ = new SQUEZONAVE();

            SQ.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            this.Hide();

            SNORTHAVE SN = new SNORTHAVE();

            SN.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

           SABOUTUS AU = new SABOUTUS();

            AU.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

            SGUIDE GD = new SGUIDE();

            GD.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();

            SCONTACTUS CU = new SCONTACTUS();

            CU.ShowDialog();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Main_home home = new Main_home();

            home.ShowDialog();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Araneta : Form
    {
        public Araneta()
        {
            InitializeComponent();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb4_Santolan.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToQuezonAve, fromNorthAveToQuezonAve, TotalPrice;

                NorthAveToQuezonAve = lbl4Santolan.Text;
                fromNorthAveToQuezonAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromNorthAveToQuezonAve(NorthAveToQuezonAve.ToString());
                GMA2.fromNorthAveToQuezonAve2(fromNorthAveToQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
            else if (rb4_Ortigas.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToQuezonAve, fromNorthAveToQuezonAve, TotalPrice;

                NorthAveToQuezonAve = lbl4Ortigas.Text;
                fromNorthAveToQuezonAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromNorthAveToQuezonAve(NorthAveToQuezonAve.ToString());
                GMA2.fromNorthAveToQuezonAve2(fromNorthAveToQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
            else if (rb4_ShawBoulevard.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToQuezonAve, fromNorthAveToQuezonAve, TotalPrice;

                NorthAveToQuezonAve = lbl4ShawBoulevard.Text;
                fromNorthAveToQuezonAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromNorthAveToQuezonAve(NorthAveToQuezonAve.ToString());
                GMA2.fromNorthAveToQuezonAve2(fromNorthAveToQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
            else if (rb4_BoniAve.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToQuezonAve, fromNorthAveToQuezonAve, TotalPrice;

                NorthAveToQuezonAve = lbl4BoniAve.Text;
                fromNorthAveToQuezonAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromNorthAveToQuezonAve(NorthAveToQuezonAve.ToString());
                GMA2.fromNorthAveToQuezonAve2(fromNorthAveToQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
            else if (rb4_Guadalupe.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToQuezonAve, fromNorthAveToQuezonAve, TotalPrice;

                NorthAveToQuezonAve = lbl4Guadalupe.Text;
                fromNorthAveToQuezonAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromNorthAveToQuezonAve(NorthAveToQuezonAve.ToString());
                GMA2.fromNorthAveToQuezonAve2(fromNorthAveToQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
            else if (rb4_Buendia.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToQuezonAve, fromNorthAveToQuezonAve, TotalPrice;

                NorthAveToQuezonAve = lbl4Buendia.Text;
                fromNorthAveToQuezonAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromNorthAveToQuezonAve(NorthAveToQuezonAve.ToString());
                GMA2.fromNorthAveToQuezonAve2(fromNorthAveToQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
            else if (rb4_AyalaAve.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToQuezonAve, fromNorthAveToQuezonAve, TotalPrice;

                NorthAveToQuezonAve = lbl4AyalaAve.Text;
                fromNorthAveToQuezonAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromNorthAveToQuezonAve(NorthAveToQuezonAve.ToString());
                GMA2.fromNorthAveToQuezonAve2(fromNorthAveToQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
            else if (rb4_Magallanes.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToQuezonAve, fromNorthAveToQuezonAve, TotalPrice;

                NorthAveToQuezonAve = lbl4Magallanes.Text;
                fromNorthAveToQuezonAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromNorthAveToQuezonAve(NorthAveToQuezonAve.ToString());
                GMA2.fromNorthAveToQuezonAve2(fromNorthAveToQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
            else if (rb4_TaftAve.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToQuezonAve, fromNorthAveToQuezonAve, TotalPrice;

                NorthAveToQuezonAve = lbl4TaftAve.Text;
                fromNorthAveToQuezonAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromNorthAveToQuezonAve(NorthAveToQuezonAve.ToString());
                GMA2.fromNorthAveToQuezonAve2(fromNorthAveToQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
        }

        private void Araneta_Load(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void rb4_Santolan_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_Santolan.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb4_Ortigas_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_Ortigas.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb4_ShawBoulevard_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_ShawBoulevard.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb4_BoniAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_BoniAve.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb4_Guadalupe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_Guadalupe.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb4_Buendia_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_Buendia.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb4_AyalaAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_AyalaAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb4_Magallanes_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_Magallanes.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb4_TaftAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_TaftAve.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }
    }
}

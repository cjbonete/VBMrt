﻿namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    partial class SAYALA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label6;
            this.label4 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_GMAKamuning = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl3QuezonAve = new System.Windows.Forms.Label();
            this.rb3_QuezonAve = new System.Windows.Forms.RadioButton();
            this.lbl3GMAKAMUNING = new System.Windows.Forms.Label();
            this.rb3_GMA = new System.Windows.Forms.RadioButton();
            this.lbl3NorthAve = new System.Windows.Forms.Label();
            this.rb3_NorthAve = new System.Windows.Forms.RadioButton();
            this.rb3_Guadalupe = new System.Windows.Forms.RadioButton();
            this.lbl3ShawBoulevard = new System.Windows.Forms.Label();
            this.lbl3Ortigas = new System.Windows.Forms.Label();
            this.rb3_ShawBoulevard = new System.Windows.Forms.RadioButton();
            this.rb3_Ortigas = new System.Windows.Forms.RadioButton();
            this.lbl3Santolan = new System.Windows.Forms.Label();
            this.rb3_Santolan = new System.Windows.Forms.RadioButton();
            this.lbl3Buendia = new System.Windows.Forms.Label();
            this.rb3_Buendia = new System.Windows.Forms.RadioButton();
            this.lbl3BoniAve = new System.Windows.Forms.Label();
            this.rb3_BoniAve = new System.Windows.Forms.RadioButton();
            this.lbl3AranetaCubao = new System.Windows.Forms.Label();
            this.rb3_AranetaCubao = new System.Windows.Forms.RadioButton();
            this.lbl3Guadalupe = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.lbl_Ayala = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label2.Location = new System.Drawing.Point(556, 118);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(272, 24);
            label2.TabIndex = 1;
            label2.Text = "SELECT YOUR DESTINATION";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label3.Location = new System.Drawing.Point(668, 301);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(101, 24);
            label3.TabIndex = 12;
            label3.Text = "Ticket fare:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label6.Location = new System.Drawing.Point(180, 255);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(178, 37);
            label6.TabIndex = 36;
            label6.Text = "STATIONS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(828, 395);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 42);
            this.label4.TabIndex = 16;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(1167, 633);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(140, 33);
            this.button14.TabIndex = 17;
            this.button14.Text = "PROCEED";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 75);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1326, 155);
            this.panel1.TabIndex = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ITZeyyyyy_TRAIN_TICKET_SYSTEM.Properties.Resources.metro_station;
            this.pictureBox2.Location = new System.Drawing.Point(143, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(193, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(321, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(919, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "AYALA KAMUNING STATION";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_GMAKamuning
            // 
            this.lbl_GMAKamuning.AutoSize = true;
            this.lbl_GMAKamuning.ForeColor = System.Drawing.Color.White;
            this.lbl_GMAKamuning.Location = new System.Drawing.Point(62, 127);
            this.lbl_GMAKamuning.Name = "lbl_GMAKamuning";
            this.lbl_GMAKamuning.Size = new System.Drawing.Size(92, 13);
            this.lbl_GMAKamuning.TabIndex = 41;
            this.lbl_GMAKamuning.Text = "GMA KAMUNING";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel5.Location = new System.Drawing.Point(50, 285);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 400);
            this.panel5.TabIndex = 40;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel9.Location = new System.Drawing.Point(462, 285);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1, 400);
            this.panel9.TabIndex = 39;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel4.Location = new System.Drawing.Point(50, 285);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(136, 1);
            this.panel4.TabIndex = 38;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel8.Location = new System.Drawing.Point(327, 285);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(136, 1);
            this.panel8.TabIndex = 37;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl3QuezonAve);
            this.panel2.Controls.Add(this.rb3_QuezonAve);
            this.panel2.Controls.Add(this.lbl3GMAKAMUNING);
            this.panel2.Controls.Add(this.rb3_GMA);
            this.panel2.Controls.Add(this.lbl3NorthAve);
            this.panel2.Controls.Add(this.rb3_NorthAve);
            this.panel2.Controls.Add(this.rb3_Guadalupe);
            this.panel2.Controls.Add(this.lbl3ShawBoulevard);
            this.panel2.Controls.Add(this.lbl_GMAKamuning);
            this.panel2.Controls.Add(this.lbl3Ortigas);
            this.panel2.Controls.Add(this.rb3_ShawBoulevard);
            this.panel2.Controls.Add(this.rb3_Ortigas);
            this.panel2.Controls.Add(this.lbl3Santolan);
            this.panel2.Controls.Add(this.rb3_Santolan);
            this.panel2.Controls.Add(this.lbl3Buendia);
            this.panel2.Controls.Add(this.rb3_Buendia);
            this.panel2.Controls.Add(this.lbl3BoniAve);
            this.panel2.Controls.Add(this.rb3_BoniAve);
            this.panel2.Controls.Add(this.lbl3AranetaCubao);
            this.panel2.Controls.Add(this.rb3_AranetaCubao);
            this.panel2.Controls.Add(this.lbl3Guadalupe);
            this.panel2.Location = new System.Drawing.Point(50, 285);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(413, 429);
            this.panel2.TabIndex = 35;
            // 
            // lbl3QuezonAve
            // 
            this.lbl3QuezonAve.AutoSize = true;
            this.lbl3QuezonAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl3QuezonAve.Location = new System.Drawing.Point(254, 217);
            this.lbl3QuezonAve.Name = "lbl3QuezonAve";
            this.lbl3QuezonAve.Size = new System.Drawing.Size(100, 13);
            this.lbl3QuezonAve.TabIndex = 75;
            this.lbl3QuezonAve.Text = "QUEZON AVENUE";
            // 
            // rb3_QuezonAve
            // 
            this.rb3_QuezonAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb3_QuezonAve.AutoSize = true;
            this.rb3_QuezonAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb3_QuezonAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb3_QuezonAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb3_QuezonAve.ForeColor = System.Drawing.Color.White;
            this.rb3_QuezonAve.Location = new System.Drawing.Point(229, 237);
            this.rb3_QuezonAve.Name = "rb3_QuezonAve";
            this.rb3_QuezonAve.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb3_QuezonAve.Size = new System.Drawing.Size(158, 37);
            this.rb3_QuezonAve.TabIndex = 74;
            this.rb3_QuezonAve.TabStop = true;
            this.rb3_QuezonAve.Text = "Quezon Ave.";
            this.rb3_QuezonAve.UseVisualStyleBackColor = false;
            this.rb3_QuezonAve.CheckedChanged += new System.EventHandler(this.rb3_QuezonAve_CheckedChanged);
            // 
            // lbl3GMAKAMUNING
            // 
            this.lbl3GMAKAMUNING.AutoSize = true;
            this.lbl3GMAKAMUNING.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl3GMAKAMUNING.Location = new System.Drawing.Point(260, 155);
            this.lbl3GMAKAMUNING.Name = "lbl3GMAKAMUNING";
            this.lbl3GMAKAMUNING.Size = new System.Drawing.Size(92, 13);
            this.lbl3GMAKAMUNING.TabIndex = 77;
            this.lbl3GMAKAMUNING.Text = "GMA KAMUNING";
            // 
            // rb3_GMA
            // 
            this.rb3_GMA.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb3_GMA.AutoSize = true;
            this.rb3_GMA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb3_GMA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb3_GMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb3_GMA.ForeColor = System.Drawing.Color.White;
            this.rb3_GMA.Location = new System.Drawing.Point(228, 177);
            this.rb3_GMA.Name = "rb3_GMA";
            this.rb3_GMA.Size = new System.Drawing.Size(156, 36);
            this.rb3_GMA.TabIndex = 76;
            this.rb3_GMA.TabStop = true;
            this.rb3_GMA.Text = "GMA Kamuning";
            this.rb3_GMA.UseVisualStyleBackColor = false;
            this.rb3_GMA.CheckedChanged += new System.EventHandler(this.rb3_GMA_CheckedChanged);
            // 
            // lbl3NorthAve
            // 
            this.lbl3NorthAve.AutoSize = true;
            this.lbl3NorthAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl3NorthAve.Location = new System.Drawing.Point(262, 288);
            this.lbl3NorthAve.Name = "lbl3NorthAve";
            this.lbl3NorthAve.Size = new System.Drawing.Size(93, 13);
            this.lbl3NorthAve.TabIndex = 73;
            this.lbl3NorthAve.Text = "NORTH AVENUE";
            // 
            // rb3_NorthAve
            // 
            this.rb3_NorthAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb3_NorthAve.AutoSize = true;
            this.rb3_NorthAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb3_NorthAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb3_NorthAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb3_NorthAve.ForeColor = System.Drawing.Color.White;
            this.rb3_NorthAve.Location = new System.Drawing.Point(227, 306);
            this.rb3_NorthAve.Name = "rb3_NorthAve";
            this.rb3_NorthAve.Padding = new System.Windows.Forms.Padding(17, 0, 17, 0);
            this.rb3_NorthAve.Size = new System.Drawing.Size(159, 37);
            this.rb3_NorthAve.TabIndex = 72;
            this.rb3_NorthAve.TabStop = true;
            this.rb3_NorthAve.Text = "North Ave.";
            this.rb3_NorthAve.UseVisualStyleBackColor = false;
            this.rb3_NorthAve.CheckedChanged += new System.EventHandler(this.rb3_NorthAve_CheckedChanged);
            // 
            // rb3_Guadalupe
            // 
            this.rb3_Guadalupe.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb3_Guadalupe.AutoSize = true;
            this.rb3_Guadalupe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb3_Guadalupe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb3_Guadalupe.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb3_Guadalupe.ForeColor = System.Drawing.Color.White;
            this.rb3_Guadalupe.Location = new System.Drawing.Point(33, 113);
            this.rb3_Guadalupe.Name = "rb3_Guadalupe";
            this.rb3_Guadalupe.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.rb3_Guadalupe.Size = new System.Drawing.Size(159, 37);
            this.rb3_Guadalupe.TabIndex = 71;
            this.rb3_Guadalupe.TabStop = true;
            this.rb3_Guadalupe.Text = "Guadalupe";
            this.rb3_Guadalupe.UseVisualStyleBackColor = false;
            this.rb3_Guadalupe.CheckedChanged += new System.EventHandler(this.rb3_Guadalupe_CheckedChanged);
            // 
            // lbl3ShawBoulevard
            // 
            this.lbl3ShawBoulevard.AutoSize = true;
            this.lbl3ShawBoulevard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl3ShawBoulevard.Location = new System.Drawing.Point(57, 220);
            this.lbl3ShawBoulevard.Name = "lbl3ShawBoulevard";
            this.lbl3ShawBoulevard.Size = new System.Drawing.Size(109, 13);
            this.lbl3ShawBoulevard.TabIndex = 64;
            this.lbl3ShawBoulevard.Text = "SHAW BOULEVARD";
            // 
            // lbl3Ortigas
            // 
            this.lbl3Ortigas.AutoSize = true;
            this.lbl3Ortigas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl3Ortigas.Location = new System.Drawing.Point(79, 287);
            this.lbl3Ortigas.Name = "lbl3Ortigas";
            this.lbl3Ortigas.Size = new System.Drawing.Size(55, 13);
            this.lbl3Ortigas.TabIndex = 62;
            this.lbl3Ortigas.Text = "ORTIGAS";
            // 
            // rb3_ShawBoulevard
            // 
            this.rb3_ShawBoulevard.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb3_ShawBoulevard.AutoSize = true;
            this.rb3_ShawBoulevard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb3_ShawBoulevard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb3_ShawBoulevard.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb3_ShawBoulevard.ForeColor = System.Drawing.Color.White;
            this.rb3_ShawBoulevard.Location = new System.Drawing.Point(36, 241);
            this.rb3_ShawBoulevard.Name = "rb3_ShawBoulevard";
            this.rb3_ShawBoulevard.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.rb3_ShawBoulevard.Size = new System.Drawing.Size(155, 36);
            this.rb3_ShawBoulevard.TabIndex = 63;
            this.rb3_ShawBoulevard.TabStop = true;
            this.rb3_ShawBoulevard.Text = "Shaw Blvd.";
            this.rb3_ShawBoulevard.UseVisualStyleBackColor = false;
            this.rb3_ShawBoulevard.CheckedChanged += new System.EventHandler(this.rb3_ShawBoulevard_CheckedChanged);
            // 
            // rb3_Ortigas
            // 
            this.rb3_Ortigas.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb3_Ortigas.AutoSize = true;
            this.rb3_Ortigas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb3_Ortigas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb3_Ortigas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb3_Ortigas.ForeColor = System.Drawing.Color.White;
            this.rb3_Ortigas.Location = new System.Drawing.Point(36, 306);
            this.rb3_Ortigas.Name = "rb3_Ortigas";
            this.rb3_Ortigas.Padding = new System.Windows.Forms.Padding(37, 0, 37, 0);
            this.rb3_Ortigas.Size = new System.Drawing.Size(155, 36);
            this.rb3_Ortigas.TabIndex = 61;
            this.rb3_Ortigas.TabStop = true;
            this.rb3_Ortigas.Text = "Ortigas";
            this.rb3_Ortigas.UseVisualStyleBackColor = false;
            this.rb3_Ortigas.CheckedChanged += new System.EventHandler(this.rb3_Ortigas_CheckedChanged);
            // 
            // lbl3Santolan
            // 
            this.lbl3Santolan.AutoSize = true;
            this.lbl3Santolan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl3Santolan.Location = new System.Drawing.Point(274, 23);
            this.lbl3Santolan.Name = "lbl3Santolan";
            this.lbl3Santolan.Size = new System.Drawing.Size(65, 13);
            this.lbl3Santolan.TabIndex = 60;
            this.lbl3Santolan.Text = "SANTOLAN";
            // 
            // rb3_Santolan
            // 
            this.rb3_Santolan.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb3_Santolan.AutoSize = true;
            this.rb3_Santolan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb3_Santolan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb3_Santolan.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb3_Santolan.ForeColor = System.Drawing.Color.White;
            this.rb3_Santolan.Location = new System.Drawing.Point(231, 43);
            this.rb3_Santolan.Name = "rb3_Santolan";
            this.rb3_Santolan.Padding = new System.Windows.Forms.Padding(30, 0, 30, 0);
            this.rb3_Santolan.Size = new System.Drawing.Size(155, 36);
            this.rb3_Santolan.TabIndex = 59;
            this.rb3_Santolan.TabStop = true;
            this.rb3_Santolan.Text = "Santolan";
            this.rb3_Santolan.UseVisualStyleBackColor = false;
            this.rb3_Santolan.CheckedChanged += new System.EventHandler(this.rb3_Santolan_CheckedChanged);
            // 
            // lbl3Buendia
            // 
            this.lbl3Buendia.AutoSize = true;
            this.lbl3Buendia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl3Buendia.Location = new System.Drawing.Point(82, 23);
            this.lbl3Buendia.Name = "lbl3Buendia";
            this.lbl3Buendia.Size = new System.Drawing.Size(55, 13);
            this.lbl3Buendia.TabIndex = 56;
            this.lbl3Buendia.Text = "BUENDIA";
            // 
            // rb3_Buendia
            // 
            this.rb3_Buendia.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb3_Buendia.AutoSize = true;
            this.rb3_Buendia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb3_Buendia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb3_Buendia.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb3_Buendia.ForeColor = System.Drawing.Color.White;
            this.rb3_Buendia.Location = new System.Drawing.Point(32, 43);
            this.rb3_Buendia.Name = "rb3_Buendia";
            this.rb3_Buendia.Padding = new System.Windows.Forms.Padding(28, 0, 28, 0);
            this.rb3_Buendia.Size = new System.Drawing.Size(159, 37);
            this.rb3_Buendia.TabIndex = 51;
            this.rb3_Buendia.TabStop = true;
            this.rb3_Buendia.Text = "Buendia";
            this.rb3_Buendia.UseVisualStyleBackColor = false;
            this.rb3_Buendia.CheckedChanged += new System.EventHandler(this.rb3_Buendia_CheckedChanged);
            // 
            // lbl3BoniAve
            // 
            this.lbl3BoniAve.AutoSize = true;
            this.lbl3BoniAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl3BoniAve.Location = new System.Drawing.Point(67, 155);
            this.lbl3BoniAve.Name = "lbl3BoniAve";
            this.lbl3BoniAve.Size = new System.Drawing.Size(80, 13);
            this.lbl3BoniAve.TabIndex = 66;
            this.lbl3BoniAve.Text = "BONI AVENUE";
            // 
            // rb3_BoniAve
            // 
            this.rb3_BoniAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb3_BoniAve.AutoSize = true;
            this.rb3_BoniAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb3_BoniAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb3_BoniAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb3_BoniAve.ForeColor = System.Drawing.Color.White;
            this.rb3_BoniAve.Location = new System.Drawing.Point(36, 171);
            this.rb3_BoniAve.Name = "rb3_BoniAve";
            this.rb3_BoniAve.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.rb3_BoniAve.Size = new System.Drawing.Size(156, 37);
            this.rb3_BoniAve.TabIndex = 65;
            this.rb3_BoniAve.TabStop = true;
            this.rb3_BoniAve.Text = "Boni Ave.";
            this.rb3_BoniAve.UseVisualStyleBackColor = false;
            this.rb3_BoniAve.CheckedChanged += new System.EventHandler(this.rb3_BoniAve_CheckedChanged);
            // 
            // lbl3AranetaCubao
            // 
            this.lbl3AranetaCubao.AutoSize = true;
            this.lbl3AranetaCubao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl3AranetaCubao.Location = new System.Drawing.Point(260, 91);
            this.lbl3AranetaCubao.Name = "lbl3AranetaCubao";
            this.lbl3AranetaCubao.Size = new System.Drawing.Size(98, 13);
            this.lbl3AranetaCubao.TabIndex = 55;
            this.lbl3AranetaCubao.Text = "ARANETA CUBAO";
            // 
            // rb3_AranetaCubao
            // 
            this.rb3_AranetaCubao.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb3_AranetaCubao.AutoSize = true;
            this.rb3_AranetaCubao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb3_AranetaCubao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb3_AranetaCubao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb3_AranetaCubao.ForeColor = System.Drawing.Color.White;
            this.rb3_AranetaCubao.Location = new System.Drawing.Point(229, 112);
            this.rb3_AranetaCubao.Name = "rb3_AranetaCubao";
            this.rb3_AranetaCubao.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb3_AranetaCubao.Size = new System.Drawing.Size(158, 36);
            this.rb3_AranetaCubao.TabIndex = 53;
            this.rb3_AranetaCubao.TabStop = true;
            this.rb3_AranetaCubao.Text = "Araneta Cubao";
            this.rb3_AranetaCubao.UseVisualStyleBackColor = false;
            this.rb3_AranetaCubao.CheckedChanged += new System.EventHandler(this.rb3_AranetaCubao_CheckedChanged);
            // 
            // lbl3Guadalupe
            // 
            this.lbl3Guadalupe.AutoSize = true;
            this.lbl3Guadalupe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl3Guadalupe.Location = new System.Drawing.Point(82, 91);
            this.lbl3Guadalupe.Name = "lbl3Guadalupe";
            this.lbl3Guadalupe.Size = new System.Drawing.Size(73, 13);
            this.lbl3Guadalupe.TabIndex = 58;
            this.lbl3Guadalupe.Text = "GUADALUPE";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(618, 442);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(248, 111);
            this.lblPrice.TabIndex = 42;
            this.lblPrice.Text = "0.00";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(672, 633);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(140, 33);
            this.button13.TabIndex = 43;
            this.button13.Text = "BACK";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click_1);
            // 
            // lbl_Ayala
            // 
            this.lbl_Ayala.AutoSize = true;
            this.lbl_Ayala.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl_Ayala.Location = new System.Drawing.Point(241, 239);
            this.lbl_Ayala.Name = "lbl_Ayala";
            this.lbl_Ayala.Size = new System.Drawing.Size(41, 13);
            this.lbl_Ayala.TabIndex = 78;
            this.lbl_Ayala.Text = "AYALA";
            // 
            // SAYALA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1370, 723);
            this.Controls.Add(this.lbl_Ayala);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel8);
            this.Controls.Add(label6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button14);
            this.Controls.Add(label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SAYALA";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GMA";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.GMA_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_GMAKamuning;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl3ShawBoulevard;
        private System.Windows.Forms.RadioButton rb3_ShawBoulevard;
        private System.Windows.Forms.Label lbl3Ortigas;
        private System.Windows.Forms.RadioButton rb3_Ortigas;
        private System.Windows.Forms.Label lbl3Santolan;
        private System.Windows.Forms.RadioButton rb3_Santolan;
        private System.Windows.Forms.Label lbl3Buendia;
        private System.Windows.Forms.Label lbl3AranetaCubao;
        private System.Windows.Forms.Label lbl3Guadalupe;
        private System.Windows.Forms.RadioButton rb3_AranetaCubao;
        private System.Windows.Forms.RadioButton rb3_Buendia;
        private System.Windows.Forms.Label lbl3BoniAve;
        private System.Windows.Forms.RadioButton rb3_BoniAve;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.RadioButton rb3_Guadalupe;
        private System.Windows.Forms.Label lbl3NorthAve;
        private System.Windows.Forms.RadioButton rb3_NorthAve;
        private System.Windows.Forms.Label lbl3QuezonAve;
        private System.Windows.Forms.RadioButton rb3_QuezonAve;
        private System.Windows.Forms.Label lbl3GMAKAMUNING;
        private System.Windows.Forms.RadioButton rb3_GMA;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label lbl_Ayala;
    }
}
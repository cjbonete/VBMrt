﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class MRT7_BT : Form
    {



        public MRT7_BT()
        {
            InitializeComponent();
        }

        private void North_Ave_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form11 frm11 = new Form11();

            frm11.ShowDialog();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb_MG.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToMangga, fromNorthAveToMangga, TotalPrice;

                NorthAveToMangga = lblMG.Text;
                fromNorthAveToMangga = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToQcCircle(NorthAveToMangga.ToString());
                GMA2.fromNorthAveToQcCircle2(fromNorthAveToMangga.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
            else if (rb_DC.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToDonaC, fromNorthAveToDonaC, TotalPrice;

                NorthAveToDonaC = lblDC.Text;
                fromNorthAveToDonaC = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToQcCircle(NorthAveToDonaC.ToString());
                GMA2.fromNorthAveToQcCircle2(fromNorthAveToDonaC.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
            else if (rb_RG.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToRegalado, fromNorthAveToRegalado, TotalPrice;

                NorthAveToRegalado = lblRG.Text;
                fromNorthAveToRegalado = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToQcCircle(NorthAveToRegalado.ToString());
                GMA2.fromNorthAveToQcCircle2(fromNorthAveToRegalado.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
            else if (rb_MA.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToMAve, fromNorthAveToMAve, TotalPrice;

                NorthAveToMAve = lblMA.Text;
                fromNorthAveToMAve = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToQcCircle(NorthAveToMAve.ToString());
                GMA2.fromNorthAveToQcCircle2(fromNorthAveToMAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
            else if (rb_QR.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToQuirino, fromNorthAveToQuirino, TotalPrice;

                NorthAveToQuirino = lblQR.Text;
                fromNorthAveToQuirino = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToQcCircle(NorthAveToQuirino.ToString());
                GMA2.fromNorthAveToQcCircle2(fromNorthAveToQuirino.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }

            else if (rb_SH.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToSH, fromNorthAveToSH, TotalPrice;

                NorthAveToSH = lblSH.Text;
                fromNorthAveToSH = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToQcCircle(NorthAveToSH.ToString());
                GMA2.fromNorthAveToQcCircle2(fromNorthAveToSH.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
            else if (rb_TL.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveTotala, fromNorthAveTotala, TotalPrice;

                NorthAveTotala = lblTL.Text;
                fromNorthAveTotala = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToQcCircle(NorthAveTotala.ToString());
                GMA2.fromNorthAveToQcCircle2(fromNorthAveTotala.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
            else if (rb_SJ.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToSJDM, fromNorthAveToSJDM, TotalPrice;

                NorthAveToSJDM = lblSJ.Text;
                fromNorthAveToSJDM = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToQcCircle(NorthAveToSJDM.ToString());
                GMA2.fromNorthAveToQcCircle2(fromNorthAveToSJDM.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            } 
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form11 frm11 = new Form11();

            frm11.ShowDialog();
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void rb_MG_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_MG.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb_DC_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_DC.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb_RG_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_RG.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb_MA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_MA.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb_QR_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_QR.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb_SH_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_SH.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb_TL_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_TL.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb_SJ_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_SJ.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }
    }
}

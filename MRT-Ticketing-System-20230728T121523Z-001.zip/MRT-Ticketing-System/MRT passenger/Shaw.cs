﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Shaw : Form
    {
        public Shaw()
        {
            InitializeComponent();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Shaw_Load(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
           if (rb7_BoniAve.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl7BoniAve.Text;
                fromQuezonAve = lbl_Shaw.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();

                lblTot GMA2 = new lblTot();
                GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());
                GMA2.ShowDialog();
            }
           else if (rb7_Guadalupe.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl7Guadalupe.Text;
               fromQuezonAve = lbl_Shaw.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb7_Buendia.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl7Buendia.Text;
               fromQuezonAve = lbl_Shaw.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb7_AyalaAve.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl7AyalaAve.Text;
               fromQuezonAve = lbl_Shaw.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb7_Magallanes.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl7Magallanes.Text;
               fromQuezonAve = lbl_Shaw.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb7_TaftAve.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl7TaftAve.Text;
               fromQuezonAve = lbl_Shaw.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void rb7_BoniAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb7_BoniAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb7_Guadalupe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb7_Guadalupe.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb7_Buendia_CheckedChanged(object sender, EventArgs e)
        {
            if (rb7_Buendia.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb7_AyalaAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb7_AyalaAve.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb7_Magallanes_CheckedChanged(object sender, EventArgs e)
        {
            if (rb7_Magallanes.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb7_TaftAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb7_TaftAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }
    }
}

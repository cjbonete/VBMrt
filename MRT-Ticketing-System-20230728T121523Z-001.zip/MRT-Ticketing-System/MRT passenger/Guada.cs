﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Guada : Form
    {
        public Guada()
        {
            InitializeComponent();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
           if (rb9_Buendia.Checked == true && lblPrice.Text != "0.00")
          {
              string QuezonAve, fromQuezonAve, TotalPrice;

              QuezonAve = lbl9Buendia.Text;
              fromQuezonAve = lbl_Guadalupe.Text;
              TotalPrice = lblPrice.Text;

              this.Hide();

              lblTot GMA2 = new lblTot();
              GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
              GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
              GMA2.TotalPrice(TotalPrice.ToString());
              GMA2.ShowDialog();
          }
           else if (rb9_AyalaAve.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl9AyalaAve.Text;
               fromQuezonAve = lbl_Guadalupe.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb9_Magallanes.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl9Magallanes.Text;
               fromQuezonAve = lbl_Guadalupe.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb9_TaftAve.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl9TaftAve.Text;
               fromQuezonAve = lbl_Guadalupe.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void rb9_Buendia_CheckedChanged(object sender, EventArgs e)
        {
            if (rb9_Buendia.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb9_AyalaAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb9_AyalaAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb9_Magallanes_CheckedChanged(object sender, EventArgs e)
        {
            if (rb9_Magallanes.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb9_TaftAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb9_TaftAve.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }
    }
}

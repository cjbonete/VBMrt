﻿namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    partial class Quezon_Ave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label3;
            this.label4 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rb2_BoniAve = new System.Windows.Forms.RadioButton();
            this.lbl_QuezonAve = new System.Windows.Forms.Label();
            this.lbl2TaftAve = new System.Windows.Forms.Label();
            this.lbl2ShawBoulevard = new System.Windows.Forms.Label();
            this.rb2_TaftAve = new System.Windows.Forms.RadioButton();
            this.rb2_ShawBoulevard = new System.Windows.Forms.RadioButton();
            this.lbl2Magallanes = new System.Windows.Forms.Label();
            this.lbl2Ortigas = new System.Windows.Forms.Label();
            this.lbl2AyalaAve = new System.Windows.Forms.Label();
            this.rb2_Ortigas = new System.Windows.Forms.RadioButton();
            this.rb2_Magallanes = new System.Windows.Forms.RadioButton();
            this.lbl2Santolan = new System.Windows.Forms.Label();
            this.rb2_AyalaAve = new System.Windows.Forms.RadioButton();
            this.rb2_Santolan = new System.Windows.Forms.RadioButton();
            this.lbl2Buendia = new System.Windows.Forms.Label();
            this.lbl2AranetaCubao = new System.Windows.Forms.Label();
            this.lbl2Guadalupe = new System.Windows.Forms.Label();
            this.rb2_AranetaCubao = new System.Windows.Forms.RadioButton();
            this.rb2_Buendia = new System.Windows.Forms.RadioButton();
            this.lbl2BoniAve = new System.Windows.Forms.Label();
            this.rb2_Guadalupe = new System.Windows.Forms.RadioButton();
            this.lbl2GMAKAMUNING = new System.Windows.Forms.Label();
            this.rb2_GMA = new System.Windows.Forms.RadioButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblPrice = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            label2 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label2.Location = new System.Drawing.Point(556, 118);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(272, 24);
            label2.TabIndex = 1;
            label2.Text = "SELECT YOUR DESTINATION";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label5.Location = new System.Drawing.Point(175, 284);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(178, 37);
            label5.TabIndex = 13;
            label5.Text = "STATIONS";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label3.Location = new System.Drawing.Point(662, 314);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(101, 24);
            label3.TabIndex = 12;
            label3.Text = "Ticket fare:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(822, 408);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 42);
            this.label4.TabIndex = 16;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(1165, 690);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(140, 33);
            this.button14.TabIndex = 17;
            this.button14.Text = "PROCEED";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(23, 88);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1326, 155);
            this.panel1.TabIndex = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ITZeyyyyy_TRAIN_TICKET_SYSTEM.Properties.Resources.metro_station;
            this.pictureBox2.Location = new System.Drawing.Point(143, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(193, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(321, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(903, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "QUEZON AVENUE STATION";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rb2_BoniAve);
            this.panel2.Controls.Add(this.lbl_QuezonAve);
            this.panel2.Controls.Add(this.lbl2TaftAve);
            this.panel2.Controls.Add(this.lbl2ShawBoulevard);
            this.panel2.Controls.Add(this.rb2_TaftAve);
            this.panel2.Controls.Add(this.rb2_ShawBoulevard);
            this.panel2.Controls.Add(this.lbl2Magallanes);
            this.panel2.Controls.Add(this.lbl2Ortigas);
            this.panel2.Controls.Add(this.lbl2AyalaAve);
            this.panel2.Controls.Add(this.rb2_Ortigas);
            this.panel2.Controls.Add(this.rb2_Magallanes);
            this.panel2.Controls.Add(this.lbl2Santolan);
            this.panel2.Controls.Add(this.rb2_AyalaAve);
            this.panel2.Controls.Add(this.rb2_Santolan);
            this.panel2.Controls.Add(this.lbl2Buendia);
            this.panel2.Controls.Add(this.lbl2AranetaCubao);
            this.panel2.Controls.Add(this.lbl2Guadalupe);
            this.panel2.Controls.Add(this.rb2_AranetaCubao);
            this.panel2.Controls.Add(this.rb2_Buendia);
            this.panel2.Controls.Add(this.lbl2BoniAve);
            this.panel2.Controls.Add(this.rb2_Guadalupe);
            this.panel2.Controls.Add(this.lbl2GMAKAMUNING);
            this.panel2.Controls.Add(this.rb2_GMA);
            this.panel2.Location = new System.Drawing.Point(45, 314);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(413, 429);
            this.panel2.TabIndex = 11;
            // 
            // rb2_BoniAve
            // 
            this.rb2_BoniAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb2_BoniAve.AutoSize = true;
            this.rb2_BoniAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb2_BoniAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb2_BoniAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb2_BoniAve.ForeColor = System.Drawing.Color.White;
            this.rb2_BoniAve.Location = new System.Drawing.Point(240, 43);
            this.rb2_BoniAve.Name = "rb2_BoniAve";
            this.rb2_BoniAve.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.rb2_BoniAve.Size = new System.Drawing.Size(156, 37);
            this.rb2_BoniAve.TabIndex = 71;
            this.rb2_BoniAve.TabStop = true;
            this.rb2_BoniAve.Text = "Boni Ave.";
            this.rb2_BoniAve.UseVisualStyleBackColor = false;
            this.rb2_BoniAve.CheckedChanged += new System.EventHandler(this.rb2_BoniAve_CheckedChanged);
            // 
            // lbl_QuezonAve
            // 
            this.lbl_QuezonAve.AutoSize = true;
            this.lbl_QuezonAve.ForeColor = System.Drawing.Color.White;
            this.lbl_QuezonAve.Location = new System.Drawing.Point(264, 57);
            this.lbl_QuezonAve.Name = "lbl_QuezonAve";
            this.lbl_QuezonAve.Size = new System.Drawing.Size(100, 13);
            this.lbl_QuezonAve.TabIndex = 34;
            this.lbl_QuezonAve.Text = "QUEZON AVENUE";
            this.lbl_QuezonAve.Click += new System.EventHandler(this.lbl_NorthAve_Click);
            // 
            // lbl2TaftAve
            // 
            this.lbl2TaftAve.AutoSize = true;
            this.lbl2TaftAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl2TaftAve.Location = new System.Drawing.Point(177, 353);
            this.lbl2TaftAve.Name = "lbl2TaftAve";
            this.lbl2TaftAve.Size = new System.Drawing.Size(81, 13);
            this.lbl2TaftAve.TabIndex = 70;
            this.lbl2TaftAve.Text = "TAFT AVENUE";
            // 
            // lbl2ShawBoulevard
            // 
            this.lbl2ShawBoulevard.AutoSize = true;
            this.lbl2ShawBoulevard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl2ShawBoulevard.Location = new System.Drawing.Point(54, 282);
            this.lbl2ShawBoulevard.Name = "lbl2ShawBoulevard";
            this.lbl2ShawBoulevard.Size = new System.Drawing.Size(109, 13);
            this.lbl2ShawBoulevard.TabIndex = 64;
            this.lbl2ShawBoulevard.Text = "SHAW BOULEVARD";
            // 
            // rb2_TaftAve
            // 
            this.rb2_TaftAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb2_TaftAve.AutoSize = true;
            this.rb2_TaftAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb2_TaftAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb2_TaftAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb2_TaftAve.ForeColor = System.Drawing.Color.White;
            this.rb2_TaftAve.Location = new System.Drawing.Point(137, 372);
            this.rb2_TaftAve.Name = "rb2_TaftAve";
            this.rb2_TaftAve.Padding = new System.Windows.Forms.Padding(22, 0, 22, 0);
            this.rb2_TaftAve.Size = new System.Drawing.Size(154, 37);
            this.rb2_TaftAve.TabIndex = 69;
            this.rb2_TaftAve.TabStop = true;
            this.rb2_TaftAve.Text = "Taft Ave.";
            this.rb2_TaftAve.UseVisualStyleBackColor = false;
            this.rb2_TaftAve.CheckedChanged += new System.EventHandler(this.rb2_TaftAve_CheckedChanged);
            // 
            // rb2_ShawBoulevard
            // 
            this.rb2_ShawBoulevard.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb2_ShawBoulevard.AutoSize = true;
            this.rb2_ShawBoulevard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb2_ShawBoulevard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb2_ShawBoulevard.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb2_ShawBoulevard.ForeColor = System.Drawing.Color.White;
            this.rb2_ShawBoulevard.Location = new System.Drawing.Point(34, 303);
            this.rb2_ShawBoulevard.Name = "rb2_ShawBoulevard";
            this.rb2_ShawBoulevard.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.rb2_ShawBoulevard.Size = new System.Drawing.Size(155, 36);
            this.rb2_ShawBoulevard.TabIndex = 63;
            this.rb2_ShawBoulevard.TabStop = true;
            this.rb2_ShawBoulevard.Text = "Shaw Blvd.";
            this.rb2_ShawBoulevard.UseVisualStyleBackColor = false;
            this.rb2_ShawBoulevard.CheckedChanged += new System.EventHandler(this.rb2_ShawBoulevard_CheckedChanged);
            // 
            // lbl2Magallanes
            // 
            this.lbl2Magallanes.AutoSize = true;
            this.lbl2Magallanes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl2Magallanes.Location = new System.Drawing.Point(278, 290);
            this.lbl2Magallanes.Name = "lbl2Magallanes";
            this.lbl2Magallanes.Size = new System.Drawing.Size(79, 13);
            this.lbl2Magallanes.TabIndex = 57;
            this.lbl2Magallanes.Text = "MAGALLANES";
            // 
            // lbl2Ortigas
            // 
            this.lbl2Ortigas.AutoSize = true;
            this.lbl2Ortigas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl2Ortigas.Location = new System.Drawing.Point(77, 220);
            this.lbl2Ortigas.Name = "lbl2Ortigas";
            this.lbl2Ortigas.Size = new System.Drawing.Size(55, 13);
            this.lbl2Ortigas.TabIndex = 62;
            this.lbl2Ortigas.Text = "ORTIGAS";
            // 
            // lbl2AyalaAve
            // 
            this.lbl2AyalaAve.AutoSize = true;
            this.lbl2AyalaAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl2AyalaAve.Location = new System.Drawing.Point(270, 225);
            this.lbl2AyalaAve.Name = "lbl2AyalaAve";
            this.lbl2AyalaAve.Size = new System.Drawing.Size(88, 13);
            this.lbl2AyalaAve.TabIndex = 68;
            this.lbl2AyalaAve.Text = "AYALA AVENUE";
            // 
            // rb2_Ortigas
            // 
            this.rb2_Ortigas.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb2_Ortigas.AutoSize = true;
            this.rb2_Ortigas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb2_Ortigas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb2_Ortigas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb2_Ortigas.ForeColor = System.Drawing.Color.White;
            this.rb2_Ortigas.Location = new System.Drawing.Point(34, 239);
            this.rb2_Ortigas.Name = "rb2_Ortigas";
            this.rb2_Ortigas.Padding = new System.Windows.Forms.Padding(37, 0, 37, 0);
            this.rb2_Ortigas.Size = new System.Drawing.Size(155, 36);
            this.rb2_Ortigas.TabIndex = 61;
            this.rb2_Ortigas.TabStop = true;
            this.rb2_Ortigas.Text = "Ortigas";
            this.rb2_Ortigas.UseVisualStyleBackColor = false;
            this.rb2_Ortigas.CheckedChanged += new System.EventHandler(this.rb2_Ortigas_CheckedChanged);
            // 
            // rb2_Magallanes
            // 
            this.rb2_Magallanes.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb2_Magallanes.AutoSize = true;
            this.rb2_Magallanes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb2_Magallanes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb2_Magallanes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb2_Magallanes.ForeColor = System.Drawing.Color.White;
            this.rb2_Magallanes.Location = new System.Drawing.Point(241, 309);
            this.rb2_Magallanes.Name = "rb2_Magallanes";
            this.rb2_Magallanes.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.rb2_Magallanes.Size = new System.Drawing.Size(155, 37);
            this.rb2_Magallanes.TabIndex = 52;
            this.rb2_Magallanes.TabStop = true;
            this.rb2_Magallanes.Text = "Magallanes";
            this.rb2_Magallanes.UseVisualStyleBackColor = false;
            this.rb2_Magallanes.CheckedChanged += new System.EventHandler(this.rb2_Magallanes_CheckedChanged);
            // 
            // lbl2Santolan
            // 
            this.lbl2Santolan.AutoSize = true;
            this.lbl2Santolan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl2Santolan.Location = new System.Drawing.Point(77, 155);
            this.lbl2Santolan.Name = "lbl2Santolan";
            this.lbl2Santolan.Size = new System.Drawing.Size(65, 13);
            this.lbl2Santolan.TabIndex = 60;
            this.lbl2Santolan.Text = "SANTOLAN";
            // 
            // rb2_AyalaAve
            // 
            this.rb2_AyalaAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb2_AyalaAve.AutoSize = true;
            this.rb2_AyalaAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb2_AyalaAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb2_AyalaAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb2_AyalaAve.ForeColor = System.Drawing.Color.White;
            this.rb2_AyalaAve.Location = new System.Drawing.Point(241, 245);
            this.rb2_AyalaAve.Name = "rb2_AyalaAve";
            this.rb2_AyalaAve.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.rb2_AyalaAve.Size = new System.Drawing.Size(157, 37);
            this.rb2_AyalaAve.TabIndex = 67;
            this.rb2_AyalaAve.TabStop = true;
            this.rb2_AyalaAve.Text = "Ayala Ave.";
            this.rb2_AyalaAve.UseVisualStyleBackColor = false;
            this.rb2_AyalaAve.CheckedChanged += new System.EventHandler(this.rb2_AyalaAve_CheckedChanged);
            // 
            // rb2_Santolan
            // 
            this.rb2_Santolan.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb2_Santolan.AutoSize = true;
            this.rb2_Santolan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb2_Santolan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb2_Santolan.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb2_Santolan.ForeColor = System.Drawing.Color.White;
            this.rb2_Santolan.Location = new System.Drawing.Point(34, 175);
            this.rb2_Santolan.Name = "rb2_Santolan";
            this.rb2_Santolan.Padding = new System.Windows.Forms.Padding(30, 0, 30, 0);
            this.rb2_Santolan.Size = new System.Drawing.Size(155, 36);
            this.rb2_Santolan.TabIndex = 59;
            this.rb2_Santolan.TabStop = true;
            this.rb2_Santolan.Text = "Santolan";
            this.rb2_Santolan.UseVisualStyleBackColor = false;
            this.rb2_Santolan.CheckedChanged += new System.EventHandler(this.rb2_Santolan_CheckedChanged);
            // 
            // lbl2Buendia
            // 
            this.lbl2Buendia.AutoSize = true;
            this.lbl2Buendia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl2Buendia.Location = new System.Drawing.Point(291, 158);
            this.lbl2Buendia.Name = "lbl2Buendia";
            this.lbl2Buendia.Size = new System.Drawing.Size(55, 13);
            this.lbl2Buendia.TabIndex = 56;
            this.lbl2Buendia.Text = "BUENDIA";
            // 
            // lbl2AranetaCubao
            // 
            this.lbl2AranetaCubao.AutoSize = true;
            this.lbl2AranetaCubao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl2AranetaCubao.Location = new System.Drawing.Point(65, 87);
            this.lbl2AranetaCubao.Name = "lbl2AranetaCubao";
            this.lbl2AranetaCubao.Size = new System.Drawing.Size(98, 13);
            this.lbl2AranetaCubao.TabIndex = 55;
            this.lbl2AranetaCubao.Text = "ARANETA CUBAO";
            // 
            // lbl2Guadalupe
            // 
            this.lbl2Guadalupe.AutoSize = true;
            this.lbl2Guadalupe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl2Guadalupe.Location = new System.Drawing.Point(291, 90);
            this.lbl2Guadalupe.Name = "lbl2Guadalupe";
            this.lbl2Guadalupe.Size = new System.Drawing.Size(73, 13);
            this.lbl2Guadalupe.TabIndex = 58;
            this.lbl2Guadalupe.Text = "GUADALUPE";
            // 
            // rb2_AranetaCubao
            // 
            this.rb2_AranetaCubao.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb2_AranetaCubao.AutoSize = true;
            this.rb2_AranetaCubao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb2_AranetaCubao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb2_AranetaCubao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb2_AranetaCubao.ForeColor = System.Drawing.Color.White;
            this.rb2_AranetaCubao.Location = new System.Drawing.Point(34, 108);
            this.rb2_AranetaCubao.Name = "rb2_AranetaCubao";
            this.rb2_AranetaCubao.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb2_AranetaCubao.Size = new System.Drawing.Size(158, 36);
            this.rb2_AranetaCubao.TabIndex = 53;
            this.rb2_AranetaCubao.TabStop = true;
            this.rb2_AranetaCubao.Text = "Araneta Cubao";
            this.rb2_AranetaCubao.UseVisualStyleBackColor = false;
            this.rb2_AranetaCubao.CheckedChanged += new System.EventHandler(this.rb2_AranetaCubao_CheckedChanged);
            // 
            // rb2_Buendia
            // 
            this.rb2_Buendia.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb2_Buendia.AutoSize = true;
            this.rb2_Buendia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb2_Buendia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb2_Buendia.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb2_Buendia.ForeColor = System.Drawing.Color.White;
            this.rb2_Buendia.Location = new System.Drawing.Point(241, 178);
            this.rb2_Buendia.Name = "rb2_Buendia";
            this.rb2_Buendia.Padding = new System.Windows.Forms.Padding(28, 0, 28, 0);
            this.rb2_Buendia.Size = new System.Drawing.Size(159, 37);
            this.rb2_Buendia.TabIndex = 51;
            this.rb2_Buendia.TabStop = true;
            this.rb2_Buendia.Text = "Buendia";
            this.rb2_Buendia.UseVisualStyleBackColor = false;
            this.rb2_Buendia.CheckedChanged += new System.EventHandler(this.rb2_Buendia_CheckedChanged);
            // 
            // lbl2BoniAve
            // 
            this.lbl2BoniAve.AutoSize = true;
            this.lbl2BoniAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl2BoniAve.Location = new System.Drawing.Point(266, 19);
            this.lbl2BoniAve.Name = "lbl2BoniAve";
            this.lbl2BoniAve.Size = new System.Drawing.Size(80, 13);
            this.lbl2BoniAve.TabIndex = 66;
            this.lbl2BoniAve.Text = "BONI AVENUE";
            // 
            // rb2_Guadalupe
            // 
            this.rb2_Guadalupe.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb2_Guadalupe.AutoSize = true;
            this.rb2_Guadalupe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb2_Guadalupe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb2_Guadalupe.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb2_Guadalupe.ForeColor = System.Drawing.Color.White;
            this.rb2_Guadalupe.Location = new System.Drawing.Point(241, 113);
            this.rb2_Guadalupe.Name = "rb2_Guadalupe";
            this.rb2_Guadalupe.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.rb2_Guadalupe.Size = new System.Drawing.Size(159, 37);
            this.rb2_Guadalupe.TabIndex = 54;
            this.rb2_Guadalupe.TabStop = true;
            this.rb2_Guadalupe.Text = "Guadalupe";
            this.rb2_Guadalupe.UseVisualStyleBackColor = false;
            this.rb2_Guadalupe.CheckedChanged += new System.EventHandler(this.rb2_Guadalupe_CheckedChanged);
            // 
            // lbl2GMAKAMUNING
            // 
            this.lbl2GMAKAMUNING.AutoSize = true;
            this.lbl2GMAKAMUNING.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl2GMAKAMUNING.Location = new System.Drawing.Point(66, 21);
            this.lbl2GMAKAMUNING.Name = "lbl2GMAKAMUNING";
            this.lbl2GMAKAMUNING.Size = new System.Drawing.Size(92, 13);
            this.lbl2GMAKAMUNING.TabIndex = 49;
            this.lbl2GMAKAMUNING.Text = "GMA KAMUNING";
            // 
            // rb2_GMA
            // 
            this.rb2_GMA.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb2_GMA.AutoSize = true;
            this.rb2_GMA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb2_GMA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb2_GMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb2_GMA.ForeColor = System.Drawing.Color.White;
            this.rb2_GMA.Location = new System.Drawing.Point(34, 43);
            this.rb2_GMA.Name = "rb2_GMA";
            this.rb2_GMA.Size = new System.Drawing.Size(156, 36);
            this.rb2_GMA.TabIndex = 48;
            this.rb2_GMA.TabStop = true;
            this.rb2_GMA.Text = "GMA Kamuning";
            this.rb2_GMA.UseVisualStyleBackColor = false;
            this.rb2_GMA.CheckedChanged += new System.EventHandler(this.rb2_GMA_CheckedChanged);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel8.Location = new System.Drawing.Point(322, 314);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(136, 1);
            this.panel8.TabIndex = 19;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel4.Location = new System.Drawing.Point(45, 314);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(136, 1);
            this.panel4.TabIndex = 20;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel9.Location = new System.Drawing.Point(457, 314);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1, 400);
            this.panel9.TabIndex = 21;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel5.Location = new System.Drawing.Point(45, 314);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 400);
            this.panel5.TabIndex = 22;
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(630, 469);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(248, 111);
            this.lblPrice.TabIndex = 31;
            this.lblPrice.Text = "0.00";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(666, 690);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(140, 33);
            this.button13.TabIndex = 32;
            this.button13.Text = "BACK";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click_1);
            // 
            // Quezon_Ave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1370, 723);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button14);
            this.Controls.Add(label5);
            this.Controls.Add(label3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Quezon_Ave";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quezon_Ave";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Quezon_Ave_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbl_QuezonAve;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lbl2TaftAve;
        private System.Windows.Forms.Label lbl2ShawBoulevard;
        private System.Windows.Forms.RadioButton rb2_TaftAve;
        private System.Windows.Forms.RadioButton rb2_ShawBoulevard;
        private System.Windows.Forms.Label lbl2Magallanes;
        private System.Windows.Forms.Label lbl2Ortigas;
        private System.Windows.Forms.Label lbl2AyalaAve;
        private System.Windows.Forms.RadioButton rb2_Ortigas;
        private System.Windows.Forms.RadioButton rb2_Magallanes;
        private System.Windows.Forms.Label lbl2Santolan;
        private System.Windows.Forms.RadioButton rb2_AyalaAve;
        private System.Windows.Forms.RadioButton rb2_Santolan;
        private System.Windows.Forms.Label lbl2Buendia;
        private System.Windows.Forms.Label lbl2AranetaCubao;
        private System.Windows.Forms.Label lbl2Guadalupe;
        private System.Windows.Forms.RadioButton rb2_AranetaCubao;
        private System.Windows.Forms.RadioButton rb2_Buendia;
        private System.Windows.Forms.Label lbl2BoniAve;
        private System.Windows.Forms.RadioButton rb2_Guadalupe;
        private System.Windows.Forms.Label lbl2GMAKAMUNING;
        private System.Windows.Forms.RadioButton rb2_GMA;
        private System.Windows.Forms.RadioButton rb2_BoniAve;
        private System.Windows.Forms.Button button13;


    }
}
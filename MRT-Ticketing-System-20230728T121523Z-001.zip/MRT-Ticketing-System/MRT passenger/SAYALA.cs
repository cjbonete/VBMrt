﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SAYALA : Form
    {
        public SAYALA()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void GMA_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb3_Buendia.Checked == true && lblPrice.Text != "0.00")
            {

                string AyalaToBuendia, fromAyalaToBuendia, TotalPrice;

                AyalaToBuendia = lbl3Buendia.Text;
                fromAyalaToBuendia = lbl_Ayala.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromAyalaToBuendia(AyalaToBuendia.ToString());
                TF.fromAyalaToBuendia2(fromAyalaToBuendia.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb3_Guadalupe.Checked == true && lblPrice.Text != "0.00")
            {

                string AyalaToGuadalupe, fromAyalaToGuadalupe, TotalPrice;

                AyalaToGuadalupe = lbl3Guadalupe.Text;
                fromAyalaToGuadalupe = lbl_Ayala.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromAyalaToGuadalupe(AyalaToGuadalupe.ToString());
                TF.fromAyalaToGuadalupe2(fromAyalaToGuadalupe.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb3_BoniAve.Checked == true && lblPrice.Text != "0.00")
            {

                string AyalaToBoniAve, fromAyalaToBoniAve, TotalPrice;

                AyalaToBoniAve = lbl3BoniAve.Text;
                fromAyalaToBoniAve = lbl_Ayala.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromAyalaToBoniAve(AyalaToBoniAve.ToString());
                TF.fromAyalaToBoniAve2(fromAyalaToBoniAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb3_ShawBoulevard.Checked == true && lblPrice.Text != "0.00")
            {

                string AyalaToShawBoulevard, fromAyalaToShawBoulevard, TotalPrice;

                AyalaToShawBoulevard = lbl3ShawBoulevard.Text;
                fromAyalaToShawBoulevard = lbl_Ayala.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromAyalaToShawBoulevard(AyalaToShawBoulevard.ToString());
                TF.fromAyalaToShawBoulevard2(fromAyalaToShawBoulevard.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb3_Ortigas.Checked == true && lblPrice.Text != "0.00")
            {

                string AyalaToOrtigas, fromAyalaToOrtigas, TotalPrice;

                AyalaToOrtigas = lbl3Ortigas.Text;
                fromAyalaToOrtigas = lbl_Ayala.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromAyalaToOrtigas(AyalaToOrtigas.ToString());
                TF.fromAyalaToOrtigas2(fromAyalaToOrtigas.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb3_Santolan.Checked == true && lblPrice.Text != "0.00")
            {

                string AyalaToSantolan, fromAyalaToSantolan, TotalPrice;

                AyalaToSantolan = lbl3Santolan.Text;
                fromAyalaToSantolan = lbl_Ayala.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromAyalaToSantolan(AyalaToSantolan.ToString());
                TF.fromAyalaToSantolan2(fromAyalaToSantolan.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb3_AranetaCubao.Checked == true && lblPrice.Text != "0.00")
            {

                string AyalaToAraneta, fromAyalaToAraneta, TotalPrice;

                AyalaToAraneta = lbl3AranetaCubao.Text;
                fromAyalaToAraneta = lbl_Ayala.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromAyalaToAraneta(AyalaToAraneta.ToString());
                TF.fromAyalaToAraneta2(fromAyalaToAraneta.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb3_GMA.Checked == true && lblPrice.Text != "0.00")
            {

                string AyalaToGMAKamuning, fromAyalaToGMAKamuning, TotalPrice;

                AyalaToGMAKamuning = lbl3GMAKAMUNING.Text;
                fromAyalaToGMAKamuning = lbl_Ayala.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromAyalaToGMAKamuning(AyalaToGMAKamuning.ToString());
                TF.fromAyalaToGMAKamuning2(fromAyalaToGMAKamuning.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb3_QuezonAve.Checked == true && lblPrice.Text != "0.00")
            {

                string AyalaToQuezonAve, fromAyalaToQuezonAve, TotalPrice;

                AyalaToQuezonAve = lbl3QuezonAve.Text;
                fromAyalaToQuezonAve = lbl_Ayala.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();

                TF.fromAyalaToQuezonAve(AyalaToQuezonAve.ToString());
                TF.fromAyalaToQuezonAve2(fromAyalaToQuezonAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();
            }

            else if (rb3_NorthAve.Checked == true && lblPrice.Text != "0.00")
            {

                string AyalaToNorthAve, fromAyalaToNorthAve, TotalPrice;

                AyalaToNorthAve = lbl3NorthAve.Text;
                fromAyalaToNorthAve = lbl_Ayala.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromAyalaToNorthAve(AyalaToNorthAve.ToString());
                TF.fromAyalaToNorthAve2(fromAyalaToNorthAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            
        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void rb3_Buendia_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_Buendia.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb3_Guadalupe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_Guadalupe.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb3_BoniAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_BoniAve.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb3_ShawBoulevard_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_ShawBoulevard.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb3_Ortigas_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_Ortigas.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb3_Santolan_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_Santolan.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb3_AranetaCubao_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_AranetaCubao.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb3_GMA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_GMA.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb3_QuezonAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_QuezonAve.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb3_NorthAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_NorthAve.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SCONTACTUS : Form
    {
        public SCONTACTUS()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();

         Form2 home = new Form2();

            home.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

           SABOUTUS AU = new SABOUTUS();

            AU.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

           SGUIDE GU = new SGUIDE();

            GU.ShowDialog();
        }

        private void Contact_us_Load(object sender, EventArgs e)
        {

        }
    }
}

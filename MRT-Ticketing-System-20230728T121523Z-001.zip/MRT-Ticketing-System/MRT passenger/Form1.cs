﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void SELECT_Click(object sender, EventArgs e)
        {
            this.Hide();

            North_Ave NA = new North_Ave();

            NA.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();

            Quezon_Ave QA = new Quezon_Ave();

            QA.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();

          GMA GK = new GMA();

            GK.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();

            Araneta AC = new Araneta();

            AC.ShowDialog();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();

            Santolan SA = new Santolan();

            SA.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();

         Ortigas OS = new Ortigas();

            OS.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();

            Shaw SB = new Shaw();

            SB.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();

            Boni BA = new Boni();

            BA.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();

         Guada GL = new Guada();

            GL.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
             this.Hide();

      buendia BU = new buendia();

      BU.ShowDialog();
        }

        private void button13_Click(object sender, EventArgs e)
        {

            this.Hide();

          Ayala AY = new Ayala();

            AY.ShowDialog();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Magallanes MG = new Magallanes();

            MG.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            this.Hide();

            Taft TA = new Taft();

            TA.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            about_us Au = new about_us();

            Au.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

            guide gd = new guide();

            gd.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();

            SCONTACT CU = new SCONTACT();

            CU.ShowDialog();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Main_home home = new Main_home();

            home.ShowDialog();
        }
    }
}
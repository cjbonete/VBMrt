﻿namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    partial class SARANETA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label5;
            this.label4 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl10QuezonAve = new System.Windows.Forms.Label();
            this.rb10_QuezonAve = new System.Windows.Forms.RadioButton();
            this.lbl10GMAKAMUNING = new System.Windows.Forms.Label();
            this.rb10_GMA = new System.Windows.Forms.RadioButton();
            this.lbl10NorthAve = new System.Windows.Forms.Label();
            this.rb10_NorthAve = new System.Windows.Forms.RadioButton();
            this.lblPrice = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lbl_AranetaCubao = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label2.Location = new System.Drawing.Point(556, 118);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(272, 24);
            label2.TabIndex = 1;
            label2.Text = "SELECT YOUR DESTINATION";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label3.Location = new System.Drawing.Point(688, 297);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(101, 24);
            label3.TabIndex = 12;
            label3.Text = "Ticket fare:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label5.Location = new System.Drawing.Point(190, 267);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(178, 37);
            label5.TabIndex = 30;
            label5.Text = "STATIONS";
            label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(848, 391);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 42);
            this.label4.TabIndex = 16;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(1189, 627);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(140, 33);
            this.button14.TabIndex = 17;
            this.button14.Text = "PROCEED";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(32, 71);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1326, 155);
            this.panel1.TabIndex = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ITZeyyyyy_TRAIN_TICKET_SYSTEM.Properties.Resources.metro_station;
            this.pictureBox2.Location = new System.Drawing.Point(143, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(193, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(379, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(896, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "ARANETA CUBAO STATION";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel4.Location = new System.Drawing.Point(180, 299);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 400);
            this.panel4.TabIndex = 34;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel9.Location = new System.Drawing.Point(377, 299);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1, 400);
            this.panel9.TabIndex = 33;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel3.Location = new System.Drawing.Point(348, 299);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(30, 1);
            this.panel3.TabIndex = 32;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel8.Location = new System.Drawing.Point(180, 299);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(30, 1);
            this.panel8.TabIndex = 31;
            this.panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.panel8_Paint);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl10QuezonAve);
            this.panel2.Controls.Add(this.rb10_QuezonAve);
            this.panel2.Controls.Add(this.lbl10GMAKAMUNING);
            this.panel2.Controls.Add(this.rb10_GMA);
            this.panel2.Controls.Add(this.lbl10NorthAve);
            this.panel2.Controls.Add(this.rb10_NorthAve);
            this.panel2.Location = new System.Drawing.Point(180, 301);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(198, 429);
            this.panel2.TabIndex = 29;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // lbl10QuezonAve
            // 
            this.lbl10QuezonAve.AutoSize = true;
            this.lbl10QuezonAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl10QuezonAve.Location = new System.Drawing.Point(44, 97);
            this.lbl10QuezonAve.Name = "lbl10QuezonAve";
            this.lbl10QuezonAve.Size = new System.Drawing.Size(100, 13);
            this.lbl10QuezonAve.TabIndex = 158;
            this.lbl10QuezonAve.Text = "QUEZON AVENUE";
            // 
            // rb10_QuezonAve
            // 
            this.rb10_QuezonAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb10_QuezonAve.AutoSize = true;
            this.rb10_QuezonAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb10_QuezonAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb10_QuezonAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb10_QuezonAve.ForeColor = System.Drawing.Color.White;
            this.rb10_QuezonAve.Location = new System.Drawing.Point(21, 117);
            this.rb10_QuezonAve.Name = "rb10_QuezonAve";
            this.rb10_QuezonAve.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb10_QuezonAve.Size = new System.Drawing.Size(158, 37);
            this.rb10_QuezonAve.TabIndex = 157;
            this.rb10_QuezonAve.TabStop = true;
            this.rb10_QuezonAve.Text = "Quezon Ave.";
            this.rb10_QuezonAve.UseVisualStyleBackColor = false;
            this.rb10_QuezonAve.CheckedChanged += new System.EventHandler(this.rb10_QuezonAve_CheckedChanged);
            // 
            // lbl10GMAKAMUNING
            // 
            this.lbl10GMAKAMUNING.AutoSize = true;
            this.lbl10GMAKAMUNING.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl10GMAKAMUNING.Location = new System.Drawing.Point(52, 25);
            this.lbl10GMAKAMUNING.Name = "lbl10GMAKAMUNING";
            this.lbl10GMAKAMUNING.Size = new System.Drawing.Size(92, 13);
            this.lbl10GMAKAMUNING.TabIndex = 160;
            this.lbl10GMAKAMUNING.Text = "GMA KAMUNING";
            // 
            // rb10_GMA
            // 
            this.rb10_GMA.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb10_GMA.AutoSize = true;
            this.rb10_GMA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb10_GMA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb10_GMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb10_GMA.ForeColor = System.Drawing.Color.White;
            this.rb10_GMA.Location = new System.Drawing.Point(20, 47);
            this.rb10_GMA.Name = "rb10_GMA";
            this.rb10_GMA.Size = new System.Drawing.Size(156, 36);
            this.rb10_GMA.TabIndex = 159;
            this.rb10_GMA.TabStop = true;
            this.rb10_GMA.Text = "GMA Kamuning";
            this.rb10_GMA.UseVisualStyleBackColor = false;
            this.rb10_GMA.CheckedChanged += new System.EventHandler(this.rb10_GMA_CheckedChanged);
            // 
            // lbl10NorthAve
            // 
            this.lbl10NorthAve.AutoSize = true;
            this.lbl10NorthAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl10NorthAve.Location = new System.Drawing.Point(55, 167);
            this.lbl10NorthAve.Name = "lbl10NorthAve";
            this.lbl10NorthAve.Size = new System.Drawing.Size(93, 13);
            this.lbl10NorthAve.TabIndex = 156;
            this.lbl10NorthAve.Text = "NORTH AVENUE";
            // 
            // rb10_NorthAve
            // 
            this.rb10_NorthAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb10_NorthAve.AutoSize = true;
            this.rb10_NorthAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb10_NorthAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb10_NorthAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb10_NorthAve.ForeColor = System.Drawing.Color.White;
            this.rb10_NorthAve.Location = new System.Drawing.Point(20, 185);
            this.rb10_NorthAve.Name = "rb10_NorthAve";
            this.rb10_NorthAve.Padding = new System.Windows.Forms.Padding(17, 0, 17, 0);
            this.rb10_NorthAve.Size = new System.Drawing.Size(159, 37);
            this.rb10_NorthAve.TabIndex = 155;
            this.rb10_NorthAve.TabStop = true;
            this.rb10_NorthAve.Text = "North Ave.";
            this.rb10_NorthAve.UseVisualStyleBackColor = false;
            this.rb10_NorthAve.CheckedChanged += new System.EventHandler(this.rb10_NorthAve_CheckedChanged);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(638, 421);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(248, 111);
            this.lblPrice.TabIndex = 76;
            this.lblPrice.Text = "0.00";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(692, 627);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 33);
            this.button1.TabIndex = 77;
            this.button1.Text = "BACK";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbl_AranetaCubao
            // 
            this.lbl_AranetaCubao.AutoSize = true;
            this.lbl_AranetaCubao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl_AranetaCubao.Location = new System.Drawing.Point(238, 244);
            this.lbl_AranetaCubao.Name = "lbl_AranetaCubao";
            this.lbl_AranetaCubao.Size = new System.Drawing.Size(98, 13);
            this.lbl_AranetaCubao.TabIndex = 85;
            this.lbl_AranetaCubao.Text = "ARANETA CUBAO";
            // 
            // SARANETA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1370, 727);
            this.Controls.Add(this.lbl_AranetaCubao);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel8);
            this.Controls.Add(label5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button14);
            this.Controls.Add(label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SARANETA";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "buendia";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lbl10QuezonAve;
        private System.Windows.Forms.RadioButton rb10_QuezonAve;
        private System.Windows.Forms.Label lbl10GMAKAMUNING;
        private System.Windows.Forms.RadioButton rb10_GMA;
        private System.Windows.Forms.Label lbl10NorthAve;
        private System.Windows.Forms.RadioButton rb10_NorthAve;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbl_AranetaCubao;
    }
}
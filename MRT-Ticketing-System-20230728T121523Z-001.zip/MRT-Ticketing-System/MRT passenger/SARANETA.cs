﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SARANETA : Form
    {
        public SARANETA()
        {
            InitializeComponent();
        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb10_GMA.Checked == true && lblPrice.Text != "0.00")
            {

                string AranetaToGMAKamuning, fromAranetaToGMAKamuning, TotalPrice;

                AranetaToGMAKamuning = lbl10GMAKAMUNING.Text;
                fromAranetaToGMAKamuning = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromAranetaToGMAKamuning(AranetaToGMAKamuning.ToString());
                TF.fromAranetaToGMAKamuning2(fromAranetaToGMAKamuning.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb10_QuezonAve.Checked == true && lblPrice.Text != "0.00")
            {

                string AranetaToQuezonAve, fromAranetaToQuezonAve, TotalPrice;

                AranetaToQuezonAve = lbl10QuezonAve.Text;
                fromAranetaToQuezonAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();

                TF.fromAranetaToQuezonAve(AranetaToQuezonAve.ToString());
                TF.fromAranetaToQuezonAve2(fromAranetaToQuezonAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();
            }

            else if (rb10_NorthAve.Checked == true && lblPrice.Text != "0.00")
            {

                string AranetaToNorthAve, fromAranetaToNorthAve, TotalPrice;

                AranetaToNorthAve = lbl10NorthAve.Text;
                fromAranetaToNorthAve = lbl_AranetaCubao.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromAranetaToNorthAve(AranetaToNorthAve.ToString());
                TF.fromAranetaToNorthAve2(fromAranetaToNorthAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Buendia_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void rb10_GMA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb10_GMA.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb10_QuezonAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb10_QuezonAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb10_NorthAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb10_NorthAve.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }
    }
}

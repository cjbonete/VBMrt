﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SCONTACT : Form
    {
        public SCONTACT()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();

         Form1 home = new Form1();

            home.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

           about_us au = new about_us();

            au.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

            guide gu = new guide();

            gu.ShowDialog();
        }

        private void Contact_us_Load(object sender, EventArgs e)
        {

        }
    }
}

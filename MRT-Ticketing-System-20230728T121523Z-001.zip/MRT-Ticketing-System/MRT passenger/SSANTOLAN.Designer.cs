﻿namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    partial class SSANTOLAN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label5;
            this.label4 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl9QuezonAve = new System.Windows.Forms.Label();
            this.rb9_QuezonAve = new System.Windows.Forms.RadioButton();
            this.lbl9GMAKAMUNING = new System.Windows.Forms.Label();
            this.rb9_GMA = new System.Windows.Forms.RadioButton();
            this.rb9_AranetaCubao = new System.Windows.Forms.RadioButton();
            this.lbl9NorthAve = new System.Windows.Forms.Label();
            this.lbl9AranetaCubao = new System.Windows.Forms.Label();
            this.rb9_NorthAve = new System.Windows.Forms.RadioButton();
            this.lblPrice = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.lbl_Santolan = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label2.Location = new System.Drawing.Point(556, 118);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(272, 24);
            label2.TabIndex = 1;
            label2.Text = "SELECT YOUR DESTINATION";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label3.Location = new System.Drawing.Point(678, 298);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(101, 24);
            label3.TabIndex = 12;
            label3.Text = "Ticket fare:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label5.Location = new System.Drawing.Point(180, 274);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(178, 37);
            label5.TabIndex = 24;
            label5.Text = "STATIONS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(838, 392);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 42);
            this.label4.TabIndex = 16;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(1179, 625);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(140, 33);
            this.button14.TabIndex = 17;
            this.button14.Text = "PROCEED";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(22, 72);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1326, 155);
            this.panel1.TabIndex = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ITZeyyyyy_TRAIN_TICKET_SYSTEM.Properties.Resources.metro_station;
            this.pictureBox2.Location = new System.Drawing.Point(143, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(193, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(330, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1084, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "SANTOLAN ANNAPOLIS STATION";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel4.Location = new System.Drawing.Point(170, 306);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 400);
            this.panel4.TabIndex = 28;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel9.Location = new System.Drawing.Point(367, 306);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1, 400);
            this.panel9.TabIndex = 27;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel3.Location = new System.Drawing.Point(338, 306);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(30, 1);
            this.panel3.TabIndex = 26;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel8.Location = new System.Drawing.Point(170, 306);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(30, 1);
            this.panel8.TabIndex = 25;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl9QuezonAve);
            this.panel2.Controls.Add(this.rb9_QuezonAve);
            this.panel2.Controls.Add(this.lbl9GMAKAMUNING);
            this.panel2.Controls.Add(this.rb9_GMA);
            this.panel2.Controls.Add(this.rb9_AranetaCubao);
            this.panel2.Controls.Add(this.lbl9NorthAve);
            this.panel2.Controls.Add(this.lbl9AranetaCubao);
            this.panel2.Controls.Add(this.rb9_NorthAve);
            this.panel2.Location = new System.Drawing.Point(170, 308);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(198, 429);
            this.panel2.TabIndex = 23;
            // 
            // lbl9QuezonAve
            // 
            this.lbl9QuezonAve.AutoSize = true;
            this.lbl9QuezonAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl9QuezonAve.Location = new System.Drawing.Point(47, 149);
            this.lbl9QuezonAve.Name = "lbl9QuezonAve";
            this.lbl9QuezonAve.Size = new System.Drawing.Size(100, 13);
            this.lbl9QuezonAve.TabIndex = 152;
            this.lbl9QuezonAve.Text = "QUEZON AVENUE";
            // 
            // rb9_QuezonAve
            // 
            this.rb9_QuezonAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb9_QuezonAve.AutoSize = true;
            this.rb9_QuezonAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb9_QuezonAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb9_QuezonAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb9_QuezonAve.ForeColor = System.Drawing.Color.White;
            this.rb9_QuezonAve.Location = new System.Drawing.Point(22, 166);
            this.rb9_QuezonAve.Name = "rb9_QuezonAve";
            this.rb9_QuezonAve.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb9_QuezonAve.Size = new System.Drawing.Size(158, 37);
            this.rb9_QuezonAve.TabIndex = 151;
            this.rb9_QuezonAve.TabStop = true;
            this.rb9_QuezonAve.Text = "Quezon Ave.";
            this.rb9_QuezonAve.UseVisualStyleBackColor = false;
            this.rb9_QuezonAve.CheckedChanged += new System.EventHandler(this.rb9_QuezonAve_CheckedChanged);
            // 
            // lbl9GMAKAMUNING
            // 
            this.lbl9GMAKAMUNING.AutoSize = true;
            this.lbl9GMAKAMUNING.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl9GMAKAMUNING.Location = new System.Drawing.Point(53, 74);
            this.lbl9GMAKAMUNING.Name = "lbl9GMAKAMUNING";
            this.lbl9GMAKAMUNING.Size = new System.Drawing.Size(92, 13);
            this.lbl9GMAKAMUNING.TabIndex = 154;
            this.lbl9GMAKAMUNING.Text = "GMA KAMUNING";
            // 
            // rb9_GMA
            // 
            this.rb9_GMA.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb9_GMA.AutoSize = true;
            this.rb9_GMA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb9_GMA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb9_GMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb9_GMA.ForeColor = System.Drawing.Color.White;
            this.rb9_GMA.Location = new System.Drawing.Point(21, 96);
            this.rb9_GMA.Name = "rb9_GMA";
            this.rb9_GMA.Size = new System.Drawing.Size(156, 36);
            this.rb9_GMA.TabIndex = 153;
            this.rb9_GMA.TabStop = true;
            this.rb9_GMA.Text = "GMA Kamuning";
            this.rb9_GMA.UseVisualStyleBackColor = false;
            this.rb9_GMA.CheckedChanged += new System.EventHandler(this.rb9_GMA_CheckedChanged);
            // 
            // rb9_AranetaCubao
            // 
            this.rb9_AranetaCubao.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb9_AranetaCubao.AutoSize = true;
            this.rb9_AranetaCubao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb9_AranetaCubao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb9_AranetaCubao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb9_AranetaCubao.ForeColor = System.Drawing.Color.White;
            this.rb9_AranetaCubao.Location = new System.Drawing.Point(19, 24);
            this.rb9_AranetaCubao.Name = "rb9_AranetaCubao";
            this.rb9_AranetaCubao.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb9_AranetaCubao.Size = new System.Drawing.Size(158, 36);
            this.rb9_AranetaCubao.TabIndex = 147;
            this.rb9_AranetaCubao.TabStop = true;
            this.rb9_AranetaCubao.Text = "Araneta Cubao";
            this.rb9_AranetaCubao.UseVisualStyleBackColor = false;
            this.rb9_AranetaCubao.CheckedChanged += new System.EventHandler(this.rb9_AranetaCubao_CheckedChanged);
            // 
            // lbl9NorthAve
            // 
            this.lbl9NorthAve.AutoSize = true;
            this.lbl9NorthAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl9NorthAve.Location = new System.Drawing.Point(56, 216);
            this.lbl9NorthAve.Name = "lbl9NorthAve";
            this.lbl9NorthAve.Size = new System.Drawing.Size(93, 13);
            this.lbl9NorthAve.TabIndex = 150;
            this.lbl9NorthAve.Text = "NORTH AVENUE";
            // 
            // lbl9AranetaCubao
            // 
            this.lbl9AranetaCubao.AutoSize = true;
            this.lbl9AranetaCubao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl9AranetaCubao.Location = new System.Drawing.Point(50, 3);
            this.lbl9AranetaCubao.Name = "lbl9AranetaCubao";
            this.lbl9AranetaCubao.Size = new System.Drawing.Size(98, 13);
            this.lbl9AranetaCubao.TabIndex = 148;
            this.lbl9AranetaCubao.Text = "ARANETA CUBAO";
            // 
            // rb9_NorthAve
            // 
            this.rb9_NorthAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb9_NorthAve.AutoSize = true;
            this.rb9_NorthAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb9_NorthAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb9_NorthAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb9_NorthAve.ForeColor = System.Drawing.Color.White;
            this.rb9_NorthAve.Location = new System.Drawing.Point(21, 234);
            this.rb9_NorthAve.Name = "rb9_NorthAve";
            this.rb9_NorthAve.Padding = new System.Windows.Forms.Padding(17, 0, 17, 0);
            this.rb9_NorthAve.Size = new System.Drawing.Size(159, 37);
            this.rb9_NorthAve.TabIndex = 149;
            this.rb9_NorthAve.TabStop = true;
            this.rb9_NorthAve.Text = "North Ave.";
            this.rb9_NorthAve.UseVisualStyleBackColor = false;
            this.rb9_NorthAve.CheckedChanged += new System.EventHandler(this.rb9_NorthAve_CheckedChanged);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(632, 425);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(248, 111);
            this.lblPrice.TabIndex = 75;
            this.lblPrice.Text = "0.00";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(682, 625);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 33);
            this.button1.TabIndex = 76;
            this.button1.Text = "BACK";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbl_Santolan
            // 
            this.lbl_Santolan.AutoSize = true;
            this.lbl_Santolan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl_Santolan.Location = new System.Drawing.Point(241, 249);
            this.lbl_Santolan.Name = "lbl_Santolan";
            this.lbl_Santolan.Size = new System.Drawing.Size(65, 13);
            this.lbl_Santolan.TabIndex = 84;
            this.lbl_Santolan.Text = "SANTOLAN";
            // 
            // SSANTOLAN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1370, 723);
            this.Controls.Add(this.lbl_Santolan);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel8);
            this.Controls.Add(label5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button14);
            this.Controls.Add(label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SSANTOLAN";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Guada";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lbl9QuezonAve;
        private System.Windows.Forms.RadioButton rb9_QuezonAve;
        private System.Windows.Forms.Label lbl9GMAKAMUNING;
        private System.Windows.Forms.RadioButton rb9_GMA;
        private System.Windows.Forms.RadioButton rb9_AranetaCubao;
        private System.Windows.Forms.Label lbl9NorthAve;
        private System.Windows.Forms.Label lbl9AranetaCubao;
        private System.Windows.Forms.RadioButton rb9_NorthAve;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbl_Santolan;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SMAGALLANES : Form
    {
        public SMAGALLANES()
        {
            InitializeComponent();
        }

        private void Quezon_Ave_Load(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm1 = new Form2();

            frm1.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb2_AyalaAve.Checked == true && lblPrice.Text != "0.00")
            {

                string MagToAyala, fromMagToAyala, TotalPrice;
                MagToAyala = lbl2AyalaAve.Text;
                fromMagToAyala = lbl_Magallanes.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromMagToAyala(MagToAyala.ToString());
                TF.fromMagToAyala2(fromMagToAyala.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb2_Buendia.Checked == true && lblPrice.Text != "0.00")
            {

                string MagToBuendia, fromMagToBuendia, TotalPrice;

                MagToBuendia = lbl2Buendia.Text;
                fromMagToBuendia = lbl_Magallanes.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromMagToBuendia(MagToBuendia.ToString());
                TF.fromMagToBuendia2(fromMagToBuendia.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb2_Guadalupe.Checked == true && lblPrice.Text != "0.00")
            {

                string MagToGuadalupe, fromMagToGuadalupe, TotalPrice;

                MagToGuadalupe = lbl2Guadalupe.Text;
                fromMagToGuadalupe = lbl_Magallanes.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromMagToGuadalupe(MagToGuadalupe.ToString());
                TF.fromMagToGuadalupe2(fromMagToGuadalupe.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb2_BoniAve.Checked == true && lblPrice.Text != "0.00")
            {

                string MagToBoniAve, fromMagToBoniAve, TotalPrice;

                MagToBoniAve = lbl2BoniAve.Text;
                fromMagToBoniAve = lbl_Magallanes.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromMagToBoniAve(MagToBoniAve.ToString());
                TF.fromMagToBoniAve2(fromMagToBoniAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb2_ShawBoulevard.Checked == true && lblPrice.Text != "0.00")
            {

                string MagToShawBoulevard, fromMagToShawBoulevard, TotalPrice;

                MagToShawBoulevard = lbl2ShawBoulevard.Text;
                fromMagToShawBoulevard = lbl_Magallanes.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromMagToShawBoulevard(MagToShawBoulevard.ToString());
                TF.fromMagToShawBoulevard2(fromMagToShawBoulevard.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb2_Ortigas.Checked == true && lblPrice.Text != "0.00")
            {

                string MagToOrtigas, fromMagToOrtigas, TotalPrice;

                MagToOrtigas = lbl2Ortigas.Text;
                fromMagToOrtigas = lbl_Magallanes.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromMagToOrtigas(MagToOrtigas.ToString());
                TF.fromMagToOrtigas2(fromMagToOrtigas.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb2_Santolan.Checked == true && lblPrice.Text != "0.00")
            {

                string MagToSantolan, fromMagToSantolan, TotalPrice;

                MagToSantolan = lbl2Santolan.Text;
                fromMagToSantolan = lbl_Magallanes.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromMagToSantolan(MagToSantolan.ToString());
                TF.fromMagToSantolan2(fromMagToSantolan.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb2_AranetaCubao.Checked == true && lblPrice.Text != "0.00")
            {

                string MagToAraneta, fromMagToAraneta, TotalPrice;

                MagToAraneta = lbl2AranetaCubao.Text;
                fromMagToAraneta = lbl_Magallanes.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromMagToAraneta(MagToAraneta.ToString());
                TF.fromMagToAraneta2(fromMagToAraneta.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb2_GMA.Checked == true && lblPrice.Text != "0.00")
            {

                string MagToGMAKamuning, fromMagToGMAKamuning, TotalPrice;

                MagToGMAKamuning = lbl2GMAKAMUNING.Text;
                fromMagToGMAKamuning = lbl_Magallanes.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromMagToGMAKamuning(MagToGMAKamuning.ToString());
                TF.fromMagToGMAKamuning2(fromMagToGMAKamuning.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb2_QuezonAve.Checked == true && lblPrice.Text != "0.00")
            {

                string MagToQuezonAve, fromMagToQuezonAve, TotalPrice;

                MagToQuezonAve = lbl2QuezonAve.Text;
                fromMagToQuezonAve = lbl_Magallanes.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();

                TF.fromTaftToQuezonAve(MagToQuezonAve.ToString());
                TF.fromTaftToQuezonAve2(fromMagToQuezonAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();
            }

            else if (rb2_NorthAve.Checked == true && lblPrice.Text != "0.00")
            {

                string MagToNorthAve, fromMagToNorthAve, TotalPrice;

                MagToNorthAve = lbl2NorthAve.Text;
                fromMagToNorthAve = lbl_Magallanes.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromMagToNorthAve(MagToNorthAve.ToString());
                TF.fromMagToNorthAve2(fromMagToNorthAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void lblGMAKAMUNING_Click(object sender, EventArgs e)
        {

        }

        private void lbl_NorthAve_Click(object sender, EventArgs e)
        {

        }

        private void rb2_AyalaAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_AyalaAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb2_Buendia_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_Buendia.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb2_Guadalupe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_Guadalupe.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb2_BoniAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_BoniAve.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb2_ShawBoulevard_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_ShawBoulevard.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb2_Ortigas_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_Ortigas.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb2_Santolan_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_Santolan.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb2_AranetaCubao_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_AranetaCubao.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb2_GMA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_GMA.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb2_QuezonAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_QuezonAve.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb2_NorthAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_NorthAve.Checked == true)
            {
                lblPrice.Text = "28.00";
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }
    }
}

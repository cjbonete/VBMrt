﻿namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    partial class SMRT7_DA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label5;
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblNA = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.rb_QC = new System.Windows.Forms.RadioButton();
            this.lblQC = new System.Windows.Forms.Label();
            this.lblTS = new System.Windows.Forms.Label();
            this.rb_TS = new System.Windows.Forms.RadioButton();
            this.lblUA = new System.Windows.Forms.Label();
            this.rb_UA = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.rb_NA = new System.Windows.Forms.RadioButton();
            this.lbl_DA = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.lblPrice = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label2.Location = new System.Drawing.Point(741, 153);
            label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(351, 29);
            label2.TabIndex = 1;
            label2.Text = "SELECT YOUR DESTINATION";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label3.Location = new System.Drawing.Point(904, 373);
            label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(132, 29);
            label3.TabIndex = 3;
            label3.Text = "Ticket fare:";
            label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label5.Location = new System.Drawing.Point(249, 336);
            label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(219, 46);
            label5.TabIndex = 3;
            label5.Text = "STATIONS";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(29, 95);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1768, 191);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ITZeyyyyy_TRAIN_TICKET_SYSTEM.Properties.Resources.metro_station;
            this.pictureBox2.Location = new System.Drawing.Point(191, 42);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(257, 123);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(476, 63);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(988, 91);
            this.label1.TabIndex = 0;
            this.label1.Text = "DON ANTONIO STATION";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblNA);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.rb_QC);
            this.panel2.Controls.Add(this.lblQC);
            this.panel2.Controls.Add(this.lblTS);
            this.panel2.Controls.Add(this.rb_TS);
            this.panel2.Controls.Add(this.lblUA);
            this.panel2.Controls.Add(this.rb_UA);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.rb_NA);
            this.panel2.Controls.Add(this.lbl_DA);
            this.panel2.Location = new System.Drawing.Point(81, 373);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(587, 528);
            this.panel2.TabIndex = 2;
            // 
            // lblNA
            // 
            this.lblNA.AutoSize = true;
            this.lblNA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblNA.Location = new System.Drawing.Point(229, 311);
            this.lblNA.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNA.Name = "lblNA";
            this.lblNA.Size = new System.Drawing.Size(118, 17);
            this.lblNA.TabIndex = 36;
            this.lblNA.Text = "NORTH AVENUE";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel5.Location = new System.Drawing.Point(405, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(181, 1);
            this.panel5.TabIndex = 12;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel3.Location = new System.Drawing.Point(585, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1, 492);
            this.panel3.TabIndex = 11;
            // 
            // rb_QC
            // 
            this.rb_QC.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_QC.AutoSize = true;
            this.rb_QC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_QC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_QC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_QC.ForeColor = System.Drawing.Color.White;
            this.rb_QC.Location = new System.Drawing.Point(177, 254);
            this.rb_QC.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_QC.Name = "rb_QC";
            this.rb_QC.Padding = new System.Windows.Forms.Padding(31, 0, 31, 0);
            this.rb_QC.Size = new System.Drawing.Size(206, 43);
            this.rb_QC.TabIndex = 10;
            this.rb_QC.TabStop = true;
            this.rb_QC.Text = "QC Circle";
            this.rb_QC.UseVisualStyleBackColor = false;
            this.rb_QC.CheckedChanged += new System.EventHandler(this.rb_QC_CheckedChanged);
            // 
            // lblQC
            // 
            this.lblQC.AutoSize = true;
            this.lblQC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblQC.Location = new System.Drawing.Point(237, 238);
            this.lblQC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQC.Name = "lblQC";
            this.lblQC.Size = new System.Drawing.Size(80, 17);
            this.lblQC.TabIndex = 32;
            this.lblQC.Text = "QC CIRCLE";
            // 
            // lblTS
            // 
            this.lblTS.AutoSize = true;
            this.lblTS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblTS.Location = new System.Drawing.Point(219, 100);
            this.lblTS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTS.Name = "lblTS";
            this.lblTS.Size = new System.Drawing.Size(119, 17);
            this.lblTS.TabIndex = 34;
            this.lblTS.Text = "TANDANG SORA";
            // 
            // rb_TS
            // 
            this.rb_TS.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_TS.AutoSize = true;
            this.rb_TS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_TS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_TS.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_TS.ForeColor = System.Drawing.Color.White;
            this.rb_TS.Location = new System.Drawing.Point(177, 116);
            this.rb_TS.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_TS.Name = "rb_TS";
            this.rb_TS.Padding = new System.Windows.Forms.Padding(13, 0, 13, 0);
            this.rb_TS.Size = new System.Drawing.Size(204, 41);
            this.rb_TS.TabIndex = 33;
            this.rb_TS.TabStop = true;
            this.rb_TS.Text = "Tandang Sora";
            this.rb_TS.UseVisualStyleBackColor = false;
            this.rb_TS.CheckedChanged += new System.EventHandler(this.rb_TS_CheckedChanged);
            // 
            // lblUA
            // 
            this.lblUA.AutoSize = true;
            this.lblUA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblUA.Location = new System.Drawing.Point(219, 171);
            this.lblUA.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUA.Name = "lblUA";
            this.lblUA.Size = new System.Drawing.Size(120, 17);
            this.lblUA.TabIndex = 31;
            this.lblUA.Text = "UNIVERSITY AVE";
            // 
            // rb_UA
            // 
            this.rb_UA.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_UA.AutoSize = true;
            this.rb_UA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_UA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_UA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_UA.ForeColor = System.Drawing.Color.White;
            this.rb_UA.Location = new System.Drawing.Point(177, 187);
            this.rb_UA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_UA.Name = "rb_UA";
            this.rb_UA.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.rb_UA.Size = new System.Drawing.Size(205, 41);
            this.rb_UA.TabIndex = 12;
            this.rb_UA.TabStop = true;
            this.rb_UA.Text = "University Ave";
            this.rb_UA.UseVisualStyleBackColor = false;
            this.rb_UA.CheckedChanged += new System.EventHandler(this.rb_UA_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 492);
            this.panel4.TabIndex = 10;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel6.Location = new System.Drawing.Point(4, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(181, 1);
            this.panel6.TabIndex = 11;
            // 
            // rb_NA
            // 
            this.rb_NA.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_NA.AutoSize = true;
            this.rb_NA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_NA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_NA.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_NA.ForeColor = System.Drawing.Color.White;
            this.rb_NA.Location = new System.Drawing.Point(179, 334);
            this.rb_NA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rb_NA.Name = "rb_NA";
            this.rb_NA.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb_NA.Size = new System.Drawing.Size(202, 43);
            this.rb_NA.TabIndex = 35;
            this.rb_NA.TabStop = true;
            this.rb_NA.Text = "North Avenue";
            this.rb_NA.UseVisualStyleBackColor = false;
            this.rb_NA.CheckedChanged += new System.EventHandler(this.rb_NA_CheckedChanged);
            // 
            // lbl_DA
            // 
            this.lbl_DA.AutoSize = true;
            this.lbl_DA.Location = new System.Drawing.Point(207, 352);
            this.lbl_DA.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_DA.Name = "lbl_DA";
            this.lbl_DA.Size = new System.Drawing.Size(161, 17);
            this.lbl_DA.TabIndex = 32;
            this.lbl_DA.Text = "SMRT 7 DON ANTONIO";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1117, 489);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 54);
            this.label4.TabIndex = 8;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(1489, 725);
            this.button14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(187, 41);
            this.button14.TabIndex = 9;
            this.button14.Text = "CASH";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(845, 540);
            this.lblPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(310, 139);
            this.lblPrice.TabIndex = 30;
            this.lblPrice.Text = "0.00";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(909, 820);
            this.button13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(187, 41);
            this.button13.TabIndex = 7;
            this.button13.Text = "BACK";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Window;
            this.button1.Location = new System.Drawing.Point(1489, 820);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(187, 41);
            this.button1.TabIndex = 31;
            this.button1.Text = "CARD";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // SMRT7_DA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1827, 890);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(label5);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.label4);
            this.Controls.Add(label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "SMRT7_DA";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "xfdxds";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.North_Ave_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton rb_QC;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.RadioButton rb_UA;
        private System.Windows.Forms.Label lblUA;
        private System.Windows.Forms.Label lbl_DA;
        private System.Windows.Forms.Label lblQC;
        private System.Windows.Forms.Label lblTS;
        private System.Windows.Forms.RadioButton rb_TS;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblNA;
        private System.Windows.Forms.RadioButton rb_NA;
    }
}
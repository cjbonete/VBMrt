﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SBUENDIA : Form
    {
        public SBUENDIA()
        {
            InitializeComponent();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb4_Guadalupe.Checked == true && lblPrice.Text != "0.00")
            {

                string BuendiaToGuadalupe, fromBuendiaToGuadalupe, TotalPrice;

                BuendiaToGuadalupe = lbl4Guadalupe.Text;
                fromBuendiaToGuadalupe = lbl_Buendia.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBuendiaToGuadalupe(BuendiaToGuadalupe.ToString());
                TF.fromBuendiaToGuadalupe2(fromBuendiaToGuadalupe.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb4_BoniAve.Checked == true && lblPrice.Text != "0.00")
            {

                string BuendiaToBoniAve, fromBuendiaToBoniAve, TotalPrice;

                BuendiaToBoniAve = lbl4BoniAve.Text;
                fromBuendiaToBoniAve = lbl_Buendia.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBuendiaToBoniAve(BuendiaToBoniAve.ToString());
                TF.fromBuendiaToBoniAve2(fromBuendiaToBoniAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb4_ShawBoulevard.Checked == true && lblPrice.Text != "0.00")
            {

                string BuendiaToShawBoulevard, fromBuendiaToShawBoulevard, TotalPrice;

                BuendiaToShawBoulevard = lbl4ShawBoulevard.Text;
                fromBuendiaToShawBoulevard = lbl_Buendia.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBuendiaToShawBoulevard(BuendiaToShawBoulevard.ToString());
                TF.fromBuendiaToShawBoulevard2(fromBuendiaToShawBoulevard.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb4_Ortigas.Checked == true && lblPrice.Text != "0.00")
            {

                string BuendiaToOrtigas, fromBuendiaToOrtigas, TotalPrice;

                BuendiaToOrtigas = lbl4Ortigas.Text;
                fromBuendiaToOrtigas = lbl_Buendia.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBuendiaToOrtigas(BuendiaToOrtigas.ToString());
                TF.fromBuendiaToOrtigas2(fromBuendiaToOrtigas.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb4_Santolan.Checked == true && lblPrice.Text != "0.00")
            {

                string BuendiaToSantolan, fromBuendiaToSantolan, TotalPrice;

                BuendiaToSantolan = lbl4Santolan.Text;
                fromBuendiaToSantolan = lbl_Buendia.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBuendiaToSantolan(BuendiaToSantolan.ToString());
                TF.fromBuendiaToSantolan2(fromBuendiaToSantolan.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb4_AranetaCubao.Checked == true && lblPrice.Text != "0.00")
            {

                string BuendiaToAraneta, fromBuendiaToAraneta, TotalPrice;

                BuendiaToAraneta = lbl4AranetaCubao.Text;
                fromBuendiaToAraneta = lbl_Buendia.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBuendiaToAraneta(BuendiaToAraneta.ToString());
                TF.fromBuendiaToAraneta2(fromBuendiaToAraneta.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb4_GMA.Checked == true && lblPrice.Text != "0.00")
            {

                string BuendiaToGMAKamuning, fromBuendiaToGMAKamuning, TotalPrice;

                BuendiaToGMAKamuning = lbl4GMAKAMUNING.Text;
                fromBuendiaToGMAKamuning = lbl_Buendia.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBuendiaToGMAKamuning(BuendiaToGMAKamuning.ToString());
                TF.fromBuendiaToGMAKamuning2(fromBuendiaToGMAKamuning.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb4_QuezonAve.Checked == true && lblPrice.Text != "0.00")
            {

                string BuendiaToQuezonAve, fromBuendiaToQuezonAve, TotalPrice;

                BuendiaToQuezonAve = lbl4QuezonAve.Text;
                fromBuendiaToQuezonAve = lbl_Buendia.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();

                TF.fromBuendiaToQuezonAve(BuendiaToQuezonAve.ToString());
                TF.fromBuendiaToQuezonAve2(fromBuendiaToQuezonAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();
            }

            else if (rb4_NorthAve.Checked == true && lblPrice.Text != "0.00")
            {

                string BuendiaToNorthAve, fromBuendiaToNorthAve, TotalPrice;

                BuendiaToNorthAve = lbl4NorthAve.Text;
                fromBuendiaToNorthAve = lbl_Buendia.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBuendiaToNorthAve(BuendiaToNorthAve.ToString());
                TF.fromBuendiaToNorthAve2(fromBuendiaToNorthAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }
        }

        private void Araneta_Load(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
           
        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void rb4_Guadalupe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_Guadalupe.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb4_BoniAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_BoniAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb4_ShawBoulevard_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_ShawBoulevard.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb4_Ortigas_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_Ortigas.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb4_Santolan_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_Santolan.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb4_AranetaCubao_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_AranetaCubao.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb4_GMA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_GMA.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb4_QuezonAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_QuezonAve.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb4_NorthAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb4_NorthAve.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

    }
}

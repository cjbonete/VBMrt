﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SSANTOLAN : Form
    {
        public SSANTOLAN()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb9_AranetaCubao.Checked == true && lblPrice.Text != "0.00")
            {

                string SantolanToAraneta, fromSantolanToAraneta, TotalPrice;

                SantolanToAraneta = lbl9AranetaCubao.Text;
                fromSantolanToAraneta = lbl_Santolan.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromSantolanToAraneta(SantolanToAraneta.ToString());
                TF.fromSantolanToAraneta2(fromSantolanToAraneta.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb9_GMA.Checked == true && lblPrice.Text != "0.00")
            {

                string SantolanToGMAKamuning, fromSantolanToGMAKamuning, TotalPrice;

                SantolanToGMAKamuning = lbl9GMAKAMUNING.Text;
                fromSantolanToGMAKamuning = lbl_Santolan.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromSantolanToGMAKamuning(SantolanToGMAKamuning.ToString());
                TF.fromSantolanToGMAKamuning2(fromSantolanToGMAKamuning.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb9_QuezonAve.Checked == true && lblPrice.Text != "0.00")
            {

                string SantolanToQuezonAve, fromSantolanToQuezonAve, TotalPrice;

                SantolanToQuezonAve = lbl9QuezonAve.Text;
                fromSantolanToQuezonAve = lbl_Santolan.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();

                TF.fromSantolanToQuezonAve(SantolanToQuezonAve.ToString());
                TF.fromSantolanToQuezonAve2(fromSantolanToQuezonAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();
            }

            else if (rb9_NorthAve.Checked == true && lblPrice.Text != "0.00")
            {

                string SantolanToNorthAve, fromSantolanToNorthAve, TotalPrice;

                SantolanToNorthAve = lbl9NorthAve.Text;
                fromSantolanToNorthAve = lbl_Santolan.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromSantolanToNorthAve(SantolanToNorthAve.ToString());
                TF.fromSantolanToNorthAve2(fromSantolanToNorthAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void rb9_AranetaCubao_CheckedChanged(object sender, EventArgs e)
        {
            if (rb9_AranetaCubao.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb9_GMA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb9_GMA.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb9_QuezonAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb9_QuezonAve.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb9_NorthAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb9_NorthAve.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }
    }
}

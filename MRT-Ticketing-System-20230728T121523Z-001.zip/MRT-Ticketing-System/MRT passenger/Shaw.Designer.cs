﻿namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    partial class Shaw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label6;
            this.label4 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_Shaw = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rb7_AyalaAve = new System.Windows.Forms.RadioButton();
            this.lbl7TaftAve = new System.Windows.Forms.Label();
            this.rb7_TaftAve = new System.Windows.Forms.RadioButton();
            this.lbl7Magallanes = new System.Windows.Forms.Label();
            this.lbl7AyalaAve = new System.Windows.Forms.Label();
            this.rb7_Magallanes = new System.Windows.Forms.RadioButton();
            this.lbl7Buendia = new System.Windows.Forms.Label();
            this.lbl7Guadalupe = new System.Windows.Forms.Label();
            this.rb7_Buendia = new System.Windows.Forms.RadioButton();
            this.lbl7BoniAve = new System.Windows.Forms.Label();
            this.rb7_Guadalupe = new System.Windows.Forms.RadioButton();
            this.rb7_BoniAve = new System.Windows.Forms.RadioButton();
            this.lblPrice = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label2.Location = new System.Drawing.Point(556, 118);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(272, 24);
            label2.TabIndex = 1;
            label2.Text = "SELECT YOUR DESTINATION";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label3.Location = new System.Drawing.Point(672, 286);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(101, 24);
            label3.TabIndex = 12;
            label3.Text = "Ticket fare:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label6.Location = new System.Drawing.Point(165, 256);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(178, 37);
            label6.TabIndex = 64;
            label6.Text = "STATIONS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(832, 380);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 42);
            this.label4.TabIndex = 16;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(1175, 649);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(140, 33);
            this.button14.TabIndex = 17;
            this.button14.Text = "PROCEED";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(16, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1326, 155);
            this.panel1.TabIndex = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ITZeyyyyy_TRAIN_TICKET_SYSTEM.Properties.Resources.metro_station;
            this.pictureBox2.Location = new System.Drawing.Point(143, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(193, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(314, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(972, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = " SHAW BOULEVARD STATION";
            // 
            // lbl_Shaw
            // 
            this.lbl_Shaw.AutoSize = true;
            this.lbl_Shaw.ForeColor = System.Drawing.Color.White;
            this.lbl_Shaw.Location = new System.Drawing.Point(252, 82);
            this.lbl_Shaw.Name = "lbl_Shaw";
            this.lbl_Shaw.Size = new System.Drawing.Size(109, 13);
            this.lbl_Shaw.TabIndex = 69;
            this.lbl_Shaw.Text = "SHAW BOULEVARD";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel5.Location = new System.Drawing.Point(35, 286);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 400);
            this.panel5.TabIndex = 68;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel9.Location = new System.Drawing.Point(447, 286);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1, 400);
            this.panel9.TabIndex = 67;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel4.Location = new System.Drawing.Point(35, 286);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(136, 1);
            this.panel4.TabIndex = 66;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel8.Location = new System.Drawing.Point(312, 286);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(136, 1);
            this.panel8.TabIndex = 65;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rb7_AyalaAve);
            this.panel2.Controls.Add(this.lbl7TaftAve);
            this.panel2.Controls.Add(this.lbl_Shaw);
            this.panel2.Controls.Add(this.rb7_TaftAve);
            this.panel2.Controls.Add(this.lbl7Magallanes);
            this.panel2.Controls.Add(this.lbl7AyalaAve);
            this.panel2.Controls.Add(this.rb7_Magallanes);
            this.panel2.Controls.Add(this.lbl7Buendia);
            this.panel2.Controls.Add(this.lbl7Guadalupe);
            this.panel2.Controls.Add(this.rb7_Buendia);
            this.panel2.Controls.Add(this.lbl7BoniAve);
            this.panel2.Controls.Add(this.rb7_Guadalupe);
            this.panel2.Controls.Add(this.rb7_BoniAve);
            this.panel2.Location = new System.Drawing.Point(35, 286);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(413, 429);
            this.panel2.TabIndex = 63;
            // 
            // rb7_AyalaAve
            // 
            this.rb7_AyalaAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb7_AyalaAve.AutoSize = true;
            this.rb7_AyalaAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb7_AyalaAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb7_AyalaAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb7_AyalaAve.ForeColor = System.Drawing.Color.White;
            this.rb7_AyalaAve.Location = new System.Drawing.Point(223, 67);
            this.rb7_AyalaAve.Name = "rb7_AyalaAve";
            this.rb7_AyalaAve.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.rb7_AyalaAve.Size = new System.Drawing.Size(157, 37);
            this.rb7_AyalaAve.TabIndex = 71;
            this.rb7_AyalaAve.TabStop = true;
            this.rb7_AyalaAve.Text = "Ayala Ave.";
            this.rb7_AyalaAve.UseVisualStyleBackColor = false;
            this.rb7_AyalaAve.CheckedChanged += new System.EventHandler(this.rb7_AyalaAve_CheckedChanged);
            // 
            // lbl7TaftAve
            // 
            this.lbl7TaftAve.AutoSize = true;
            this.lbl7TaftAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl7TaftAve.Location = new System.Drawing.Point(260, 183);
            this.lbl7TaftAve.Name = "lbl7TaftAve";
            this.lbl7TaftAve.Size = new System.Drawing.Size(81, 13);
            this.lbl7TaftAve.TabIndex = 70;
            this.lbl7TaftAve.Text = "TAFT AVENUE";
            // 
            // rb7_TaftAve
            // 
            this.rb7_TaftAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb7_TaftAve.AutoSize = true;
            this.rb7_TaftAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb7_TaftAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb7_TaftAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb7_TaftAve.ForeColor = System.Drawing.Color.White;
            this.rb7_TaftAve.Location = new System.Drawing.Point(223, 202);
            this.rb7_TaftAve.Name = "rb7_TaftAve";
            this.rb7_TaftAve.Padding = new System.Windows.Forms.Padding(22, 0, 22, 0);
            this.rb7_TaftAve.Size = new System.Drawing.Size(154, 37);
            this.rb7_TaftAve.TabIndex = 69;
            this.rb7_TaftAve.TabStop = true;
            this.rb7_TaftAve.Text = "Taft Ave.";
            this.rb7_TaftAve.UseVisualStyleBackColor = false;
            this.rb7_TaftAve.CheckedChanged += new System.EventHandler(this.rb7_TaftAve_CheckedChanged);
            // 
            // lbl7Magallanes
            // 
            this.lbl7Magallanes.AutoSize = true;
            this.lbl7Magallanes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl7Magallanes.Location = new System.Drawing.Point(260, 117);
            this.lbl7Magallanes.Name = "lbl7Magallanes";
            this.lbl7Magallanes.Size = new System.Drawing.Size(79, 13);
            this.lbl7Magallanes.TabIndex = 57;
            this.lbl7Magallanes.Text = "MAGALLANES";
            // 
            // lbl7AyalaAve
            // 
            this.lbl7AyalaAve.AutoSize = true;
            this.lbl7AyalaAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl7AyalaAve.Location = new System.Drawing.Point(252, 47);
            this.lbl7AyalaAve.Name = "lbl7AyalaAve";
            this.lbl7AyalaAve.Size = new System.Drawing.Size(88, 13);
            this.lbl7AyalaAve.TabIndex = 68;
            this.lbl7AyalaAve.Text = "AYALA AVENUE";
            // 
            // rb7_Magallanes
            // 
            this.rb7_Magallanes.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb7_Magallanes.AutoSize = true;
            this.rb7_Magallanes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb7_Magallanes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb7_Magallanes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb7_Magallanes.ForeColor = System.Drawing.Color.White;
            this.rb7_Magallanes.Location = new System.Drawing.Point(223, 136);
            this.rb7_Magallanes.Name = "rb7_Magallanes";
            this.rb7_Magallanes.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.rb7_Magallanes.Size = new System.Drawing.Size(155, 37);
            this.rb7_Magallanes.TabIndex = 52;
            this.rb7_Magallanes.TabStop = true;
            this.rb7_Magallanes.Text = "Magallanes";
            this.rb7_Magallanes.UseVisualStyleBackColor = false;
            this.rb7_Magallanes.CheckedChanged += new System.EventHandler(this.rb7_Magallanes_CheckedChanged);
            // 
            // lbl7Buendia
            // 
            this.lbl7Buendia.AutoSize = true;
            this.lbl7Buendia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl7Buendia.Location = new System.Drawing.Point(81, 181);
            this.lbl7Buendia.Name = "lbl7Buendia";
            this.lbl7Buendia.Size = new System.Drawing.Size(55, 13);
            this.lbl7Buendia.TabIndex = 56;
            this.lbl7Buendia.Text = "BUENDIA";
            // 
            // lbl7Guadalupe
            // 
            this.lbl7Guadalupe.AutoSize = true;
            this.lbl7Guadalupe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl7Guadalupe.Location = new System.Drawing.Point(81, 112);
            this.lbl7Guadalupe.Name = "lbl7Guadalupe";
            this.lbl7Guadalupe.Size = new System.Drawing.Size(73, 13);
            this.lbl7Guadalupe.TabIndex = 58;
            this.lbl7Guadalupe.Text = "GUADALUPE";
            // 
            // rb7_Buendia
            // 
            this.rb7_Buendia.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb7_Buendia.AutoSize = true;
            this.rb7_Buendia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb7_Buendia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb7_Buendia.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb7_Buendia.ForeColor = System.Drawing.Color.White;
            this.rb7_Buendia.Location = new System.Drawing.Point(31, 201);
            this.rb7_Buendia.Name = "rb7_Buendia";
            this.rb7_Buendia.Padding = new System.Windows.Forms.Padding(28, 0, 28, 0);
            this.rb7_Buendia.Size = new System.Drawing.Size(159, 37);
            this.rb7_Buendia.TabIndex = 51;
            this.rb7_Buendia.TabStop = true;
            this.rb7_Buendia.Text = "Buendia";
            this.rb7_Buendia.UseVisualStyleBackColor = false;
            this.rb7_Buendia.CheckedChanged += new System.EventHandler(this.rb7_Buendia_CheckedChanged);
            // 
            // lbl7BoniAve
            // 
            this.lbl7BoniAve.AutoSize = true;
            this.lbl7BoniAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl7BoniAve.Location = new System.Drawing.Point(76, 43);
            this.lbl7BoniAve.Name = "lbl7BoniAve";
            this.lbl7BoniAve.Size = new System.Drawing.Size(80, 13);
            this.lbl7BoniAve.TabIndex = 66;
            this.lbl7BoniAve.Text = "BONI AVENUE";
            // 
            // rb7_Guadalupe
            // 
            this.rb7_Guadalupe.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb7_Guadalupe.AutoSize = true;
            this.rb7_Guadalupe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb7_Guadalupe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb7_Guadalupe.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb7_Guadalupe.ForeColor = System.Drawing.Color.White;
            this.rb7_Guadalupe.Location = new System.Drawing.Point(31, 135);
            this.rb7_Guadalupe.Name = "rb7_Guadalupe";
            this.rb7_Guadalupe.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.rb7_Guadalupe.Size = new System.Drawing.Size(159, 37);
            this.rb7_Guadalupe.TabIndex = 54;
            this.rb7_Guadalupe.TabStop = true;
            this.rb7_Guadalupe.Text = "Guadalupe";
            this.rb7_Guadalupe.UseVisualStyleBackColor = false;
            this.rb7_Guadalupe.CheckedChanged += new System.EventHandler(this.rb7_Guadalupe_CheckedChanged);
            // 
            // rb7_BoniAve
            // 
            this.rb7_BoniAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb7_BoniAve.AutoSize = true;
            this.rb7_BoniAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb7_BoniAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb7_BoniAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb7_BoniAve.ForeColor = System.Drawing.Color.White;
            this.rb7_BoniAve.Location = new System.Drawing.Point(31, 67);
            this.rb7_BoniAve.Name = "rb7_BoniAve";
            this.rb7_BoniAve.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.rb7_BoniAve.Size = new System.Drawing.Size(156, 37);
            this.rb7_BoniAve.TabIndex = 65;
            this.rb7_BoniAve.TabStop = true;
            this.rb7_BoniAve.Text = "Boni Ave.";
            this.rb7_BoniAve.UseVisualStyleBackColor = false;
            this.rb7_BoniAve.CheckedChanged += new System.EventHandler(this.rb7_BoniAve_CheckedChanged);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(637, 422);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(248, 111);
            this.lblPrice.TabIndex = 73;
            this.lblPrice.Text = "0.00";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(676, 649);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 33);
            this.button1.TabIndex = 74;
            this.button1.Text = "BACK";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Shaw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1354, 703);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel8);
            this.Controls.Add(label6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button14);
            this.Controls.Add(label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Shaw";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Shaw";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Shaw_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_Shaw;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl7Buendia;
        private System.Windows.Forms.Label lbl7Guadalupe;
        private System.Windows.Forms.RadioButton rb7_Buendia;
        private System.Windows.Forms.Label lbl7BoniAve;
        private System.Windows.Forms.RadioButton rb7_Guadalupe;
        private System.Windows.Forms.RadioButton rb7_BoniAve;
        private System.Windows.Forms.Label lbl7TaftAve;
        private System.Windows.Forms.RadioButton rb7_TaftAve;
        private System.Windows.Forms.Label lbl7Magallanes;
        private System.Windows.Forms.Label lbl7AyalaAve;
        private System.Windows.Forms.RadioButton rb7_Magallanes;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.RadioButton rb7_AyalaAve;
        private System.Windows.Forms.Button button1;
    }
}
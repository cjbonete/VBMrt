﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SMRT7_BT : Form
    {



        public SMRT7_BT()
        {
            InitializeComponent();
        }

        private void North_Ave_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form11 frm11 = new Form11();

            frm11.ShowDialog();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb_DA.Checked == true && lblPrice.Text != "0.00")
            {

                string SJDMToDA, fromSJDMToDA, TotalPrice;

                SJDMToDA = lblDA.Text;
                fromSJDMToDA = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromSJDMToTala(SJDMToDA.ToString());
                GMA2.fromSJDMToTala2(fromSJDMToDA.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
            else if (rb_TS.Checked == true && lblPrice.Text != "0.00")
            {

                string SJDMToTS, fromSJDMToTS, TotalPrice;

                SJDMToTS = lblTS.Text;
                fromSJDMToTS = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromSJDMToTala(SJDMToTS.ToString());
                GMA2.fromSJDMToTala2(fromSJDMToTS.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
            else if (rb_UA.Checked == true && lblPrice.Text != "0.00")
            {

                string SJDMToUA, fromSJDMToUA, TotalPrice;

                SJDMToUA = lblUA.Text;
                fromSJDMToUA = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromSJDMToTala(SJDMToUA.ToString());
                GMA2.fromSJDMToTala2(fromSJDMToUA.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
            else if (rb_QC.Checked == true && lblPrice.Text != "0.00")
            {

                string SJDMToQC, fromSJDMToQC, TotalPrice;

                SJDMToQC = lblQC.Text;
                fromSJDMToQC = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromSJDMToTala(SJDMToQC.ToString());
                GMA2.fromSJDMToTala2(fromSJDMToQC.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
            else if (rb_NA.Checked == true && lblPrice.Text != "0.00")
            {

                string SJDMToNA, fromSJDMToNA, TotalPrice;

                SJDMToNA = lblNA.Text;
                fromSJDMToNA = lbl_BT.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromSJDMToTala(SJDMToNA.ToString());
                GMA2.fromSJDMToTala2(fromSJDMToNA.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form22 frm22 = new Form22();

            frm22.ShowDialog();
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void rb_DA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_DA.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb_TS_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_TS.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb_UA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_UA.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb_QC_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_QC.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb_NA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_NA.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

    }
}

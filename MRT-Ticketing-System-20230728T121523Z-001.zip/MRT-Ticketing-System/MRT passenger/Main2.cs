﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Main2 : Form
    {
        public Main2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form11 f11 = new Form11();

            f11.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form22 f22 = new Form22();

            f22.ShowDialog();
        }

        private void Main2_Load(object sender, EventArgs e)
        {

        }
    }
}

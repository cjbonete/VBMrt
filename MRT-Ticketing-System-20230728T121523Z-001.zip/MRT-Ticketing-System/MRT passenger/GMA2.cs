﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class lblTot : Form

    {
        private OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\khyrex\Desktop\MRT-Ticketing-System\MRTDB.accdb");

        public lblTot()
        {
            InitializeComponent();

        }

        private void GMA2_Load(object sender, EventArgs e)
        {
            timer.Start();
            int randomNum;

            Random random = new Random();
            randomNum = random.Next(999999, 10000000);

            lblRand.Text = ("" + randomNum);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (lbl_FromLocation.Text == "NORTH AVENUE")
            {
                this.Hide();
                North_Ave NorthAve = new North_Ave();
                NorthAve.ShowDialog();

            }

            else if (lbl_FromLocation.Text == "QUEZON AVENUE")
            {
                this.Hide();
                Quezon_Ave QC = new Quezon_Ave();
                QC.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "GMA KAMUNING")
            {
                this.Hide();
                GMA gma = new GMA();
                gma.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "ARANETA CUBAO")
            {
                this.Hide();
                Araneta araneta = new Araneta();
                araneta.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "SANTOLAN")
            {
                this.Hide();
                Santolan santolan = new Santolan();
                santolan.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "ORTIGAS")
            {
                this.Hide();
                Ortigas ortigas = new Ortigas();
                ortigas.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "SHAW BOULEVARD")
            {
                this.Hide();
                Shaw shaw = new Shaw();
                shaw.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "BONIFACIO AVE")
            {
                this.Hide();
                Boni boni = new Boni();
                boni.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "GUADALUPE")
            {
                this.Hide();
                Guada guada = new Guada();
                guada.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "AYALA")
            {
                this.Hide();
                Ayala ayala = new Ayala();
                ayala.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MAGALLANES")
            {
                this.Hide();
                Magallanes magallanes = new Magallanes();
                magallanes.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "TAFT AVE")
            {
                this.Hide();
                Taft taft = new Taft();
                taft.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 NORTH AVENUE")
            {
                this.Hide();
                MRT7_NA MRT7_NA = new MRT7_NA();
                MRT7_NA.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 QC CIRCLE")
            {
                this.Hide();
                MRT7_QC MRT7_QC = new MRT7_QC();
                MRT7_QC.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 UNIVERSITY AVE")
            {
                this.Hide();
                MRT7_UA MRT7_UA = new MRT7_UA();
                MRT7_UA.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 TANDANG SORA")
            {
                this.Hide();
                MRT7_TS MRT7_TS = new MRT7_TS();
                MRT7_TS.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 DON ANTONIO")
            {
                this.Hide();
                MRT7_DA MRT7_DA = new MRT7_DA();
                MRT7_DA.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 BATASAN")
            {
                this.Hide();
                MRT7_BT MRT7_BT = new MRT7_BT();
                MRT7_BT.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 MANGGAHAN")
            {
                this.Hide();
                MRT7_MG MRT7_MG = new MRT7_MG();
                MRT7_MG.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 DON CARMEN")
            {
                this.Hide();
                MRT7_DC MRT7_DC = new MRT7_DC();
                MRT7_DC.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 REGALADO")
            {
                this.Hide();
                MRT7_RG MRT7_RG = new MRT7_RG();
                MRT7_RG.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 MINDANAO AVE")
            {
                this.Hide();
                MRT7_MA MRT7_MA = new MRT7_MA();
                MRT7_MA.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 QUIRINO")
            {
                this.Hide();
                MRT7_QR MRT7_QR = new MRT7_QR();
                MRT7_QR.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 SACRED HEART")
            {
                this.Hide();
                MRT7_SH MRT7_SH = new MRT7_SH();
                MRT7_SH.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 TALA")
            {
                this.Hide();
                MRT7_TL MRT7_TL = new MRT7_TL();
                MRT7_TL.ShowDialog();
            }
            else if (lbl_FromLocation.Text == "MRT 7 SJDM")
            {
                this.Hide();
                MRT7_SJ MRT7_SJ = new MRT7_SJ();
                MRT7_SJ.ShowDialog();
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lbl_Location_Click(object sender, EventArgs e)
        {

        }

        // NORTH AVENUEEEEEEEEEEEE

        public void fromNorthAveToGMAKamuning(string fromNorthAveToGMAKamuning)
        {

            fromNorthAveToGMAKamuning.ToString();
            lbl_Location.Text = fromNorthAveToGMAKamuning.ToString();

        }

        public void fromNorthAveToGMAKamuning2(string fromNorthAveToGMAKamuning2)
        {

            fromNorthAveToGMAKamuning2.ToString();
            lbl_FromLocation.Text = fromNorthAveToGMAKamuning2.ToString();

        }
        public void fromNorthAveToQuezonAve(string fromNorthAveToQuezonAve)
        {

            fromNorthAveToQuezonAve.ToString();
            lbl_Location.Text = fromNorthAveToQuezonAve.ToString();


        }

        public void fromNorthAveToQuezonAve2(string fromNorthAveToQuezonAve2)
        {

            fromNorthAveToQuezonAve2.ToString();
            lbl_FromLocation.Text = fromNorthAveToQuezonAve2.ToString();


        }
        //
        public void fromNorthAveToAranetaCubao(string fromNorthAveToAranetaCubao)
        {

            fromNorthAveToAranetaCubao.ToString();
            lbl_Location.Text = fromNorthAveToAranetaCubao.ToString();


        }

        public void fromNorthAveToAranetaCubao2(string fromNorthAveToAranetaCubao2)
        {

            fromNorthAveToAranetaCubao2.ToString();
            lbl_FromLocation.Text = fromNorthAveToAranetaCubao2.ToString();


        }
        //
        public void fromNorthAveToSantolan(string fromNorthAveToSantolan)
        {

            fromNorthAveToSantolan.ToString();
            lbl_Location.Text = fromNorthAveToSantolan.ToString();


        }

        public void fromNorthAveToSantolan2(string fromNorthAveToSantolan2)
        {

            fromNorthAveToSantolan2.ToString();
            lbl_FromLocation.Text = fromNorthAveToSantolan2.ToString();


        }
        //
        public void fromNorthAveToOrtigas(string fromNorthAveToOrtigas)
        {

            fromNorthAveToOrtigas.ToString();
            lbl_Location.Text = fromNorthAveToOrtigas.ToString();


        }

        public void fromNorthAveToOrtigas2(string fromNorthAveToOrtigas2)
        {

            fromNorthAveToOrtigas2.ToString();
            lbl_FromLocation.Text = fromNorthAveToOrtigas2.ToString();


        }
        //
        public void fromNorthAveToShawBoulevard(string fromNorthAveToShawBoulevard)
        {

            fromNorthAveToShawBoulevard.ToString();
            lbl_Location.Text = fromNorthAveToShawBoulevard.ToString();


        }

        public void fromNorthAveToShawBoulevard2(string fromNorthAveToShawBoulevard2)
        {

            fromNorthAveToShawBoulevard2.ToString();
            lbl_FromLocation.Text = fromNorthAveToShawBoulevard2.ToString();


        }
        //
        public void fromNorthAveToBoniAve(string fromNorthAveToBoniAve)
        {

            fromNorthAveToBoniAve.ToString();
            lbl_Location.Text = fromNorthAveToBoniAve.ToString();


        }

        public void fromNorthAveToBoniAve2(string fromNorthAveToBoniAve2)
        {

            fromNorthAveToBoniAve2.ToString();
            lbl_FromLocation.Text = fromNorthAveToBoniAve2.ToString();


        }
        //
        public void fromNorthAveToGuadalupe(string fromNorthAveToGuadalupe)
        {

            fromNorthAveToGuadalupe.ToString();
            lbl_Location.Text = fromNorthAveToGuadalupe.ToString();


        }

        public void fromNorthAveToGuadalupe2(string fromNorthAveToGuadalupe2)
        {

            fromNorthAveToGuadalupe2.ToString();
            lbl_FromLocation.Text = fromNorthAveToGuadalupe2.ToString();


        }
        //
        public void fromNorthAveToBuendia(string fromNorthAveToBuendia)
        {

            fromNorthAveToBuendia.ToString();
            lbl_Location.Text = fromNorthAveToBuendia.ToString();


        }

        public void fromNorthAveToBuendia2(string fromNorthAveToBuendia2)
        {

            fromNorthAveToBuendia2.ToString();
            lbl_FromLocation.Text = fromNorthAveToBuendia2.ToString();


        }
        //
        public void fromNorthAveToAyalaAve(string fromNorthAveToAyalaAve)
        {

            fromNorthAveToAyalaAve.ToString();
            lbl_Location.Text = fromNorthAveToAyalaAve.ToString();


        }

        public void fromNorthAveToAyalaAve2(string fromNorthAveToAyalaAve2)
        {

            fromNorthAveToAyalaAve2.ToString();
            lbl_FromLocation.Text = fromNorthAveToAyalaAve2.ToString();


        }
        //
        public void fromNorthAveToMagallanes(string fromNorthAveToMagallanes)
        {

            fromNorthAveToMagallanes.ToString();
            lbl_Location.Text = fromNorthAveToMagallanes.ToString();


        }

        public void fromNorthAveToMagallanes2(string fromNorthAveToMagallanes2)
        {

            fromNorthAveToMagallanes2.ToString();
            lbl_FromLocation.Text = fromNorthAveToMagallanes2.ToString();


        }
        //
        public void fromNorthAveToTaftAve(string fromNorthAveToTaftAve)
        {

            fromNorthAveToTaftAve.ToString();
            lbl_Location.Text = fromNorthAveToTaftAve.ToString();


        }

        public void fromNorthAveToTaftAve2(string fromNorthAveToTaftAve2)
        {

            fromNorthAveToTaftAve2.ToString();
            lbl_FromLocation.Text = fromNorthAveToTaftAve2.ToString();


        }
        //

        //QUEZON AVEEEEEEE

        public void fromQuezonAveToGMAKamuning(string fromQuezonAveToGMAKamuning)
        {

            fromQuezonAveToGMAKamuning.ToString();
            lbl_Location.Text = fromQuezonAveToGMAKamuning.ToString();


        }
        public void fromQuezonAveToGMAKamuning2(string fromQuezonAveToGMAKamuning2)
        {

            fromQuezonAveToGMAKamuning2.ToString();
            lbl_FromLocation.Text = fromQuezonAveToGMAKamuning2.ToString();

        }
        //
        public void fromQuezonAveToAranetaCubao(string fromQuezonAveToAranetaCubao)
        {

            fromQuezonAveToAranetaCubao.ToString();
            lbl_Location.Text = fromQuezonAveToAranetaCubao.ToString();


        }
        public void fromQuezonAveToAranetaCubao2(string fromQuezonAveToAranetaCubao2)
        {

            fromQuezonAveToAranetaCubao2.ToString();
            lbl_FromLocation.Text = fromQuezonAveToAranetaCubao2.ToString();

        }
        //
        public void fromQuezonAveToSantolan(string fromQuezonAveToSantolan)
        {

            fromQuezonAveToSantolan.ToString();
            lbl_Location.Text = fromQuezonAveToSantolan.ToString();


        }
        public void fromQuezonAveToSantolan2(string fromQuezonAveToSantolan2)
        {

            fromQuezonAveToSantolan2.ToString();
            lbl_FromLocation.Text = fromQuezonAveToSantolan2.ToString();

        }
        //
        public void fromQuezonAveToOrtigas(string fromQuezonAveToOrtigas)
        {

            fromQuezonAveToOrtigas.ToString();
            lbl_Location.Text = fromQuezonAveToOrtigas.ToString();


        }
        public void fromQuezonAveToOrtigas2(string fromQuezonAveToOrtigas2)
        {

            fromQuezonAveToOrtigas2.ToString();
            lbl_FromLocation.Text = fromQuezonAveToOrtigas2.ToString();

        }
        //
        public void fromQuezonAveToShawBoulevard(string fromQuezonAveToShawBoulevard)
        {

            fromQuezonAveToShawBoulevard.ToString();
            lbl_Location.Text = fromQuezonAveToShawBoulevard.ToString();


        }
        public void fromQuezonAveToShawBoulevard2(string fromQuezonAveToShawBoulevard2)
        {

            fromQuezonAveToShawBoulevard2.ToString();
            lbl_FromLocation.Text = fromQuezonAveToShawBoulevard2.ToString();

        }
        //
        public void fromQuezonAveToBoni(string fromQuezonAveToBoni)
        {

            fromQuezonAveToBoni.ToString();
            lbl_Location.Text = fromQuezonAveToBoni.ToString();


        }
        public void fromQuezonAveToBoni2(string fromQuezonAveToBoni2)
        {

            fromQuezonAveToBoni2.ToString();
            lbl_FromLocation.Text = fromQuezonAveToBoni2.ToString();

        }
        //
        public void fromQuezonAveToGuadalupe(string fromQuezonAveToGuadalupe)
        {

            fromQuezonAveToGuadalupe.ToString();
            lbl_Location.Text = fromQuezonAveToGuadalupe.ToString();


        }
        public void fromQuezonAveToGuadalupe2(string fromQuezonAveToGuadalupe2)
        {

            fromQuezonAveToGuadalupe2.ToString();
            lbl_FromLocation.Text = fromQuezonAveToGuadalupe2.ToString();

        }
        //

        public void fromQuezonAveToBuendia(string fromQuezonAveToBuendia)
        {

            fromQuezonAveToBuendia.ToString();
            lbl_Location.Text = fromQuezonAveToBuendia.ToString();


        }
        public void fromQuezonAveToBuendia2(string fromQuezonAveToBuendia2)
        {

            fromQuezonAveToBuendia2.ToString();
            lbl_FromLocation.Text = fromQuezonAveToBuendia2.ToString();

        }
        //
        public void fromQuezonAveToAyala(string fromQuezonAveToAyala)
        {

            fromQuezonAveToAyala.ToString();
            lbl_Location.Text = fromQuezonAveToAyala.ToString();


        }
        public void fromQuezonAveToAyala2(string fromQuezonAveToAyala2)
        {

            fromQuezonAveToAyala2.ToString();
            lbl_FromLocation.Text = fromQuezonAveToAyala2.ToString();

        }
        //
        public void fromQuezonAveToMagallanes(string fromQuezonAveToMagallanes)
        {

            fromQuezonAveToMagallanes.ToString();
            lbl_Location.Text = fromQuezonAveToMagallanes.ToString();


        }
        public void fromQuezonAveToMagallanes2(string fromQuezonAveToMagallanes2)
        {

            fromQuezonAveToMagallanes2.ToString();
            lbl_FromLocation.Text = fromQuezonAveToMagallanes2.ToString();

        }
        //
        public void fromQuezonAveToTaftAve(string fromQuezonAveToTaftAve)
        {

            fromQuezonAveToTaftAve.ToString();
            lbl_Location.Text = fromQuezonAveToTaftAve.ToString();


        }
        public void fromQuezonAveToTaftAve2(string fromQuezonAveToTaftAve2)
        {

            fromQuezonAveToTaftAve2.ToString();
            lbl_FromLocation.Text = fromQuezonAveToTaftAve2.ToString();

        }
        //

        //GMA KAMUNINGGGGGGG
        public void fromGMAKamuningToAranetaCubao(string fromGMAKamuningToAranetaCubao)
        {

            fromGMAKamuningToAranetaCubao.ToString();
            lbl_Location.Text = fromGMAKamuningToAranetaCubao.ToString();


        }
        public void fromGMAKamuningToAranetaCubao2(string fromGMAKamuningToAranetaCubao2)
        {

            fromGMAKamuningToAranetaCubao2.ToString();
            lbl_FromLocation.Text = fromGMAKamuningToAranetaCubao2.ToString();

        }
        //
        public void fromGMAKamuningToSantolan(string fromGMAKamuningToSantolan)
        {

            fromGMAKamuningToSantolan.ToString();
            lbl_Location.Text = fromGMAKamuningToSantolan.ToString();


        }
        public void fromGMAKamuningToSantolan2(string fromGMAKamuningToSantolan2)
        {

            fromGMAKamuningToSantolan2.ToString();
            lbl_FromLocation.Text = fromGMAKamuningToSantolan2.ToString();

        }
        //
        public void fromGMAKamuningToOrtigas(string fromGMAKamuningToOrtigas)
        {

            fromGMAKamuningToOrtigas.ToString();
            lbl_Location.Text = fromGMAKamuningToOrtigas.ToString();


        }
        public void fromGMAKamuningToOrtigas2(string fromGMAKamuningToOrtigas2)
        {

            fromGMAKamuningToOrtigas2.ToString();
            lbl_FromLocation.Text = fromGMAKamuningToOrtigas2.ToString();

        }
        //

        public void fromGMAKamuningToShawBoulevard(string fromGMAKamuningToShawBoulevard)
        {

            fromGMAKamuningToShawBoulevard.ToString();
            lbl_Location.Text = fromGMAKamuningToShawBoulevard.ToString();


        }
        public void fromGMAKamuningToShawBoulevard2(string fromGMAKamuningToShawBoulevard2)
        {

            fromGMAKamuningToShawBoulevard2.ToString();
            lbl_FromLocation.Text = fromGMAKamuningToShawBoulevard2.ToString();

        }
        //
        public void fromGMAKamuningToBoni(string fromGMAKamuningToBoni)
        {

            fromGMAKamuningToBoni.ToString();
            lbl_Location.Text = fromGMAKamuningToBoni.ToString();


        }
        public void fromGMAKamuningToBoni2(string fromGMAKamuningToBoni2)
        {

            fromGMAKamuningToBoni2.ToString();
            lbl_FromLocation.Text = fromGMAKamuningToBoni2.ToString();

        }
        //
        public void fromGMAKamuningToGuadalupe(string fromGMAKamuningToGuadalupe)
        {

            fromGMAKamuningToGuadalupe.ToString();
            lbl_Location.Text = fromGMAKamuningToGuadalupe.ToString();


        }
        public void fromGMAKamuningToGuadalupe2(string fromGMAKamuningToGuadalupe2)
        {

            fromGMAKamuningToGuadalupe2.ToString();
            lbl_FromLocation.Text = fromGMAKamuningToGuadalupe2.ToString();

        }
        //
        public void fromGMAKamuningToBuendia(string fromGMAKamuningToBuendia)
        {

            fromGMAKamuningToBuendia.ToString();
            lbl_Location.Text = fromGMAKamuningToBuendia.ToString();


        }
        public void fromGMAKamuningToBuendia2(string fromGMAKamuningToBuendia2)
        {

            fromGMAKamuningToBuendia2.ToString();
            lbl_FromLocation.Text = fromGMAKamuningToBuendia2.ToString();

        }
        //
        public void fromGMAKamuningToAyala(string fromGMAKamuningToAyala)
        {

            fromGMAKamuningToAyala.ToString();
            lbl_Location.Text = fromGMAKamuningToAyala.ToString();


        }
        public void fromGMAKamuningToAyala2(string fromGMAKamuningToAyala2)
        {

            fromGMAKamuningToAyala2.ToString();
            lbl_FromLocation.Text = fromGMAKamuningToAyala2.ToString();

        }
        //
        public void fromGMAKamuningToMagallanes(string fromGMAKamuningToMagallanes)
        {

            fromGMAKamuningToMagallanes.ToString();
            lbl_Location.Text = fromGMAKamuningToMagallanes.ToString();


        }
        public void fromGMAKamuningToMagallanes2(string fromGMAKamuningToMagallanes2)
        {

            fromGMAKamuningToMagallanes2.ToString();
            lbl_FromLocation.Text = fromGMAKamuningToMagallanes2.ToString();

        }
        //
        //
        public void fromGMAKamuningToTaftAve(string fromGMAKamuningToTaftAve)
        {

            fromGMAKamuningToTaftAve.ToString();
            lbl_Location.Text = fromGMAKamuningToTaftAve.ToString();


        }
        public void fromGMAKamuningToTaftAve2(string fromGMAKamuningToTaftAve2)
        {

            fromGMAKamuningToTaftAve2.ToString();
            lbl_FromLocation.Text = fromGMAKamuningToTaftAve2.ToString();

        }
        //
        //Araneta Cubaooooo
        public void fromAranetaCubaoToSantolan(string fromAranetaCubaoToSantolan)
        {

            fromAranetaCubaoToSantolan.ToString();
            lbl_Location.Text = fromAranetaCubaoToSantolan.ToString();


        }
        public void fromAranetaCubaoToSantolan2(string fromAranetaCubaoToSantolan2)
        {

            fromAranetaCubaoToSantolan2.ToString();
            lbl_FromLocation.Text = fromAranetaCubaoToSantolan2.ToString();

        }
        //
        public void fromAranetaCubaoToOrtigas(string fromAranetaCubaoToOrtigas)
        {

            fromAranetaCubaoToOrtigas.ToString();
            lbl_Location.Text = fromAranetaCubaoToOrtigas.ToString();


        }
        public void fromAranetaCubaoToOrtigas2(string fromAranetaCubaoToOrtigas2)
        {

            fromAranetaCubaoToOrtigas2.ToString();
            lbl_FromLocation.Text = fromAranetaCubaoToOrtigas2.ToString();

        }
        //
        public void fromAranetaCubaoToShawBoulevard(string fromAranetaCubaoToShawBoulevard)
        {

            fromAranetaCubaoToShawBoulevard.ToString();
            lbl_Location.Text = fromAranetaCubaoToShawBoulevard.ToString();


        }
        public void fromAranetaCubaoToShawBoulevard2(string fromAranetaCubaoToShawBoulevard2)
        {

            fromAranetaCubaoToShawBoulevard2.ToString();
            lbl_FromLocation.Text = fromAranetaCubaoToShawBoulevard2.ToString();

        }
        //
        public void fromAranetaCubaoToBoni(string fromAranetaCubaoToBoni)
        {

            fromAranetaCubaoToBoni.ToString();
            lbl_Location.Text = fromAranetaCubaoToBoni.ToString();


        }
        public void fromAranetaCubaoToBoni2(string fromAranetaCubaoToBoni2)
        {

            fromAranetaCubaoToBoni2.ToString();
            lbl_FromLocation.Text = fromAranetaCubaoToBoni2.ToString();

        }
        //
        public void fromAranetaCubaoToGuadalupe(string fromAranetaCubaoToGuadalupe)
        {

            fromAranetaCubaoToGuadalupe.ToString();
            lbl_Location.Text = fromAranetaCubaoToGuadalupe.ToString();


        }
        public void fromAranetaCubaoToGuadalupe2(string fromAranetaCubaoToGuadalupe2)
        {

            fromAranetaCubaoToGuadalupe2.ToString();
            lbl_FromLocation.Text = fromAranetaCubaoToGuadalupe2.ToString();

        }
        //
        public void fromAranetaCubaoToBuendia(string fromAranetaCubaoToBuendia)
        {

            fromAranetaCubaoToBuendia.ToString();
            lbl_Location.Text = fromAranetaCubaoToBuendia.ToString();


        }
        public void fromAranetaCubaoToBuendia2(string fromAranetaCubaoToBuendia2)
        {

            fromAranetaCubaoToBuendia2.ToString();
            lbl_FromLocation.Text = fromAranetaCubaoToBuendia2.ToString();

        }
        //
        public void fromAranetaCubaoToAyala(string fromAranetaCubaoToAyala)
        {

            fromAranetaCubaoToAyala.ToString();
            lbl_Location.Text = fromAranetaCubaoToAyala.ToString();


        }
        public void fromAranetaCubaoToAyala2(string fromAranetaCubaoToAyala2)
        {

            fromAranetaCubaoToAyala2.ToString();
            lbl_FromLocation.Text = fromAranetaCubaoToAyala2.ToString();

        }
        //
        public void fromAranetaCubaoToMagallanes(string fromAranetaCubaoToMagallanes)
        {

            fromAranetaCubaoToMagallanes.ToString();
            lbl_Location.Text = fromAranetaCubaoToMagallanes.ToString();


        }
        public void fromAranetaCubaoToMagallanes2(string fromAranetaCubaoToMagallanes2)
        {

            fromAranetaCubaoToMagallanes2.ToString();
            lbl_FromLocation.Text = fromAranetaCubaoToMagallanes2.ToString();

        }
        //
        public void fromAranetaCubaoToTaftAve(string fromAranetaCubaoToTaftAve)
        {

            fromAranetaCubaoToTaftAve.ToString();
            lbl_Location.Text = fromAranetaCubaoToTaftAve.ToString();


        }
        public void fromAranetaCubaoToTaftAve2(string fromAranetaCubaoToTaftAve2)
        {

            fromAranetaCubaoToTaftAve2.ToString();
            lbl_FromLocation.Text = fromAranetaCubaoToTaftAve2.ToString();

        }
        //
        //Santolannnnnnnnn
        public void fromSantolanToOrtigas(string fromSantolanToOrtigas)
        {

            fromSantolanToOrtigas.ToString();
            lbl_Location.Text = fromSantolanToOrtigas.ToString();


        }
        public void fromSantolanToOrtigas2(string fromSantolanToOrtigas2)
        {

            fromSantolanToOrtigas2.ToString();
            lbl_FromLocation.Text = fromSantolanToOrtigas2.ToString();

        }
        //
        public void fromSantolanToShawBoulevard(string fromSantolanToShawBoulevard)
        {

            fromSantolanToShawBoulevard.ToString();
            lbl_Location.Text = fromSantolanToShawBoulevard.ToString();


        }
        public void fromSantolanToShawBoulevard2(string fromSantolanToShawBoulevard2)
        {

            fromSantolanToShawBoulevard2.ToString();
            lbl_FromLocation.Text = fromSantolanToShawBoulevard2.ToString();

        }
        //
        public void fromSantolanToBoni(string fromSantolanToBoni)
        {

            fromSantolanToBoni.ToString();
            lbl_Location.Text = fromSantolanToBoni.ToString();


        }
        public void fromSantolanToBoni2(string fromSantolanToBoni2)
        {

            fromSantolanToBoni2.ToString();
            lbl_FromLocation.Text = fromSantolanToBoni2.ToString();

        }
        //
        public void fromSantolanToGuadalupe(string fromSantolanToGuadalupe)
        {

            fromSantolanToGuadalupe.ToString();
            lbl_Location.Text = fromSantolanToGuadalupe.ToString();


        }
        public void fromSantolanToGuadalupe2(string fromSantolanToGuadalupe2)
        {

            fromSantolanToGuadalupe2.ToString();
            lbl_FromLocation.Text = fromSantolanToGuadalupe2.ToString();

        }
        //
        public void fromSantolanToBuendia(string fromSantolanToBuendia)
        {

            fromSantolanToBuendia.ToString();
            lbl_Location.Text = fromSantolanToBuendia.ToString();


        }
        public void fromSantolanToBuendia2(string fromSantolanToBuendia2)
        {

            fromSantolanToBuendia2.ToString();
            lbl_FromLocation.Text = fromSantolanToBuendia2.ToString();

        }
        //
        public void fromSantolanToAyala(string fromSantolanToAyala)
        {

            fromSantolanToAyala.ToString();
            lbl_Location.Text = fromSantolanToAyala.ToString();


        }
        public void fromSantolanToAyala2(string fromSantolanToAyala2)
        {

            fromSantolanToAyala2.ToString();
            lbl_FromLocation.Text = fromSantolanToAyala2.ToString();

        }
        //
        public void fromSantolanToMagallanes(string fromSantolanToMagallanes)
        {

            fromSantolanToMagallanes.ToString();
            lbl_Location.Text = fromSantolanToMagallanes.ToString();


        }
        public void fromSantolanToMagallanes2(string fromSantolanToMagallanes2)
        {

            fromSantolanToMagallanes2.ToString();
            lbl_FromLocation.Text = fromSantolanToMagallanes2.ToString();

        }
        //
        public void fromSantolanToTaftAve(string fromSantolanToTaftAve)
        {

            fromSantolanToTaftAve.ToString();
            lbl_Location.Text = fromSantolanToTaftAve.ToString();


        }
        public void fromSantolanToTaftAve2(string fromSantolanToTaftAve2)
        {

            fromSantolanToTaftAve2.ToString();
            lbl_FromLocation.Text = fromSantolanToTaftAve2.ToString();

        }
        //
        //Ortigasssssssss
        public void fromOrtigasToShawBoulevard(string fromOrtigasToShawBoulevard)
        {

            fromOrtigasToShawBoulevard.ToString();
            lbl_Location.Text = fromOrtigasToShawBoulevard.ToString();


        }
        public void fromOrtigasToShawBoulevard2(string fromOrtigasToShawBoulevard2)
        {

            fromOrtigasToShawBoulevard2.ToString();
            lbl_FromLocation.Text = fromOrtigasToShawBoulevard2.ToString();

        }
        //
        public void fromOrtigasToBoni(string fromOrtigasToBoni)
        {

            fromOrtigasToBoni.ToString();
            lbl_Location.Text = fromOrtigasToBoni.ToString();


        }
        public void fromOrtigasToBoni2(string fromOrtigasToBoni2)
        {

            fromOrtigasToBoni2.ToString();
            lbl_FromLocation.Text = fromOrtigasToBoni2.ToString();

        }
        //
        public void fromOrtigasToGuadalupe(string fromOrtigasToGuadalupe)
        {

            fromOrtigasToGuadalupe.ToString();
            lbl_Location.Text = fromOrtigasToGuadalupe.ToString();


        }
        public void fromOrtigasToGuadalupe2(string fromOrtigasToGuadalupe2)
        {

            fromOrtigasToGuadalupe2.ToString();
            lbl_FromLocation.Text = fromOrtigasToGuadalupe2.ToString();

        }
        //

        public void fromOrtigasToBuendia(string fromOrtigasToBuendia)
        {

            fromOrtigasToBuendia.ToString();
            lbl_Location.Text = fromOrtigasToBuendia.ToString();


        }
        public void fromOrtigasToBuendia2(string fromOrtigasToBuendia2)
        {

            fromOrtigasToBuendia2.ToString();
            lbl_FromLocation.Text = fromOrtigasToBuendia2.ToString();

        }
        //
        public void fromOrtigasToAyala(string fromOrtigasToAyala)
        {

            fromOrtigasToAyala.ToString();
            lbl_Location.Text = fromOrtigasToAyala.ToString();


        }
        public void fromOrtigasToAyala2(string fromOrtigasToAyala2)
        {

            fromOrtigasToAyala2.ToString();
            lbl_FromLocation.Text = fromOrtigasToAyala2.ToString();

        }
        //
        public void fromOrtigasToMagallanes(string fromOrtigasToMagallanes)
        {

            fromOrtigasToMagallanes.ToString();
            lbl_Location.Text = fromOrtigasToMagallanes.ToString();


        }
        public void fromOrtigasToMagallanes2(string fromOrtigasToMagallanes2)
        {

            fromOrtigasToMagallanes2.ToString();
            lbl_FromLocation.Text = fromOrtigasToMagallanes2.ToString();

        }
        //
        public void fromOrtigasToTaftAve(string fromOrtigasToTaftAve)
        {

            fromOrtigasToTaftAve.ToString();
            lbl_Location.Text = fromOrtigasToTaftAve.ToString();


        }
        public void fromOrtigasToTaftAve2(string fromOrtigasToTaftAve2)
        {

            fromOrtigasToTaftAve2.ToString();
            lbl_FromLocation.Text = fromOrtigasToTaftAve2.ToString();

        }
        //
        //Shaw Boulevarddddddddddd
        public void fromShawBoulevardToBoni(string fromShawBoulevardToBoni)
        {

            fromShawBoulevardToBoni.ToString();
            lbl_Location.Text = fromShawBoulevardToBoni.ToString();


        }
        public void fromShawBoulevardToBoni2(string fromShawBoulevardToBoni2)
        {

            fromShawBoulevardToBoni2.ToString();
            lbl_FromLocation.Text = fromShawBoulevardToBoni2.ToString();

        }
        //
        public void fromShawBoulevardToGuadalupe(string fromShawBoulevardToGuadalupe)
        {

            fromShawBoulevardToGuadalupe.ToString();
            lbl_Location.Text = fromShawBoulevardToGuadalupe.ToString();


        }
        public void fromShawBoulevardToGuadalupe2(string fromShawBoulevardToGuadalupe2)
        {

            fromShawBoulevardToGuadalupe2.ToString();
            lbl_FromLocation.Text = fromShawBoulevardToGuadalupe2.ToString();

        }
        //
        public void fromShawBoulevardToBuendia(string fromShawBoulevardToBuendia)
        {

            fromShawBoulevardToBuendia.ToString();
            lbl_Location.Text = fromShawBoulevardToBuendia.ToString();


        }
        public void fromShawBoulevardToBuendia2(string fromShawBoulevardToBuendia2)
        {

            fromShawBoulevardToBuendia2.ToString();
            lbl_FromLocation.Text = fromShawBoulevardToBuendia2.ToString();

        }
        //
        public void fromShawBoulevardToAyala(string fromShawBoulevardToAyala)
        {

            fromShawBoulevardToAyala.ToString();
            lbl_Location.Text = fromShawBoulevardToAyala.ToString();


        }
        public void fromShawBoulevardToAyala2(string fromShawBoulevardToAyala2)
        {

            fromShawBoulevardToAyala2.ToString();
            lbl_FromLocation.Text = fromShawBoulevardToAyala2.ToString();

        }
        //
        public void fromShawBoulevardToMagallanes(string fromShawBoulevardToMagallanes)
        {

            fromShawBoulevardToMagallanes.ToString();
            lbl_Location.Text = fromShawBoulevardToMagallanes.ToString();


        }
        public void fromShawBoulevardToMagallanes2(string fromShawBoulevardToMagallanes2)
        {

            fromShawBoulevardToMagallanes2.ToString();
            lbl_FromLocation.Text = fromShawBoulevardToMagallanes2.ToString();

        }
        //
        public void fromShawBoulevardToTaftAve(string fromShawBoulevardToTaftAve)
        {

            fromShawBoulevardToTaftAve.ToString();
            lbl_Location.Text = fromShawBoulevardToTaftAve.ToString();


        }
        public void fromShawBoulevardToTaftAve2(string fromShawBoulevardToTaftAve2)
        {

            fromShawBoulevardToTaftAve2.ToString();
            lbl_FromLocation.Text = fromShawBoulevardToTaftAve2.ToString();

        }
        //Boniiiiiiiiiii

        //
        public void fromBoniToGuadalupe(string fromBoniToGuadalupe)
        {

            fromBoniToGuadalupe.ToString();
            lbl_Location.Text = fromBoniToGuadalupe.ToString();


        }
        public void fromBoniToGuadalupe2(string fromBoniToGuadalupe2)
        {

            fromBoniToGuadalupe2.ToString();
            lbl_FromLocation.Text = fromBoniToGuadalupe2.ToString();

        }
        //
        public void fromBoniToBuendia(string fromBoniToBuendia)
        {

            fromBoniToBuendia.ToString();
            lbl_Location.Text = fromBoniToBuendia.ToString();


        }
        public void fromBoniToBuendia2(string fromBoniToBuendia2)
        {

            fromBoniToBuendia2.ToString();
            lbl_FromLocation.Text = fromBoniToBuendia2.ToString();

        }
        //
        public void fromBoniToAyala(string fromBoniToAyala)
        {

            fromBoniToAyala.ToString();
            lbl_Location.Text = fromBoniToAyala.ToString();


        }
        public void fromBoniToAyala2(string fromBoniToAyala2)
        {

            fromBoniToAyala2.ToString();
            lbl_FromLocation.Text = fromBoniToAyala2.ToString();

        }
        //
        public void fromBoniToMagallanes(string fromBoniToMagallanes)
        {

            fromBoniToMagallanes.ToString();
            lbl_Location.Text = fromBoniToMagallanes.ToString();


        }
        public void fromBoniToMagallanes2(string fromBoniToMagallanes2)
        {

            fromBoniToMagallanes2.ToString();
            lbl_FromLocation.Text = fromBoniToMagallanes2.ToString();

        }
        //
        public void fromBoniToTaftAve(string fromBoniToTaftAve)
        {

            fromBoniToTaftAve.ToString();
            lbl_Location.Text = fromBoniToTaftAve.ToString();


        }
        public void fromBoniToTaftAve2(string fromBoniToTaftAve2)
        {

            fromBoniToTaftAve2.ToString();
            lbl_FromLocation.Text = fromBoniToTaftAve2.ToString();

        }
        //
        //Guadalupeeeeeeee
        public void fromGuadalupeToBuendia(string fromGuadalupeToBuendia)
        {

            fromGuadalupeToBuendia.ToString();
            lbl_Location.Text = fromGuadalupeToBuendia.ToString();


        }
        public void fromGuadalupeToBuendia2(string fromGuadalupeToBuendia2)
        {

            fromGuadalupeToBuendia2.ToString();
            lbl_FromLocation.Text = fromGuadalupeToBuendia2.ToString();

        }
        //
        public void fromGuadalupeToAyala(string fromGuadalupeToAyala)
        {

            fromGuadalupeToAyala.ToString();
            lbl_Location.Text = fromGuadalupeToAyala.ToString();


        }
        public void fromGuadalupeToAyala2(string fromGuadalupeToAyala2)
        {

            fromGuadalupeToAyala2.ToString();
            lbl_FromLocation.Text = fromGuadalupeToAyala2.ToString();

        }
        //
        public void fromGuadalupeToMagallanes(string fromGuadalupeToMagallanes)
        {

            fromGuadalupeToMagallanes.ToString();
            lbl_Location.Text = fromGuadalupeToMagallanes.ToString();


        }
        public void fromGuadalupeToMagallanes2(string fromGuadalupeToMagallanes2)
        {

            fromGuadalupeToMagallanes2.ToString();
            lbl_FromLocation.Text = fromGuadalupeToMagallanes2.ToString();

        }
        //
        public void fromGuadalupeToTaftAve(string fromGuadalupeToTaftAve)
        {

            fromGuadalupeToTaftAve.ToString();
            lbl_Location.Text = fromGuadalupeToTaftAve.ToString();


        }
        public void fromGuadalupeToTaftAve2(string fromGuadalupeToTaftAve2)
        {

            fromGuadalupeToTaftAve2.ToString();
            lbl_FromLocation.Text = fromGuadalupeToTaftAve2.ToString();

        }
        //
        //Buendiaaaaa
        public void fromBuendiaToAyala(string fromBuendiaToAyala)
        {

            fromBuendiaToAyala.ToString();
            lbl_Location.Text = fromBuendiaToAyala.ToString();


        }
        public void fromBuendiaToAyala2(string fromBuendiaToAyala2)
        {

            fromBuendiaToAyala2.ToString();
            lbl_FromLocation.Text = fromBuendiaToAyala2.ToString();

        }
        //
        public void fromBuendiaToMagallanes(string fromBuendiaToMagallanes)
        {

            fromBuendiaToMagallanes.ToString();
            lbl_Location.Text = fromBuendiaToMagallanes.ToString();


        }
        public void fromBuendiaToMagallanes2(string fromBuendiaToMagallanes2)
        {

            fromBuendiaToMagallanes2.ToString();
            lbl_FromLocation.Text = fromBuendiaToMagallanes2.ToString();

        }
        //
        public void fromBuendiaToTaftAve(string fromBuendiaToTaftAve)
        {

            fromBuendiaToTaftAve.ToString();
            lbl_Location.Text = fromBuendiaToTaftAve.ToString();


        }
        public void fromBuendiaToTaftAve2(string fromBuendiaToTaftAve2)
        {

            fromBuendiaToTaftAve2.ToString();
            lbl_FromLocation.Text = fromBuendiaToTaftAve2.ToString();

        }
        //
        // Ayalaaaaa
        public void fromAyalaToMagallanes(string fromAyalaToMagallanes)
        {

            fromAyalaToMagallanes.ToString();
            lbl_Location.Text = fromAyalaToMagallanes.ToString();


        }
        public void fromAyalaToMagallanes2(string fromAyalaToMagallanes2)
        {

            fromAyalaToMagallanes2.ToString();
            lbl_FromLocation.Text = fromAyalaToMagallanes2.ToString();
        }

        //
        public void fromAyalaToTaftAve(string fromAyalaToTaftAve)
        {

            fromAyalaToTaftAve.ToString();
            lbl_Location.Text = fromAyalaToTaftAve.ToString();


        }
        public void fromAyalaToTaftAve2(string fromAyalaToTaftAve2)
        {

            fromAyalaToTaftAve2.ToString();
            lbl_FromLocation.Text = fromAyalaToTaftAve2.ToString();
        }

        //
        //Magallanesssss
        public void fromMagallanesToTaftAve(string fromMagallanesToTaftAve)
        {

            fromMagallanesToTaftAve.ToString();
            lbl_Location.Text = fromMagallanesToTaftAve.ToString();


        }
        public void fromMagallanesToTaftAve2(string fromMagallanesToTaftAve2)
        {

            fromMagallanesToTaftAve2.ToString();
            lbl_FromLocation.Text = fromMagallanesToTaftAve2.ToString();
        }

        //MRT 7

        public void fromNorthAveToQcCircle(string fromNorthAveToQcCircle)
        {

            fromNorthAveToQcCircle.ToString();
            lbl_FromLocation.Text = fromNorthAveToQcCircle.ToString();
        }

        public void fromNorthAveToQcCircle2(string fromNorthAveToQcCircle2)
        {

            fromNorthAveToQcCircle2.ToString();
            lbl_FromLocation.Text = fromNorthAveToQcCircle2.ToString();
        }

        //SMRT 7

        public void fromSJDMToTala(string fromSJDMToTala)
        {

            fromSJDMToTala.ToString();
            lbl_FromLocation.Text = fromSJDMToTala.ToString();
        }

        public void fromSJDMToTala2(string fromSJDMToTala2)
        {

            fromSJDMToTala2.ToString();
            lbl_FromLocation.Text = fromSJDMToTala2.ToString();
        }

        public void TotalPrice(string TotalPrice) {

            TotalPrice.ToString();
            lblPrice.Text = TotalPrice.ToString();
            lblPurchase.Text = lblPrice.Text.ToString() ;
            txtTot.Text = TotalPrice.ToString();
            
          
        }


        private void lbl_FromLocation_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Plus_Click(object sender, EventArgs e)
        {
            Double ticket = Convert.ToDouble(lblTicketTot.Text);

            Double sum = ticket + 1;

            lblTicketTot.Text = sum.ToString();



            Double price = Convert.ToDouble(lblPrice.Text);

            Double PurchaseValue = sum * price;
            lblPurchase.Text = PurchaseValue.ToString() + ".00";
            txtTot.Text = PurchaseValue.ToString() + ".00";


        }

        private void Minus_Click(object sender, EventArgs e)
        {
            Double ticket = Convert.ToDouble(lblTicketTot.Text);

            if (lblTicketTot.Text == "1")
            {
                MessageBox.Show("Your Total Ticket is 1 ");
            }
            else {
                Double diff = ticket - 1;
                lblTicketTot.Text = diff.ToString();


                Double price = Convert.ToDouble(lblPrice.Text);

                Double PurchaseValue = diff * price;
                lblPurchase.Text = PurchaseValue.ToString() + ".00";
                txtTot.Text = PurchaseValue.ToString() + ".00";
            }
         
        }

        private void button1_Click(object sender, EventArgs e)
        {
          

           Double PurchaseValue = Convert.ToDouble(lblPurchase.Text);
           Double AmountInserted = Convert.ToDouble(txtAmountInserted.Text);

           if (PurchaseValue <= AmountInserted)
           {

               Double changed = AmountInserted - PurchaseValue;

               lblChange.Text = changed.ToString() + ".00";

               txtResult.Clear();
               txtResult.Text += "\n\t\t\tITZ'ey MRT\n";
               txtResult.Text += "\t\t\t   RECEIPT\n\n";
               txtResult.Text += "\t Receipt No:             \t\t" + lblRand.Text + "\n";
               txtResult.Text += "\t Date and Time \t\t" + lblTimeDate.Text + "\n";
               txtResult.Text += "\t Station Name: \t\t" + lbl_Location.Text + "\n";
               txtResult.Text += "\t ----------------------------------------------\n\n";
               txtResult.Text += "\t TRANSACTION RECEIPT\n\n";
               txtResult.Text += "\t -----------------------------------------------\n\n\n\n";
               txtResult.Text += "\t AMOUNT INSERTED: \t\t"+ txtAmountInserted.Text + ".00\n";
               txtResult.Text += "\t TOTAL AMOUNT:  \t\t" + lblPurchase.Text + "\n";
               txtResult.Text += "\t CHANGE: \t\t\t"       + lblChange.Text + "\n\n";
               txtResult.Text += "\t ------------------------------------------------\n";
               txtResult.Text += "\t Have a nice day!\n\n";
               txtResult.Text += "\t ------------------------------------------------\n";
               txtResult.Text += "\t CUSTOMER'S COPY\n\n";


               printPreviewDialog1.Document = printDocument1;
               printPreviewDialog1.ShowDialog();
               insertdata();

            }

           else {
               MessageBox.Show("Insufficient Funds");
           
           }




        }

        private void lblPurchaseValue_Click(object sender, EventArgs e)
        {

        }


        private void timer_Tick(object sender, EventArgs e)
        {
            lblTimeDate.Text = DateTime.Now.ToString("MMM dd yyyy,hh:mm");
           
        }

        private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            
        }

   

        private void Receipt_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void btnTravel_Click(object sender, EventArgs e)
        {

            this.Hide();

            Form1 f1 = new Form1();

            f1.ShowDialog();



        }

        private void printPreviewDialog_Load(object sender, EventArgs e)
        {

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(txtResult.Text, new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(10, 10));
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
                     lblTimeDate.Text = "";
                   lbl_Location.Text= "";
                       txtAmountInserted.Text= "";
                           lblPurchase.Text= "";
                           lblChange.Text = "";
                           txtResult.Text = "";
        }


        public void insertdata()
        {

            try
            {
                con.Open();
                OleDbCommand cmd = new OleDbCommand();
                cmd.Connection = con;
                cmd.CommandText = "insert into MRT(Station,Destination,Price,Tickets,AmountPaid,Total,Change,ReceiptNo,DateAndTime)values('" + lbl_FromLocation.Text + "','" + lbl_Location.Text + "','" + lblPrice.Text + "','" + lblTicketTot.Text + "','" + txtAmountInserted.Text+ "','" + lblPurchase.Text + "','" + lblChange.Text+ "','" + lblRand.Text+ "','" + lblTimeDate.Text+ "')";

                cmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);
            }
        }

    }
}

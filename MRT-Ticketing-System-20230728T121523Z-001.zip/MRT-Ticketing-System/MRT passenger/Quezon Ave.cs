﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Quezon_Ave : Form
    {
        public Quezon_Ave()
        {
            InitializeComponent();
        }

        private void Quezon_Ave_Load(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb2_GMA.Checked==true && lblPrice.Text !="0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice; 

                QuezonAve = lbl2GMAKAMUNING.Text;
                fromQuezonAve = lbl_QuezonAve.Text;
                TotalPrice = lblPrice.Text;
                TotalPrice = lblPrice.Text;
                this.Hide();
  
                lblTot GMAfrm = new lblTot();
                GMAfrm.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMAfrm.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMAfrm.TotalPrice(TotalPrice.ToString());
                GMAfrm.ShowDialog();
            }
            else if (rb2_AranetaCubao.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl2AranetaCubao.Text;
                fromQuezonAve = lbl_QuezonAve.Text;
                TotalPrice = lblPrice.Text;
                this.Hide();

                lblTot GMAfrm = new lblTot();
                GMAfrm.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMAfrm.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMAfrm.TotalPrice(TotalPrice.ToString());
                GMAfrm.ShowDialog();
            }
            else if (rb2_Santolan.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl2Santolan.Text;
                fromQuezonAve = lbl_QuezonAve.Text;
                TotalPrice = lblPrice.Text;
                this.Hide();

                lblTot GMAfrm = new lblTot();
                GMAfrm.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMAfrm.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMAfrm.TotalPrice(TotalPrice.ToString());
                GMAfrm.ShowDialog();
            }
            else if (rb2_Ortigas.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl2Ortigas.Text;
                fromQuezonAve = lbl_QuezonAve.Text;
                TotalPrice = lblPrice.Text;
                this.Hide();

                lblTot GMAfrm = new lblTot();
                GMAfrm.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMAfrm.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMAfrm.TotalPrice(TotalPrice.ToString());
                GMAfrm.ShowDialog();
            }
            else if (rb2_ShawBoulevard.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl2ShawBoulevard.Text;
                fromQuezonAve = lbl_QuezonAve.Text;
                TotalPrice = lblPrice.Text;
                this.Hide();

                lblTot GMAfrm = new lblTot();
                GMAfrm.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMAfrm.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMAfrm.TotalPrice(TotalPrice.ToString());
                GMAfrm.ShowDialog();
            }
            else if (rb2_BoniAve.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl2BoniAve.Text;
                fromQuezonAve = lbl_QuezonAve.Text;
                TotalPrice = lblPrice.Text;
                this.Hide();

                lblTot GMAfrm = new lblTot();
                GMAfrm.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMAfrm.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMAfrm.TotalPrice(TotalPrice.ToString());
                GMAfrm.ShowDialog();
            }
            else if (rb2_Guadalupe.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl2Guadalupe.Text;
                fromQuezonAve = lbl_QuezonAve.Text;
                TotalPrice = lblPrice.Text;
                this.Hide();

                lblTot GMAfrm = new lblTot();
                GMAfrm.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMAfrm.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMAfrm.TotalPrice(TotalPrice.ToString());
                GMAfrm.ShowDialog();
            }
            else if (rb2_Buendia.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl2Buendia.Text;
                fromQuezonAve = lbl_QuezonAve.Text;
                TotalPrice = lblPrice.Text;
                this.Hide();

                lblTot GMAfrm = new lblTot();
                GMAfrm.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMAfrm.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMAfrm.TotalPrice(TotalPrice.ToString());
                GMAfrm.ShowDialog();
            }
            else if (rb2_AyalaAve.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl2AyalaAve.Text;
                fromQuezonAve = lbl_QuezonAve.Text;
                TotalPrice = lblPrice.Text;
                this.Hide();

                lblTot GMAfrm = new lblTot();
                GMAfrm.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMAfrm.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMAfrm.TotalPrice(TotalPrice.ToString());
                GMAfrm.ShowDialog();
            }
            else if (rb2_Magallanes.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl2Magallanes.Text;
                fromQuezonAve = lbl_QuezonAve.Text;
                TotalPrice = lblPrice.Text;
                this.Hide();

                lblTot GMAfrm = new lblTot();
                GMAfrm.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMAfrm.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMAfrm.TotalPrice(TotalPrice.ToString());
                GMAfrm.ShowDialog();
            }
            else if (rb2_TaftAve.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve = lbl2TaftAve.Text;
                fromQuezonAve = lbl_QuezonAve.Text;
                TotalPrice = lblPrice.Text;
                this.Hide();

                lblTot GMAfrm = new lblTot();
                GMAfrm.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMAfrm.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMAfrm.TotalPrice(TotalPrice.ToString());
                GMAfrm.ShowDialog();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void lblGMAKAMUNING_Click(object sender, EventArgs e)
        {

        }

        private void lbl_NorthAve_Click(object sender, EventArgs e)
        {

        }

        private void rb_GMA_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void rb2_GMA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_GMA.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb2_AranetaCubao_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_AranetaCubao.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb2_Santolan_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_Santolan.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb2_Ortigas_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_Ortigas.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb2_ShawBoulevard_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_ShawBoulevard.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb2_BoniAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_BoniAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb2_Guadalupe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_Guadalupe.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb2_Buendia_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_Buendia.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb2_AyalaAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_AyalaAve.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb2_Magallanes_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_Magallanes.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb2_TaftAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb2_TaftAve.Checked == true)
            {
                lblPrice.Text = "28.00";
            }
        }
    }
}

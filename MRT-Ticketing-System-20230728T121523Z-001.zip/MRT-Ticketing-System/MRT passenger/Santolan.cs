﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Santolan : Form
    {
        public Santolan()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
           if (rb5_Ortigas.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl5Ortigas.Text;
               fromQuezonAve = lbl_Santolan.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb5_ShawBoulevard.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl5ShawBoulevard.Text;
               fromQuezonAve = lbl_Santolan.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb5_BoniAve.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl5BoniAve.Text;
               fromQuezonAve = lbl_Santolan.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb5_Guadalupe.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl5Guadalupe.Text;
               fromQuezonAve = lbl_Santolan.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb5_Buendia.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl5Buendia.Text;
               fromQuezonAve = lbl_Santolan.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb5_AyalaAve.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl5AyalaAve.Text;
               fromQuezonAve = lbl_Santolan.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb5_Magallanes.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl5Magallanes.Text;
               fromQuezonAve = lbl_Santolan.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb5_TaftAve.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl5TaftAve.Text;
               fromQuezonAve = lbl_Santolan.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
        }

        private void Santolan_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void rb5_Ortigas_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_Ortigas.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb5_ShawBoulevard_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_ShawBoulevard.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb5_BoniAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_BoniAve.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb5_Guadalupe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_Guadalupe.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb5_Buendia_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_Buendia.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb5_AyalaAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_AyalaAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb5_Magallanes_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_Magallanes.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb5_TaftAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_TaftAve.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }
    }
}

﻿namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    partial class Ortigas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label6;
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.lbl_Ortigas = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rb6_Buendia = new System.Windows.Forms.RadioButton();
            this.lbl6TaftAve = new System.Windows.Forms.Label();
            this.lbl6ShawBoulevard = new System.Windows.Forms.Label();
            this.rb6_TaftAve = new System.Windows.Forms.RadioButton();
            this.rb6_ShawBoulevard = new System.Windows.Forms.RadioButton();
            this.lbl6Magallanes = new System.Windows.Forms.Label();
            this.lbl6AyalaAve = new System.Windows.Forms.Label();
            this.rb6_Magallanes = new System.Windows.Forms.RadioButton();
            this.rb6_AyalaAve = new System.Windows.Forms.RadioButton();
            this.lbl6Buendia = new System.Windows.Forms.Label();
            this.lbl6Guadalupe = new System.Windows.Forms.Label();
            this.lbl6BoniAve = new System.Windows.Forms.Label();
            this.rb6_Guadalupe = new System.Windows.Forms.RadioButton();
            this.rb6_BoniAve = new System.Windows.Forms.RadioButton();
            this.lblPrice = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label2.Location = new System.Drawing.Point(556, 118);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(272, 24);
            label2.TabIndex = 1;
            label2.Text = "SELECT YOUR DESTINATION";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label3.Location = new System.Drawing.Point(672, 298);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(101, 24);
            label3.TabIndex = 13;
            label3.Text = "Ticket fare:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label6.Location = new System.Drawing.Point(174, 260);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(178, 37);
            label6.TabIndex = 57;
            label6.Text = "STATIONS";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(16, 72);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1326, 155);
            this.panel1.TabIndex = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ITZeyyyyy_TRAIN_TICKET_SYSTEM.Properties.Resources.metro_station;
            this.pictureBox2.Location = new System.Drawing.Point(143, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(193, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(388, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(631, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "ORTIGAS STATION";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(832, 392);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 42);
            this.label4.TabIndex = 16;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(1175, 661);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(140, 33);
            this.button14.TabIndex = 17;
            this.button14.Text = "PROCEED";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // lbl_Ortigas
            // 
            this.lbl_Ortigas.AutoSize = true;
            this.lbl_Ortigas.ForeColor = System.Drawing.Color.White;
            this.lbl_Ortigas.Location = new System.Drawing.Point(274, 58);
            this.lbl_Ortigas.Name = "lbl_Ortigas";
            this.lbl_Ortigas.Size = new System.Drawing.Size(55, 13);
            this.lbl_Ortigas.TabIndex = 62;
            this.lbl_Ortigas.Text = "ORTIGAS";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel5.Location = new System.Drawing.Point(44, 290);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 400);
            this.panel5.TabIndex = 61;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel9.Location = new System.Drawing.Point(456, 290);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1, 400);
            this.panel9.TabIndex = 60;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel4.Location = new System.Drawing.Point(44, 290);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(136, 1);
            this.panel4.TabIndex = 59;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel8.Location = new System.Drawing.Point(321, 290);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(136, 1);
            this.panel8.TabIndex = 58;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rb6_Buendia);
            this.panel2.Controls.Add(this.lbl6TaftAve);
            this.panel2.Controls.Add(this.lbl_Ortigas);
            this.panel2.Controls.Add(this.lbl6ShawBoulevard);
            this.panel2.Controls.Add(this.rb6_TaftAve);
            this.panel2.Controls.Add(this.rb6_ShawBoulevard);
            this.panel2.Controls.Add(this.lbl6Magallanes);
            this.panel2.Controls.Add(this.lbl6AyalaAve);
            this.panel2.Controls.Add(this.rb6_Magallanes);
            this.panel2.Controls.Add(this.rb6_AyalaAve);
            this.panel2.Controls.Add(this.lbl6Buendia);
            this.panel2.Controls.Add(this.lbl6Guadalupe);
            this.panel2.Controls.Add(this.lbl6BoniAve);
            this.panel2.Controls.Add(this.rb6_Guadalupe);
            this.panel2.Controls.Add(this.rb6_BoniAve);
            this.panel2.Location = new System.Drawing.Point(44, 290);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(413, 429);
            this.panel2.TabIndex = 56;
            // 
            // rb6_Buendia
            // 
            this.rb6_Buendia.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb6_Buendia.AutoSize = true;
            this.rb6_Buendia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb6_Buendia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb6_Buendia.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb6_Buendia.ForeColor = System.Drawing.Color.White;
            this.rb6_Buendia.Location = new System.Drawing.Point(224, 44);
            this.rb6_Buendia.Name = "rb6_Buendia";
            this.rb6_Buendia.Padding = new System.Windows.Forms.Padding(28, 0, 28, 0);
            this.rb6_Buendia.Size = new System.Drawing.Size(159, 37);
            this.rb6_Buendia.TabIndex = 71;
            this.rb6_Buendia.TabStop = true;
            this.rb6_Buendia.Text = "Buendia";
            this.rb6_Buendia.UseVisualStyleBackColor = false;
            this.rb6_Buendia.CheckedChanged += new System.EventHandler(this.rb6_Buendia_CheckedChanged);
            // 
            // lbl6TaftAve
            // 
            this.lbl6TaftAve.AutoSize = true;
            this.lbl6TaftAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl6TaftAve.Location = new System.Drawing.Point(166, 227);
            this.lbl6TaftAve.Name = "lbl6TaftAve";
            this.lbl6TaftAve.Size = new System.Drawing.Size(81, 13);
            this.lbl6TaftAve.TabIndex = 70;
            this.lbl6TaftAve.Text = "TAFT AVENUE";
            // 
            // lbl6ShawBoulevard
            // 
            this.lbl6ShawBoulevard.AutoSize = true;
            this.lbl6ShawBoulevard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl6ShawBoulevard.Location = new System.Drawing.Point(50, 23);
            this.lbl6ShawBoulevard.Name = "lbl6ShawBoulevard";
            this.lbl6ShawBoulevard.Size = new System.Drawing.Size(109, 13);
            this.lbl6ShawBoulevard.TabIndex = 64;
            this.lbl6ShawBoulevard.Text = "SHAW BOULEVARD";
            // 
            // rb6_TaftAve
            // 
            this.rb6_TaftAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb6_TaftAve.AutoSize = true;
            this.rb6_TaftAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb6_TaftAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb6_TaftAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb6_TaftAve.ForeColor = System.Drawing.Color.White;
            this.rb6_TaftAve.Location = new System.Drawing.Point(129, 246);
            this.rb6_TaftAve.Name = "rb6_TaftAve";
            this.rb6_TaftAve.Padding = new System.Windows.Forms.Padding(22, 0, 22, 0);
            this.rb6_TaftAve.Size = new System.Drawing.Size(154, 37);
            this.rb6_TaftAve.TabIndex = 69;
            this.rb6_TaftAve.TabStop = true;
            this.rb6_TaftAve.Text = "Taft Ave.";
            this.rb6_TaftAve.UseVisualStyleBackColor = false;
            this.rb6_TaftAve.CheckedChanged += new System.EventHandler(this.rb6_TaftAve_CheckedChanged);
            // 
            // rb6_ShawBoulevard
            // 
            this.rb6_ShawBoulevard.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb6_ShawBoulevard.AutoSize = true;
            this.rb6_ShawBoulevard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb6_ShawBoulevard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb6_ShawBoulevard.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb6_ShawBoulevard.ForeColor = System.Drawing.Color.White;
            this.rb6_ShawBoulevard.Location = new System.Drawing.Point(30, 44);
            this.rb6_ShawBoulevard.Name = "rb6_ShawBoulevard";
            this.rb6_ShawBoulevard.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.rb6_ShawBoulevard.Size = new System.Drawing.Size(155, 36);
            this.rb6_ShawBoulevard.TabIndex = 63;
            this.rb6_ShawBoulevard.TabStop = true;
            this.rb6_ShawBoulevard.Text = "Shaw Blvd.";
            this.rb6_ShawBoulevard.UseVisualStyleBackColor = false;
            this.rb6_ShawBoulevard.CheckedChanged += new System.EventHandler(this.rb6_ShawBoulevard_CheckedChanged);
            // 
            // lbl6Magallanes
            // 
            this.lbl6Magallanes.AutoSize = true;
            this.lbl6Magallanes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl6Magallanes.Location = new System.Drawing.Point(261, 162);
            this.lbl6Magallanes.Name = "lbl6Magallanes";
            this.lbl6Magallanes.Size = new System.Drawing.Size(79, 13);
            this.lbl6Magallanes.TabIndex = 57;
            this.lbl6Magallanes.Text = "MAGALLANES";
            // 
            // lbl6AyalaAve
            // 
            this.lbl6AyalaAve.AutoSize = true;
            this.lbl6AyalaAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl6AyalaAve.Location = new System.Drawing.Point(253, 92);
            this.lbl6AyalaAve.Name = "lbl6AyalaAve";
            this.lbl6AyalaAve.Size = new System.Drawing.Size(88, 13);
            this.lbl6AyalaAve.TabIndex = 68;
            this.lbl6AyalaAve.Text = "AYALA AVENUE";
            // 
            // rb6_Magallanes
            // 
            this.rb6_Magallanes.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb6_Magallanes.AutoSize = true;
            this.rb6_Magallanes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb6_Magallanes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb6_Magallanes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb6_Magallanes.ForeColor = System.Drawing.Color.White;
            this.rb6_Magallanes.Location = new System.Drawing.Point(224, 181);
            this.rb6_Magallanes.Name = "rb6_Magallanes";
            this.rb6_Magallanes.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.rb6_Magallanes.Size = new System.Drawing.Size(155, 37);
            this.rb6_Magallanes.TabIndex = 52;
            this.rb6_Magallanes.TabStop = true;
            this.rb6_Magallanes.Text = "Magallanes";
            this.rb6_Magallanes.UseVisualStyleBackColor = false;
            this.rb6_Magallanes.CheckedChanged += new System.EventHandler(this.rb6_Magallanes_CheckedChanged);
            // 
            // rb6_AyalaAve
            // 
            this.rb6_AyalaAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb6_AyalaAve.AutoSize = true;
            this.rb6_AyalaAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb6_AyalaAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb6_AyalaAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb6_AyalaAve.ForeColor = System.Drawing.Color.White;
            this.rb6_AyalaAve.Location = new System.Drawing.Point(224, 112);
            this.rb6_AyalaAve.Name = "rb6_AyalaAve";
            this.rb6_AyalaAve.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.rb6_AyalaAve.Size = new System.Drawing.Size(157, 37);
            this.rb6_AyalaAve.TabIndex = 67;
            this.rb6_AyalaAve.TabStop = true;
            this.rb6_AyalaAve.Text = "Ayala Ave.";
            this.rb6_AyalaAve.UseVisualStyleBackColor = false;
            this.rb6_AyalaAve.CheckedChanged += new System.EventHandler(this.rb6_AyalaAve_CheckedChanged);
            // 
            // lbl6Buendia
            // 
            this.lbl6Buendia.AutoSize = true;
            this.lbl6Buendia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl6Buendia.Location = new System.Drawing.Point(274, 25);
            this.lbl6Buendia.Name = "lbl6Buendia";
            this.lbl6Buendia.Size = new System.Drawing.Size(55, 13);
            this.lbl6Buendia.TabIndex = 56;
            this.lbl6Buendia.Text = "BUENDIA";
            // 
            // lbl6Guadalupe
            // 
            this.lbl6Guadalupe.AutoSize = true;
            this.lbl6Guadalupe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl6Guadalupe.Location = new System.Drawing.Point(80, 158);
            this.lbl6Guadalupe.Name = "lbl6Guadalupe";
            this.lbl6Guadalupe.Size = new System.Drawing.Size(73, 13);
            this.lbl6Guadalupe.TabIndex = 58;
            this.lbl6Guadalupe.Text = "GUADALUPE";
            // 
            // lbl6BoniAve
            // 
            this.lbl6BoniAve.AutoSize = true;
            this.lbl6BoniAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lbl6BoniAve.Location = new System.Drawing.Point(55, 89);
            this.lbl6BoniAve.Name = "lbl6BoniAve";
            this.lbl6BoniAve.Size = new System.Drawing.Size(80, 13);
            this.lbl6BoniAve.TabIndex = 66;
            this.lbl6BoniAve.Text = "BONI AVENUE";
            // 
            // rb6_Guadalupe
            // 
            this.rb6_Guadalupe.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb6_Guadalupe.AutoSize = true;
            this.rb6_Guadalupe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb6_Guadalupe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb6_Guadalupe.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb6_Guadalupe.ForeColor = System.Drawing.Color.White;
            this.rb6_Guadalupe.Location = new System.Drawing.Point(30, 181);
            this.rb6_Guadalupe.Name = "rb6_Guadalupe";
            this.rb6_Guadalupe.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.rb6_Guadalupe.Size = new System.Drawing.Size(159, 37);
            this.rb6_Guadalupe.TabIndex = 54;
            this.rb6_Guadalupe.TabStop = true;
            this.rb6_Guadalupe.Text = "Guadalupe";
            this.rb6_Guadalupe.UseVisualStyleBackColor = false;
            this.rb6_Guadalupe.CheckedChanged += new System.EventHandler(this.rb6_Guadalupe_CheckedChanged);
            // 
            // rb6_BoniAve
            // 
            this.rb6_BoniAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb6_BoniAve.AutoSize = true;
            this.rb6_BoniAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb6_BoniAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb6_BoniAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb6_BoniAve.ForeColor = System.Drawing.Color.White;
            this.rb6_BoniAve.Location = new System.Drawing.Point(30, 113);
            this.rb6_BoniAve.Name = "rb6_BoniAve";
            this.rb6_BoniAve.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.rb6_BoniAve.Size = new System.Drawing.Size(156, 37);
            this.rb6_BoniAve.TabIndex = 65;
            this.rb6_BoniAve.TabStop = true;
            this.rb6_BoniAve.Text = "Boni Ave.";
            this.rb6_BoniAve.UseVisualStyleBackColor = false;
            this.rb6_BoniAve.CheckedChanged += new System.EventHandler(this.rb6_BoniAve_CheckedChanged);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(639, 452);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(248, 111);
            this.lblPrice.TabIndex = 72;
            this.lblPrice.Text = "0.00";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(676, 661);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 33);
            this.button1.TabIndex = 73;
            this.button1.Text = "BACK";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Ortigas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1354, 704);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel8);
            this.Controls.Add(label6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button14);
            this.Controls.Add(label3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Ortigas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ortigas";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Ortigas_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label lbl_Ortigas;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl6TaftAve;
        private System.Windows.Forms.Label lbl6ShawBoulevard;
        private System.Windows.Forms.RadioButton rb6_TaftAve;
        private System.Windows.Forms.RadioButton rb6_ShawBoulevard;
        private System.Windows.Forms.Label lbl6Magallanes;
        private System.Windows.Forms.Label lbl6AyalaAve;
        private System.Windows.Forms.RadioButton rb6_Magallanes;
        private System.Windows.Forms.RadioButton rb6_AyalaAve;
        private System.Windows.Forms.Label lbl6Buendia;
        private System.Windows.Forms.Label lbl6Guadalupe;
        private System.Windows.Forms.Label lbl6BoniAve;
        private System.Windows.Forms.RadioButton rb6_Guadalupe;
        private System.Windows.Forms.RadioButton rb6_BoniAve;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.RadioButton rb6_Buendia;
        private System.Windows.Forms.Button button1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class buendia : Form
    {
        public buendia()
        {
            InitializeComponent();
        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
             if (rb10_AyalaAve.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl10AyalaAve.Text;
               fromQuezonAve = lbl_Buendia.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }

             else if (rb10_Magallanes.Checked == true && lblPrice.Text != "0.00")
             {
                 string QuezonAve, fromQuezonAve, TotalPrice;

                 QuezonAve = lbl10Magallanes.Text;
                 fromQuezonAve = lbl_Buendia.Text;
                 TotalPrice = lblPrice.Text;

                 this.Hide();

                 lblTot GMA2 = new lblTot();
                 GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                 GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                 GMA2.TotalPrice(TotalPrice.ToString());
                 GMA2.ShowDialog();
             }

             if (rb10_TaftAve.Checked == true && lblPrice.Text != "0.00")
             {
                 string QuezonAve, fromQuezonAve, TotalPrice;

                 QuezonAve = lbl10TaftAve.Text;
                 fromQuezonAve = lbl_Buendia.Text;
                 TotalPrice = lblPrice.Text;

                 this.Hide();

                 lblTot GMA2 = new lblTot();
                 GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                 GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                 GMA2.TotalPrice(TotalPrice.ToString());
                 GMA2.ShowDialog();
             }
        }

        private void lbl_Buendia_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void rb10_AyalaAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb10_AyalaAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb10_Magallanes_CheckedChanged(object sender, EventArgs e)
        {
            if (rb10_Magallanes.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb10_TaftAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb10_TaftAve.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }
    }
}

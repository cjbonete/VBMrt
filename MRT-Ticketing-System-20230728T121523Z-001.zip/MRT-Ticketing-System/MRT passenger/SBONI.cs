﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SBONI : Form
    {
        public SBONI()
        {
            InitializeComponent();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb6_ShawBoulevard.Checked == true && lblPrice.Text != "0.00")
            {

                string BoniToShawBoulevard, fromBoniToShawBoulevard, TotalPrice;

                BoniToShawBoulevard = lbl6ShawBoulevard.Text;
                fromBoniToShawBoulevard = lbl_Boni.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBoniToShawBoulevard(BoniToShawBoulevard.ToString());
                TF.fromBoniToShawBoulevard2(fromBoniToShawBoulevard.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb6_Ortigas.Checked == true && lblPrice.Text != "0.00")
            {

                string BoniToOrtigas, fromBoniToOrtigas, TotalPrice;

                BoniToOrtigas = lbl6Ortigas.Text;
                fromBoniToOrtigas = lbl_Boni.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBoniToOrtigas(BoniToOrtigas.ToString());
                TF.fromBoniToOrtigas2(fromBoniToOrtigas.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb6_Santolan.Checked == true && lblPrice.Text != "0.00")
            {

                string BoniToSantolan, fromBoniToSantolan, TotalPrice;

                BoniToSantolan = lbl6Santolan.Text;
                fromBoniToSantolan = lbl_Boni.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBoniToSantolan(BoniToSantolan.ToString());
                TF.fromBoniToSantolan2(fromBoniToSantolan.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb6_AranetaCubao.Checked == true && lblPrice.Text != "0.00")
            {

                string BoniToAraneta, fromBoniToAraneta, TotalPrice;

                BoniToAraneta = lbl6AranetaCubao.Text;
                fromBoniToAraneta = lbl_Boni.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBoniToAraneta(BoniToAraneta.ToString());
                TF.fromBoniToAraneta2(fromBoniToAraneta.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb6_GMA.Checked == true && lblPrice.Text != "0.00")
            {

                string BoniToGMAKamuning, fromBoniToGMAKamuning, TotalPrice;

                BoniToGMAKamuning = lbl6GMAKAMUNING.Text;
                fromBoniToGMAKamuning = lbl_Boni.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBoniToGMAKamuning(BoniToGMAKamuning.ToString());
                TF.fromBoniToGMAKamuning2(fromBoniToGMAKamuning.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb6_QuezonAve.Checked == true && lblPrice.Text != "0.00")
            {

                string BoniToQuezonAve, fromBoniToQuezonAve, TotalPrice;

                BoniToQuezonAve = lbl6QuezonAve.Text;
                fromBoniToQuezonAve = lbl_Boni.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();

                TF.fromBoniToQuezonAve(BoniToQuezonAve.ToString());
                TF.fromBoniToQuezonAve2(fromBoniToQuezonAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();
            }

            else if (rb6_NorthAve.Checked == true && lblPrice.Text != "0.00")
            {

                string BoniToNorthAve, fromBoniToNorthAve, TotalPrice;

                BoniToNorthAve = lbl6NorthAve.Text;
                fromBoniToNorthAve = lbl_Boni.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromGuadaToNorthAve(BoniToNorthAve.ToString());
                TF.fromGuadaToNorthAve2(fromBoniToNorthAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            
        }

        private void Ortigas_Load(object sender, EventArgs e)
        {

        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void rb6_ShawBoulevard_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_ShawBoulevard.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb6_Ortigas_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_Ortigas.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb6_Santolan_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_Santolan.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb6_AranetaCubao_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_AranetaCubao.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb6_GMA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_GMA.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb6_QuezonAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_QuezonAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb6_NorthAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb6_NorthAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }
    }
}

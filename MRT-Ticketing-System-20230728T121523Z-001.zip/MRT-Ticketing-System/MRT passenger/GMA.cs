﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class GMA : Form
    {
        public GMA()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void GMA_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
           if (rb3_AranetaCubao.Checked == true && lblPrice.Text != "0.00")
            {
                string QuezonAve, fromQuezonAve, TotalPrice;

                QuezonAve =lbl3AranetaCubao.Text;
                fromQuezonAve = lbl_GMAKamuning.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();

                lblTot GMA2 = new lblTot();
                GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
                GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());
                GMA2.ShowDialog();
            }
           else if (rb3_Santolan.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl3Santolan.Text;
               fromQuezonAve = lbl_GMAKamuning.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }

           else if (rb3_Ortigas.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl3Ortigas.Text;
               fromQuezonAve = lbl_GMAKamuning.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb3_ShawBoulevard.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl3ShawBoulevard.Text;
               fromQuezonAve = lbl_GMAKamuning.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb3_BoniAve.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl3BoniAve.Text;
               fromQuezonAve = lbl_GMAKamuning.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb3_Guadalupe.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl3Guadalupe.Text;
               fromQuezonAve = lbl_GMAKamuning.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb3_Buendia.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl3Buendia.Text;
               fromQuezonAve = lbl_GMAKamuning.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb3_AyalaAve.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl3AyalaAve.Text;
               fromQuezonAve = lbl_GMAKamuning.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb3_Magallanes.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl3Magallanes.Text;
               fromQuezonAve = lbl_GMAKamuning.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
           else if (rb3_TaftAve.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl3TaftAve.Text;
               fromQuezonAve = lbl_GMAKamuning.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void rb3_AranetaCubao_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_AranetaCubao.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb3_Santolan_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_Santolan.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb3_Ortigas_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_Ortigas.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb3_ShawBoulevard_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_ShawBoulevard.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb3_BoniAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_BoniAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb3_Guadalupe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_Guadalupe.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb3_Buendia_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_Buendia.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb3_AyalaAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_AyalaAve.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb3_Magallanes_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_Magallanes.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb3_TaftAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb3_TaftAve.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }
    }
}

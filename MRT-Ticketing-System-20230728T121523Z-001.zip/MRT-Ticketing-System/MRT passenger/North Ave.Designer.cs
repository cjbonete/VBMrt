﻿namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    partial class North_Ave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label5;
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.rb_BoniAve = new System.Windows.Forms.RadioButton();
            this.lblTaftAve = new System.Windows.Forms.Label();
            this.lbl_NorthAve = new System.Windows.Forms.Label();
            this.lblShawBoulevard = new System.Windows.Forms.Label();
            this.rb_TaftAve = new System.Windows.Forms.RadioButton();
            this.rb_ShawBoulevard = new System.Windows.Forms.RadioButton();
            this.lblMagallanes = new System.Windows.Forms.Label();
            this.lblOrtigas = new System.Windows.Forms.Label();
            this.lblAyalaAve = new System.Windows.Forms.Label();
            this.rb_Ortigas = new System.Windows.Forms.RadioButton();
            this.rb_Magallanes = new System.Windows.Forms.RadioButton();
            this.lblSantolan = new System.Windows.Forms.Label();
            this.rb_AyalaAve = new System.Windows.Forms.RadioButton();
            this.rb_Santolan = new System.Windows.Forms.RadioButton();
            this.lblBuendia = new System.Windows.Forms.Label();
            this.lblAranetaCubao = new System.Windows.Forms.Label();
            this.lblGuadalupe = new System.Windows.Forms.Label();
            this.rb_AranetaCubao = new System.Windows.Forms.RadioButton();
            this.rb_Buendia = new System.Windows.Forms.RadioButton();
            this.lblQuezonAve = new System.Windows.Forms.Label();
            this.lblBoniAve = new System.Windows.Forms.Label();
            this.rb_Guadalupe = new System.Windows.Forms.RadioButton();
            this.lblGMAKAMUNING = new System.Windows.Forms.Label();
            this.rb_GMA = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.rb_QuezonAve = new System.Windows.Forms.RadioButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.lblPrice = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label2.Location = new System.Drawing.Point(556, 124);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(272, 24);
            label2.TabIndex = 1;
            label2.Text = "SELECT YOUR DESTINATION";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label3.Location = new System.Drawing.Point(678, 303);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(101, 24);
            label3.TabIndex = 3;
            label3.Text = "Ticket fare:";
            label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            label5.Location = new System.Drawing.Point(187, 273);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(178, 37);
            label5.TabIndex = 3;
            label5.Text = "STATIONS";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(label2);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(22, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1326, 155);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ITZeyyyyy_TRAIN_TICKET_SYSTEM.Properties.Resources.metro_station;
            this.pictureBox2.Location = new System.Drawing.Point(143, 34);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(193, 100);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(321, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(855, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "NORTH AVENUE STATION";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.rb_BoniAve);
            this.panel2.Controls.Add(this.lblTaftAve);
            this.panel2.Controls.Add(this.lblShawBoulevard);
            this.panel2.Controls.Add(this.rb_TaftAve);
            this.panel2.Controls.Add(this.rb_ShawBoulevard);
            this.panel2.Controls.Add(this.lblMagallanes);
            this.panel2.Controls.Add(this.lblOrtigas);
            this.panel2.Controls.Add(this.lblAyalaAve);
            this.panel2.Controls.Add(this.rb_Ortigas);
            this.panel2.Controls.Add(this.rb_Magallanes);
            this.panel2.Controls.Add(this.lblSantolan);
            this.panel2.Controls.Add(this.rb_AyalaAve);
            this.panel2.Controls.Add(this.rb_Santolan);
            this.panel2.Controls.Add(this.lblBuendia);
            this.panel2.Controls.Add(this.lblAranetaCubao);
            this.panel2.Controls.Add(this.lblGuadalupe);
            this.panel2.Controls.Add(this.rb_AranetaCubao);
            this.panel2.Controls.Add(this.rb_Buendia);
            this.panel2.Controls.Add(this.lblQuezonAve);
            this.panel2.Controls.Add(this.lblBoniAve);
            this.panel2.Controls.Add(this.rb_Guadalupe);
            this.panel2.Controls.Add(this.lblGMAKAMUNING);
            this.panel2.Controls.Add(this.rb_GMA);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.rb_QuezonAve);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.lbl_NorthAve);
            this.panel2.Location = new System.Drawing.Point(61, 303);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(440, 429);
            this.panel2.TabIndex = 2;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel5.Location = new System.Drawing.Point(304, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(136, 1);
            this.panel5.TabIndex = 12;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel3.Location = new System.Drawing.Point(439, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1, 400);
            this.panel3.TabIndex = 11;
            // 
            // rb_BoniAve
            // 
            this.rb_BoniAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_BoniAve.AutoSize = true;
            this.rb_BoniAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_BoniAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_BoniAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_BoniAve.ForeColor = System.Drawing.Color.White;
            this.rb_BoniAve.Location = new System.Drawing.Point(247, 39);
            this.rb_BoniAve.Name = "rb_BoniAve";
            this.rb_BoniAve.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.rb_BoniAve.Size = new System.Drawing.Size(156, 37);
            this.rb_BoniAve.TabIndex = 47;
            this.rb_BoniAve.TabStop = true;
            this.rb_BoniAve.Text = "Boni Ave.";
            this.rb_BoniAve.UseVisualStyleBackColor = false;
            this.rb_BoniAve.CheckedChanged += new System.EventHandler(this.rb_BoniAve_CheckedChanged);
            // 
            // lblTaftAve
            // 
            this.lblTaftAve.AutoSize = true;
            this.lblTaftAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblTaftAve.Location = new System.Drawing.Point(287, 350);
            this.lblTaftAve.Name = "lblTaftAve";
            this.lblTaftAve.Size = new System.Drawing.Size(81, 13);
            this.lblTaftAve.TabIndex = 46;
            this.lblTaftAve.Text = "TAFT AVENUE";
            // 
            // lbl_NorthAve
            // 
            this.lbl_NorthAve.AutoSize = true;
            this.lbl_NorthAve.Location = new System.Drawing.Point(270, 387);
            this.lbl_NorthAve.Name = "lbl_NorthAve";
            this.lbl_NorthAve.Size = new System.Drawing.Size(93, 13);
            this.lbl_NorthAve.TabIndex = 32;
            this.lbl_NorthAve.Text = "NORTH AVENUE";
            // 
            // lblShawBoulevard
            // 
            this.lblShawBoulevard.AutoSize = true;
            this.lblShawBoulevard.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblShawBoulevard.Location = new System.Drawing.Point(38, 348);
            this.lblShawBoulevard.Name = "lblShawBoulevard";
            this.lblShawBoulevard.Size = new System.Drawing.Size(109, 13);
            this.lblShawBoulevard.TabIndex = 40;
            this.lblShawBoulevard.Text = "SHAW BOULEVARD";
            // 
            // rb_TaftAve
            // 
            this.rb_TaftAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_TaftAve.AutoSize = true;
            this.rb_TaftAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_TaftAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_TaftAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_TaftAve.ForeColor = System.Drawing.Color.White;
            this.rb_TaftAve.Location = new System.Drawing.Point(247, 372);
            this.rb_TaftAve.Name = "rb_TaftAve";
            this.rb_TaftAve.Padding = new System.Windows.Forms.Padding(22, 0, 22, 0);
            this.rb_TaftAve.Size = new System.Drawing.Size(154, 37);
            this.rb_TaftAve.TabIndex = 45;
            this.rb_TaftAve.TabStop = true;
            this.rb_TaftAve.Text = "Taft Ave.";
            this.rb_TaftAve.UseVisualStyleBackColor = false;
            this.rb_TaftAve.CheckedChanged += new System.EventHandler(this.rb_TaftAve_CheckedChanged);
            // 
            // rb_ShawBoulevard
            // 
            this.rb_ShawBoulevard.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_ShawBoulevard.AutoSize = true;
            this.rb_ShawBoulevard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_ShawBoulevard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_ShawBoulevard.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_ShawBoulevard.Location = new System.Drawing.Point(18, 369);
            this.rb_ShawBoulevard.Name = "rb_ShawBoulevard";
            this.rb_ShawBoulevard.Padding = new System.Windows.Forms.Padding(20, 0, 20, 0);
            this.rb_ShawBoulevard.Size = new System.Drawing.Size(155, 36);
            this.rb_ShawBoulevard.TabIndex = 39;
            this.rb_ShawBoulevard.TabStop = true;
            this.rb_ShawBoulevard.Text = "Shaw Blvd.";
            this.rb_ShawBoulevard.UseVisualStyleBackColor = false;
            this.rb_ShawBoulevard.CheckedChanged += new System.EventHandler(this.rb_ShawBoulevard_CheckedChanged);
            // 
            // lblMagallanes
            // 
            this.lblMagallanes.AutoSize = true;
            this.lblMagallanes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblMagallanes.Location = new System.Drawing.Point(284, 286);
            this.lblMagallanes.Name = "lblMagallanes";
            this.lblMagallanes.Size = new System.Drawing.Size(79, 13);
            this.lblMagallanes.TabIndex = 34;
            this.lblMagallanes.Text = "MAGALLANES";
            // 
            // lblOrtigas
            // 
            this.lblOrtigas.AutoSize = true;
            this.lblOrtigas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblOrtigas.Location = new System.Drawing.Point(61, 286);
            this.lblOrtigas.Name = "lblOrtigas";
            this.lblOrtigas.Size = new System.Drawing.Size(55, 13);
            this.lblOrtigas.TabIndex = 38;
            this.lblOrtigas.Text = "ORTIGAS";
            // 
            // lblAyalaAve
            // 
            this.lblAyalaAve.AutoSize = true;
            this.lblAyalaAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblAyalaAve.Location = new System.Drawing.Point(276, 221);
            this.lblAyalaAve.Name = "lblAyalaAve";
            this.lblAyalaAve.Size = new System.Drawing.Size(88, 13);
            this.lblAyalaAve.TabIndex = 44;
            this.lblAyalaAve.Text = "AYALA AVENUE";
            // 
            // rb_Ortigas
            // 
            this.rb_Ortigas.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_Ortigas.AutoSize = true;
            this.rb_Ortigas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_Ortigas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_Ortigas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Ortigas.Location = new System.Drawing.Point(18, 305);
            this.rb_Ortigas.Name = "rb_Ortigas";
            this.rb_Ortigas.Padding = new System.Windows.Forms.Padding(37, 0, 37, 0);
            this.rb_Ortigas.Size = new System.Drawing.Size(155, 36);
            this.rb_Ortigas.TabIndex = 37;
            this.rb_Ortigas.TabStop = true;
            this.rb_Ortigas.Text = "Ortigas";
            this.rb_Ortigas.UseVisualStyleBackColor = false;
            this.rb_Ortigas.CheckedChanged += new System.EventHandler(this.rb_Ortigas_CheckedChanged);
            // 
            // rb_Magallanes
            // 
            this.rb_Magallanes.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_Magallanes.AutoSize = true;
            this.rb_Magallanes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_Magallanes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_Magallanes.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Magallanes.ForeColor = System.Drawing.Color.White;
            this.rb_Magallanes.Location = new System.Drawing.Point(247, 305);
            this.rb_Magallanes.Name = "rb_Magallanes";
            this.rb_Magallanes.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.rb_Magallanes.Size = new System.Drawing.Size(155, 37);
            this.rb_Magallanes.TabIndex = 33;
            this.rb_Magallanes.TabStop = true;
            this.rb_Magallanes.Text = "Magallanes";
            this.rb_Magallanes.UseVisualStyleBackColor = false;
            this.rb_Magallanes.CheckedChanged += new System.EventHandler(this.rb_Magallanes_CheckedChanged);
            // 
            // lblSantolan
            // 
            this.lblSantolan.AutoSize = true;
            this.lblSantolan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblSantolan.Location = new System.Drawing.Point(61, 221);
            this.lblSantolan.Name = "lblSantolan";
            this.lblSantolan.Size = new System.Drawing.Size(65, 13);
            this.lblSantolan.TabIndex = 36;
            this.lblSantolan.Text = "SANTOLAN";
            // 
            // rb_AyalaAve
            // 
            this.rb_AyalaAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_AyalaAve.AutoSize = true;
            this.rb_AyalaAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_AyalaAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_AyalaAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_AyalaAve.ForeColor = System.Drawing.Color.White;
            this.rb_AyalaAve.Location = new System.Drawing.Point(247, 241);
            this.rb_AyalaAve.Name = "rb_AyalaAve";
            this.rb_AyalaAve.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.rb_AyalaAve.Size = new System.Drawing.Size(157, 37);
            this.rb_AyalaAve.TabIndex = 43;
            this.rb_AyalaAve.TabStop = true;
            this.rb_AyalaAve.Text = "Ayala Ave.";
            this.rb_AyalaAve.UseVisualStyleBackColor = false;
            this.rb_AyalaAve.CheckedChanged += new System.EventHandler(this.rb_AyalaAve_CheckedChanged);
            // 
            // rb_Santolan
            // 
            this.rb_Santolan.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_Santolan.AutoSize = true;
            this.rb_Santolan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_Santolan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_Santolan.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Santolan.ForeColor = System.Drawing.Color.White;
            this.rb_Santolan.Location = new System.Drawing.Point(18, 241);
            this.rb_Santolan.Name = "rb_Santolan";
            this.rb_Santolan.Padding = new System.Windows.Forms.Padding(30, 0, 30, 0);
            this.rb_Santolan.Size = new System.Drawing.Size(155, 36);
            this.rb_Santolan.TabIndex = 35;
            this.rb_Santolan.TabStop = true;
            this.rb_Santolan.Text = "Santolan";
            this.rb_Santolan.UseVisualStyleBackColor = false;
            this.rb_Santolan.CheckedChanged += new System.EventHandler(this.rb_Santolan_CheckedChanged);
            // 
            // lblBuendia
            // 
            this.lblBuendia.AutoSize = true;
            this.lblBuendia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblBuendia.Location = new System.Drawing.Point(297, 154);
            this.lblBuendia.Name = "lblBuendia";
            this.lblBuendia.Size = new System.Drawing.Size(55, 13);
            this.lblBuendia.TabIndex = 34;
            this.lblBuendia.Text = "BUENDIA";
            // 
            // lblAranetaCubao
            // 
            this.lblAranetaCubao.AutoSize = true;
            this.lblAranetaCubao.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblAranetaCubao.Location = new System.Drawing.Point(49, 153);
            this.lblAranetaCubao.Name = "lblAranetaCubao";
            this.lblAranetaCubao.Size = new System.Drawing.Size(98, 13);
            this.lblAranetaCubao.TabIndex = 34;
            this.lblAranetaCubao.Text = "ARANETA CUBAO";
            // 
            // lblGuadalupe
            // 
            this.lblGuadalupe.AutoSize = true;
            this.lblGuadalupe.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblGuadalupe.Location = new System.Drawing.Point(297, 86);
            this.lblGuadalupe.Name = "lblGuadalupe";
            this.lblGuadalupe.Size = new System.Drawing.Size(73, 13);
            this.lblGuadalupe.TabIndex = 34;
            this.lblGuadalupe.Text = "GUADALUPE";
            // 
            // rb_AranetaCubao
            // 
            this.rb_AranetaCubao.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_AranetaCubao.AutoSize = true;
            this.rb_AranetaCubao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_AranetaCubao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_AranetaCubao.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_AranetaCubao.ForeColor = System.Drawing.Color.White;
            this.rb_AranetaCubao.Location = new System.Drawing.Point(18, 174);
            this.rb_AranetaCubao.Name = "rb_AranetaCubao";
            this.rb_AranetaCubao.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb_AranetaCubao.Size = new System.Drawing.Size(158, 36);
            this.rb_AranetaCubao.TabIndex = 33;
            this.rb_AranetaCubao.TabStop = true;
            this.rb_AranetaCubao.Text = "Araneta Cubao";
            this.rb_AranetaCubao.UseVisualStyleBackColor = false;
            this.rb_AranetaCubao.CheckedChanged += new System.EventHandler(this.rb_AranetaCubao_CheckedChanged);
            // 
            // rb_Buendia
            // 
            this.rb_Buendia.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_Buendia.AutoSize = true;
            this.rb_Buendia.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_Buendia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_Buendia.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Buendia.ForeColor = System.Drawing.Color.White;
            this.rb_Buendia.Location = new System.Drawing.Point(247, 174);
            this.rb_Buendia.Name = "rb_Buendia";
            this.rb_Buendia.Padding = new System.Windows.Forms.Padding(28, 0, 28, 0);
            this.rb_Buendia.Size = new System.Drawing.Size(159, 37);
            this.rb_Buendia.TabIndex = 33;
            this.rb_Buendia.TabStop = true;
            this.rb_Buendia.Text = "Buendia";
            this.rb_Buendia.UseVisualStyleBackColor = false;
            this.rb_Buendia.CheckedChanged += new System.EventHandler(this.rb_Buendia_CheckedChanged);
            // 
            // lblQuezonAve
            // 
            this.lblQuezonAve.AutoSize = true;
            this.lblQuezonAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblQuezonAve.Location = new System.Drawing.Point(43, 15);
            this.lblQuezonAve.Name = "lblQuezonAve";
            this.lblQuezonAve.Size = new System.Drawing.Size(100, 13);
            this.lblQuezonAve.TabIndex = 32;
            this.lblQuezonAve.Text = "QUEZON AVENUE";
            // 
            // lblBoniAve
            // 
            this.lblBoniAve.AutoSize = true;
            this.lblBoniAve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblBoniAve.Location = new System.Drawing.Point(272, 15);
            this.lblBoniAve.Name = "lblBoniAve";
            this.lblBoniAve.Size = new System.Drawing.Size(80, 13);
            this.lblBoniAve.TabIndex = 42;
            this.lblBoniAve.Text = "BONI AVENUE";
            // 
            // rb_Guadalupe
            // 
            this.rb_Guadalupe.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_Guadalupe.AutoSize = true;
            this.rb_Guadalupe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_Guadalupe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_Guadalupe.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Guadalupe.ForeColor = System.Drawing.Color.White;
            this.rb_Guadalupe.Location = new System.Drawing.Point(247, 109);
            this.rb_Guadalupe.Name = "rb_Guadalupe";
            this.rb_Guadalupe.Padding = new System.Windows.Forms.Padding(15, 0, 15, 0);
            this.rb_Guadalupe.Size = new System.Drawing.Size(159, 37);
            this.rb_Guadalupe.TabIndex = 33;
            this.rb_Guadalupe.TabStop = true;
            this.rb_Guadalupe.Text = "Guadalupe";
            this.rb_Guadalupe.UseVisualStyleBackColor = false;
            this.rb_Guadalupe.CheckedChanged += new System.EventHandler(this.rb_Guadalupe_CheckedChanged);
            // 
            // lblGMAKAMUNING
            // 
            this.lblGMAKAMUNING.AutoSize = true;
            this.lblGMAKAMUNING.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblGMAKAMUNING.Location = new System.Drawing.Point(50, 87);
            this.lblGMAKAMUNING.Name = "lblGMAKAMUNING";
            this.lblGMAKAMUNING.Size = new System.Drawing.Size(92, 13);
            this.lblGMAKAMUNING.TabIndex = 31;
            this.lblGMAKAMUNING.Text = "GMA KAMUNING";
            // 
            // rb_GMA
            // 
            this.rb_GMA.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_GMA.AutoSize = true;
            this.rb_GMA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_GMA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_GMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_GMA.ForeColor = System.Drawing.Color.White;
            this.rb_GMA.Location = new System.Drawing.Point(18, 109);
            this.rb_GMA.Name = "rb_GMA";
            this.rb_GMA.Size = new System.Drawing.Size(156, 36);
            this.rb_GMA.TabIndex = 12;
            this.rb_GMA.TabStop = true;
            this.rb_GMA.Text = "GMA Kamuning";
            this.rb_GMA.UseVisualStyleBackColor = false;
            this.rb_GMA.CheckedChanged += new System.EventHandler(this.rb_GMA_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 400);
            this.panel4.TabIndex = 10;
            // 
            // rb_QuezonAve
            // 
            this.rb_QuezonAve.Appearance = System.Windows.Forms.Appearance.Button;
            this.rb_QuezonAve.AutoSize = true;
            this.rb_QuezonAve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.rb_QuezonAve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rb_QuezonAve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_QuezonAve.ForeColor = System.Drawing.Color.White;
            this.rb_QuezonAve.Location = new System.Drawing.Point(18, 39);
            this.rb_QuezonAve.Name = "rb_QuezonAve";
            this.rb_QuezonAve.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.rb_QuezonAve.Size = new System.Drawing.Size(158, 37);
            this.rb_QuezonAve.TabIndex = 10;
            this.rb_QuezonAve.TabStop = true;
            this.rb_QuezonAve.Text = "Quezon Ave.";
            this.rb_QuezonAve.UseVisualStyleBackColor = false;
            this.rb_QuezonAve.CheckedChanged += new System.EventHandler(this.rb_QuezonAve_CheckedChanged);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(188)))), ((int)(((byte)(148)))));
            this.panel6.Location = new System.Drawing.Point(3, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(136, 1);
            this.panel6.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(838, 397);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 42);
            this.label4.TabIndex = 8;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.SystemColors.Window;
            this.button14.Location = new System.Drawing.Point(1117, 589);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(140, 33);
            this.button14.TabIndex = 9;
            this.button14.Text = "CASH";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.lblPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(634, 439);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(248, 111);
            this.lblPrice.TabIndex = 30;
            this.lblPrice.Text = "0.00";
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(682, 666);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(140, 33);
            this.button13.TabIndex = 7;
            this.button13.Text = "BACK";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Window;
            this.button1.Location = new System.Drawing.Point(1117, 666);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 33);
            this.button1.TabIndex = 31;
            this.button1.Text = "CARD";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // North_Ave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1370, 723);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(label5);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.label4);
            this.Controls.Add(label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "North_Ave";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "xfdxds";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.North_Ave_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.RadioButton rb_QuezonAve;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.RadioButton rb_GMA;
        private System.Windows.Forms.Label lblGMAKAMUNING;
        private System.Windows.Forms.Label lbl_NorthAve;
        private System.Windows.Forms.Label lblQuezonAve;
        private System.Windows.Forms.Label lblShawBoulevard;
        private System.Windows.Forms.RadioButton rb_ShawBoulevard;
        private System.Windows.Forms.Label lblOrtigas;
        private System.Windows.Forms.RadioButton rb_Ortigas;
        private System.Windows.Forms.Label lblSantolan;
        private System.Windows.Forms.RadioButton rb_Santolan;
        private System.Windows.Forms.Label lblAranetaCubao;
        private System.Windows.Forms.RadioButton rb_AranetaCubao;
        private System.Windows.Forms.Label lblTaftAve;
        private System.Windows.Forms.RadioButton rb_TaftAve;
        private System.Windows.Forms.Label lblMagallanes;
        private System.Windows.Forms.Label lblAyalaAve;
        private System.Windows.Forms.RadioButton rb_Magallanes;
        private System.Windows.Forms.RadioButton rb_AyalaAve;
        private System.Windows.Forms.Label lblBuendia;
        private System.Windows.Forms.Label lblGuadalupe;
        private System.Windows.Forms.RadioButton rb_Buendia;
        private System.Windows.Forms.Label lblBoniAve;
        private System.Windows.Forms.RadioButton rb_Guadalupe;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.RadioButton rb_BoniAve;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button1;
    }
}
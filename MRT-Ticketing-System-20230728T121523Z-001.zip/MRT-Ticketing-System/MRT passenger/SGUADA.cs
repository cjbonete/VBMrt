﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SGUADA : Form
    {
        public SGUADA()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb5_BoniAve.Checked == true && lblPrice.Text != "0.00")
            {

                string GuadaToBoniAve, fromGuadaToBoniAve, TotalPrice;

                GuadaToBoniAve = lbl5BoniAve.Text;
                fromGuadaToBoniAve = lbl_Guadalupe.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromGuadaToBoniAve(GuadaToBoniAve.ToString());
                TF.fromGuadaToBoniAve2(fromGuadaToBoniAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb5_ShawBoulevard.Checked == true && lblPrice.Text != "0.00")
            {

                string GuadaToShawBoulevard, fromGuadaToShawBoulevard, TotalPrice;

                GuadaToShawBoulevard = lbl5ShawBoulevard.Text;
                fromGuadaToShawBoulevard = lbl_Guadalupe.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromGuadaToShawBoulevard(GuadaToShawBoulevard.ToString());
                TF.fromGuadaToShawBoulevard2(fromGuadaToShawBoulevard.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb5_Ortigas.Checked == true && lblPrice.Text != "0.00")
            {

                string GuadaToOrtigas, fromGuadaToOrtigas, TotalPrice;

                GuadaToOrtigas = lbl5Ortigas.Text;
                fromGuadaToOrtigas = lbl_Guadalupe.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromGuadaToOrtigas(GuadaToOrtigas.ToString());
                TF.fromGuadaToOrtigas2(fromGuadaToOrtigas.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb5_Santolan.Checked == true && lblPrice.Text != "0.00")
            {

                string GuadaToSantolan, fromGuadaToSantolan, TotalPrice;

                GuadaToSantolan = lbl5Santolan.Text;
                fromGuadaToSantolan = lbl_Guadalupe.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromBuendiaToSantolan(GuadaToSantolan.ToString());
                TF.fromBuendiaToSantolan2(fromGuadaToSantolan.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb5_AranetaCubao.Checked == true && lblPrice.Text != "0.00")
            {

                string GuadaToAraneta, fromGuadaToAraneta, TotalPrice;

                GuadaToAraneta = lbl5AranetaCubao.Text;
                fromGuadaToAraneta = lbl_Guadalupe.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromGuadaToAraneta(GuadaToAraneta.ToString());
                TF.fromGuadaToAraneta2(fromGuadaToAraneta.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb5_GMA.Checked == true && lblPrice.Text != "0.00")
            {

                string GuadaToGMAKamuning, fromGuadaToGMAKamuning, TotalPrice;

                GuadaToGMAKamuning = lbl5GMAKAMUNING.Text;
                fromGuadaToGMAKamuning = lbl_Guadalupe.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromGuadaToGMAKamuning(GuadaToGMAKamuning.ToString());
                TF.fromGuadaToGMAKamuning2(fromGuadaToGMAKamuning.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb5_QuezonAve.Checked == true && lblPrice.Text != "0.00")
            {

                string GuadaToQuezonAve, fromGuadaToQuezonAve, TotalPrice;

                GuadaToQuezonAve = lbl5QuezonAve.Text;
                fromGuadaToQuezonAve = lbl_Guadalupe.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();

                TF.fromGuadaToQuezonAve(GuadaToQuezonAve.ToString());
                TF.fromGuadaToQuezonAve2(fromGuadaToQuezonAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();
            }

            else if (rb5_NorthAve.Checked == true && lblPrice.Text != "0.00")
            {

                string GuadaToNorthAve, fromGuadaToNorthAve, TotalPrice;

                GuadaToNorthAve = lbl5NorthAve.Text;
                fromGuadaToNorthAve = lbl_Guadalupe.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromGuadaToNorthAve(GuadaToNorthAve.ToString());
                TF.fromGuadaToNorthAve2(fromGuadaToNorthAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            
        }

        private void Santolan_Load(object sender, EventArgs e)
        {

        }

        private void button13_Click_1(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void rb5_BoniAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_BoniAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb5_ShawBoulevard_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_ShawBoulevard.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb5_Ortigas_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_Ortigas.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb5_Santolan_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_Santolan.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb5_AranetaCubao_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_AranetaCubao.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb5_GMA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_GMA.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb5_QuezonAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_QuezonAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb5_NorthAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb5_NorthAve.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }
    }
}

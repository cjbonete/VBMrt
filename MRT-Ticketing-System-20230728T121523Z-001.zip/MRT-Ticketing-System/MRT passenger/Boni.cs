﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Boni : Form
    {
        public Boni()
        {
            InitializeComponent();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
          if (rb8_Guadalupe.Checked == true && lblPrice.Text != "0.00")
           {
               string QuezonAve, fromQuezonAve, TotalPrice;

               QuezonAve = lbl8Guadalupe.Text;
               fromQuezonAve = lbl_BoniAve.Text;
               TotalPrice = lblPrice.Text;

               this.Hide();

               lblTot GMA2 = new lblTot();
               GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
               GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
               GMA2.TotalPrice(TotalPrice.ToString());
               GMA2.ShowDialog();
           }
          else if (rb8_Buendia.Checked == true && lblPrice.Text != "0.00")
          {
              string QuezonAve, fromQuezonAve, TotalPrice;

              QuezonAve = lbl8Buendia.Text;
              fromQuezonAve = lbl_BoniAve.Text;
              TotalPrice = lblPrice.Text;

              this.Hide();

              lblTot GMA2 = new lblTot();
              GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
              GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
              GMA2.TotalPrice(TotalPrice.ToString());
              GMA2.ShowDialog();
          }
          else if (rb8_AyalaAve.Checked == true && lblPrice.Text != "0.00")
          {
              string QuezonAve, fromQuezonAve, TotalPrice;

              QuezonAve = lbl8AyalaAve.Text;
              fromQuezonAve = lbl_BoniAve.Text;
              TotalPrice = lblPrice.Text;

              this.Hide();

              lblTot GMA2 = new lblTot();
              GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
              GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
              GMA2.TotalPrice(TotalPrice.ToString());
              GMA2.ShowDialog();
          }
          else if (rb8_Magallanes.Checked == true && lblPrice.Text != "0.00")
          {
              string QuezonAve, fromQuezonAve, TotalPrice;

              QuezonAve = lbl8Magallanes.Text;
              fromQuezonAve = lbl_BoniAve.Text;
              TotalPrice = lblPrice.Text;

              this.Hide();

              lblTot GMA2 = new lblTot();
              GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
              GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
              GMA2.TotalPrice(TotalPrice.ToString());
              GMA2.ShowDialog();
          }
          else if (rb8_TaftAve.Checked == true && lblPrice.Text != "0.00")
          {
              string QuezonAve, fromQuezonAve, TotalPrice;

              QuezonAve = lbl8TaftAve.Text;
              fromQuezonAve = lbl_BoniAve.Text;
              TotalPrice = lblPrice.Text;

              this.Hide();

              lblTot GMA2 = new lblTot();
              GMA2.fromQuezonAveToGMAKamuning(QuezonAve.ToString());
              GMA2.fromQuezonAveToGMAKamuning2(fromQuezonAve.ToString());
              GMA2.TotalPrice(TotalPrice.ToString());
              GMA2.ShowDialog();
          }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void rb8_Guadalupe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb8_Guadalupe.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb8_Buendia_CheckedChanged(object sender, EventArgs e)
        {
            if (rb8_Buendia.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb8_AyalaAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb8_AyalaAve.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb8_Magallanes_CheckedChanged(object sender, EventArgs e)
        {
            if (rb8_Magallanes.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb8_TaftAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb8_TaftAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }
    }
}

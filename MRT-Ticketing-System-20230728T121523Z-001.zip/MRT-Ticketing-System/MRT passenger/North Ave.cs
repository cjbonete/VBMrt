﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class North_Ave : Form
    {



        public North_Ave()
        {
            InitializeComponent();
        }

        private void North_Ave_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {

            if (rb_QuezonAve.Checked == true && lblPrice.Text !="0.00") {

                string NorthAveToQuezonAve, fromNorthAveToQuezonAve, TotalPrice;

                NorthAveToQuezonAve = lblQuezonAve.Text;
                fromNorthAveToQuezonAve = lbl_NorthAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();

                GMA2.fromNorthAveToQuezonAve(NorthAveToQuezonAve.ToString());
                GMA2.fromNorthAveToQuezonAve2(fromNorthAveToQuezonAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();
            }

            else if (rb_GMA.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToGMAKamuning, fromNorthAveToGMAKamuning, TotalPrice;

                NorthAveToGMAKamuning = lblGMAKAMUNING.Text;
                fromNorthAveToGMAKamuning = lbl_NorthAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToGMAKamuning(NorthAveToGMAKamuning.ToString());
                GMA2.fromNorthAveToGMAKamuning2(fromNorthAveToGMAKamuning.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }

            else if (rb_AranetaCubao.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToAraneta, fromNorthAveToAraneta, TotalPrice;

                NorthAveToAraneta = lblAranetaCubao.Text;
                fromNorthAveToAraneta = lbl_NorthAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToAranetaCubao(NorthAveToAraneta.ToString());
                GMA2.fromNorthAveToAranetaCubao2(fromNorthAveToAraneta.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }

            else if (rb_Santolan.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToSantolan, fromNorthAveToSantolan, TotalPrice;

                NorthAveToSantolan = lblSantolan.Text;
                fromNorthAveToSantolan = lbl_NorthAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToSantolan(NorthAveToSantolan.ToString());
                GMA2.fromNorthAveToSantolan2(fromNorthAveToSantolan.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
            else if (rb_Ortigas.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToOrtigas, fromNorthAveToOrtigas, TotalPrice;

                NorthAveToOrtigas = lblOrtigas.Text;
                fromNorthAveToOrtigas = lbl_NorthAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToOrtigas(NorthAveToOrtigas.ToString());
                GMA2.fromNorthAveToOrtigas2(fromNorthAveToOrtigas.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
              else if (rb_ShawBoulevard.Checked== true && lblPrice.Text != "0.00")
            {

                string NorthAveToShawBoulevard, fromNorthAveToShawBoulevard, TotalPrice;

                NorthAveToShawBoulevard = lblShawBoulevard.Text;
                fromNorthAveToShawBoulevard = lbl_NorthAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToShawBoulevard(NorthAveToShawBoulevard.ToString());
                GMA2.fromNorthAveToShawBoulevard2(fromNorthAveToShawBoulevard.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
            else if (rb_BoniAve.Checked== true && lblPrice.Text != "0.00")
            {

                string NorthAveToBoniAve, fromNorthAveToBoniAve, TotalPrice;

                NorthAveToBoniAve = lblBoniAve.Text;
                fromNorthAveToBoniAve = lbl_NorthAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToBoniAve(NorthAveToBoniAve.ToString());
                GMA2.fromNorthAveToBoniAve2(fromNorthAveToBoniAve.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
            else if (rb_Guadalupe.Checked== true && lblPrice.Text != "0.00")
            {

                string NorthAveToGuadalupe, fromNorthAveToGuadalupe, TotalPrice;

                NorthAveToGuadalupe = lblGuadalupe.Text;
                fromNorthAveToGuadalupe = lbl_NorthAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToGuadalupe(NorthAveToGuadalupe.ToString());
                GMA2.fromNorthAveToGuadalupe2(fromNorthAveToGuadalupe.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
            else if (rb_Buendia.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToBuendia, fromNorthAveToBuendia, TotalPrice;

                NorthAveToBuendia = lblBuendia.Text;
                fromNorthAveToBuendia = lbl_NorthAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToBuendia(NorthAveToBuendia.ToString());
                GMA2.fromNorthAveToBuendia2(fromNorthAveToBuendia.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
            else if (rb_AyalaAve.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToBuendia, fromNorthAveToBuendia, TotalPrice;

                NorthAveToBuendia = lblAyalaAve.Text;
                fromNorthAveToBuendia = lbl_NorthAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToBuendia(NorthAveToBuendia.ToString());
                GMA2.fromNorthAveToBuendia2(fromNorthAveToBuendia.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }

            else if (rb_Magallanes.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToBuendia, fromNorthAveToBuendia, TotalPrice;

                NorthAveToBuendia = lblMagallanes.Text;
                fromNorthAveToBuendia = lbl_NorthAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToBuendia(NorthAveToBuendia.ToString());
                GMA2.fromNorthAveToBuendia2(fromNorthAveToBuendia.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }
            else if (rb_TaftAve.Checked == true && lblPrice.Text != "0.00")
            {

                string NorthAveToBuendia, fromNorthAveToBuendia, TotalPrice;

                NorthAveToBuendia = lblTaftAve.Text;
                fromNorthAveToBuendia = lbl_NorthAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTot GMA2 = new lblTot();
                GMA2.fromNorthAveToBuendia(NorthAveToBuendia.ToString());
                GMA2.fromNorthAveToBuendia2(fromNorthAveToBuendia.ToString());
                GMA2.TotalPrice(TotalPrice.ToString());

                GMA2.ShowDialog();

            }

         
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form1 frm1 = new Form1();

            frm1.ShowDialog();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void rb_QuezonAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_QuezonAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb_BoniAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_BoniAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb_GMA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_GMA.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb_Guadalupe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_Guadalupe.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb_AranetaCubao_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_AranetaCubao.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb_Buendia_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_Buendia.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb_Santolan_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_Santolan.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb_AyalaAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_AyalaAve.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb_Ortigas_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_Ortigas.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb_Magallanes_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_Magallanes.Checked == true)
            {
                lblPrice.Text = "28.00";
            }
        }

        private void rb_ShawBoulevard_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_ShawBoulevard.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb_TaftAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_TaftAve.Checked == true)
            {
                lblPrice.Text = "28.00";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}

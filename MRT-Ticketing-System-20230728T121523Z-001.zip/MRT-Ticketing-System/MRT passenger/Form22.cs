﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class Form22 : Form
    {
        public Form22()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void SELECT_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMRT7_SJ SJ = new SMRT7_SJ();

            SJ.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMRT7_TL TL = new SMRT7_TL();

            TL.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMRT7_SH SH = new SMRT7_SH();

            SH.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMRT7_QR QR = new SMRT7_QR();

            QR.ShowDialog();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMRT7_MA MA = new SMRT7_MA();

            MA.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMRT7_RG RG = new SMRT7_RG();

            RG.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMRT7_DC DC = new SMRT7_DC();

            DC.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMRT7_MG MG = new SMRT7_MG();

            MG.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMRT7_BT BT = new SMRT7_BT();

            BT.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
             this.Hide();

            SMRT7_DA DA = new SMRT7_DA();

            DA.ShowDialog();
        }

        private void button13_Click(object sender, EventArgs e)
        {

            this.Hide();

            SMRT7_TS TS = new SMRT7_TS();

            TS.ShowDialog();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMRT7_UA UA = new SMRT7_UA();

            UA.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMRT7_QC QC = new SMRT7_QC();

            QC.ShowDialog();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            this.Hide();

            SMRT7_NA NA = new SMRT7_NA();

            NA.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            about_us Au = new about_us();

            Au.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

            guide gd = new guide();

            gd.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();

            SCONTACT CU = new SCONTACT();

            CU.ShowDialog();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            Main2 home = new Main2();

            home.ShowDialog();
        }
    }
}
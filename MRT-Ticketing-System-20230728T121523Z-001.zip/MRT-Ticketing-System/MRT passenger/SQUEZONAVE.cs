﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class SQUEZONAVE : Form
    {
        public SQUEZONAVE()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb12_NorthAve.Checked == true && lblPrice.Text != "0.00")
            {

                string QuezonAveToNorthAve, fromQuezonAveToNorthAve, TotalPrice;

                QuezonAveToNorthAve = lbl12NorthAve.Text;
                fromQuezonAveToNorthAve = lbl_QuezonAvenue.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromQuezonAveToNorthAve(QuezonAveToNorthAve.ToString());
                TF.fromQuezonAveToNorthAve2(fromQuezonAveToNorthAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }
        }

        private void button13_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void rb12_NorthAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb12_NorthAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }
    }
}

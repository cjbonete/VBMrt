﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ITZeyyyyy_TRAIN_TICKET_SYSTEM
{
    public partial class STAFT : Form
    {



        public STAFT()
        {
            InitializeComponent();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (rb_Magallanes.Checked == true && lblPrice.Text != "0.00")
            {

                string TaftToMagallanes, fromTaftToMagallanes, TotalPrice;

                TaftToMagallanes = lblMagallanes.Text;
                fromTaftToMagallanes = lbl_TaftAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromTaftToMagallanes(TaftToMagallanes.ToString());
                TF.fromTaftToMagallanes2(fromTaftToMagallanes.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb_AyalaAve.Checked == true && lblPrice.Text != "0.00")
            {

                string TaftToAyala, fromTaftToAyala, TotalPrice;
                TaftToAyala = lblAyalaAve.Text;
                fromTaftToAyala = lbl_TaftAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromTaftToAyala(TaftToAyala.ToString());
                TF.fromTaftToAyala2(fromTaftToAyala.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb_Buendia.Checked == true && lblPrice.Text != "0.00")
            {

                string TaftToBuendia, fromTaftToBuendia, TotalPrice;

                TaftToBuendia = lblBuendia.Text;
                fromTaftToBuendia = lbl_TaftAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromTaftToBuendia(TaftToBuendia.ToString());
                TF.fromTaftToBuendia2(fromTaftToBuendia.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb_Guadalupe.Checked == true && lblPrice.Text != "0.00")
            {

                string TaftToGuadalupe, fromTaftToGuadalupe, TotalPrice;

                TaftToGuadalupe = lblGuadalupe.Text;
                fromTaftToGuadalupe = lbl_TaftAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromTaftToGuadalupe(TaftToGuadalupe.ToString());
                TF.fromTaftToGuadalupe2(fromTaftToGuadalupe.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb_BoniAve.Checked == true && lblPrice.Text != "0.00")
            {

                string TaftToBoniAve, fromTaftToBoniAve, TotalPrice;

                TaftToBoniAve = lblBoniAve.Text;
                fromTaftToBoniAve = lbl_TaftAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromTaftToBoniAve(TaftToBoniAve.ToString());
                TF.fromTaftToBoniAve2(fromTaftToBoniAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb_ShawBoulevard.Checked == true && lblPrice.Text != "0.00")
            {

                string TaftToShawBoulevard, fromTaftToShawBoulevard, TotalPrice;

                TaftToShawBoulevard = lblShawBoulevard.Text;
                fromTaftToShawBoulevard = lbl_TaftAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromTaftToShawBoulevard(TaftToShawBoulevard.ToString());
                TF.fromTaftToShawBoulevard2(fromTaftToShawBoulevard.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb_Ortigas.Checked == true && lblPrice.Text != "0.00")
            {

                string TaftToOrtigas, fromTaftToOrtigas, TotalPrice;

                TaftToOrtigas = lblOrtigas.Text;
                fromTaftToOrtigas = lbl_TaftAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromTaftToOrtigas(TaftToOrtigas.ToString());
                TF.fromTaftToOrtigas2(fromTaftToOrtigas.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb_Santolan.Checked == true && lblPrice.Text != "0.00")
            {

                string TaftToSantolan, fromTaftToSantolan, TotalPrice;

                TaftToSantolan = lblSantolan.Text;
                fromTaftToSantolan = lbl_TaftAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromTaftToSantolan(TaftToSantolan.ToString());
                TF.fromTaftToSantolan2(fromTaftToSantolan.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb_AranetaCubao.Checked == true && lblPrice.Text != "0.00")
            {

                string TaftToAraneta, fromTaftToAraneta, TotalPrice;

                TaftToAraneta = lblAranetaCubao.Text;
                fromTaftToAraneta = lbl_TaftAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromTaftToAraneta(TaftToAraneta.ToString());
                TF.fromTaftToAraneta2(fromTaftToAraneta.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb_GMA.Checked == true && lblPrice.Text != "0.00")
            {

                string TaftToGMAKamuning, fromTaftToGMAKamuning, TotalPrice;

                TaftToGMAKamuning = lblGMAKAMUNING.Text;
                fromTaftToGMAKamuning = lbl_TaftAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromTaftToGMAKamuning(TaftToGMAKamuning.ToString());
                TF.fromTaftToGMAKamuning2(fromTaftToGMAKamuning.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

            else if (rb_QuezonAve.Checked == true && lblPrice.Text !="0.00") {

                string TaftToQuezonAve, fromTaftToQuezonAve, TotalPrice;

                TaftToQuezonAve = lblQuezonAve.Text;
                fromTaftToQuezonAve = lbl_TaftAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();

                TF.fromTaftToQuezonAve(TaftToQuezonAve.ToString());
                TF.fromTaftToQuezonAve2(fromTaftToQuezonAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();
            }

            else if (rb_NorthAve.Checked == true && lblPrice.Text != "0.00")
            {

                string TaftToNorthAve, fromTaftToNorthAve, TotalPrice;

                TaftToNorthAve = lblNorthAve.Text;
                fromTaftToNorthAve = lbl_TaftAve.Text;
                TotalPrice = lblPrice.Text;

                this.Hide();
                lblTotal TF = new lblTotal();
                TF.fromTaftToNorthAve(TaftToNorthAve.ToString());
                TF.fromTaftToNorthAve2(fromTaftToNorthAve.ToString());
                TF.TotalPrice(TotalPrice.ToString());

                TF.ShowDialog();

            }

         
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        private void rb_Magallanes_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_Magallanes.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb_AyalaAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_AyalaAve.Checked == true)
            {
                lblPrice.Text = "13.00";
            }
        }

        private void rb_Buendia_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_Buendia.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb_Guadalupe_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_Guadalupe.Checked == true)
            {
                lblPrice.Text = "16.00";
            }
        }

        private void rb_BoniAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_BoniAve.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb_ShawBoulevard_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_ShawBoulevard.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb_Ortigas_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_Ortigas.Checked == true)
            {
                lblPrice.Text = "20.00";
            }
        }

        private void rb_Santolan_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_Santolan.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb_AranetaCubao_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_AranetaCubao.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb_GMA_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_GMA.Checked == true)
            {
                lblPrice.Text = "24.00";
            }
        }

        private void rb_QuezonAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_QuezonAve.Checked == true)
            {
                lblPrice.Text = "28.00";
            }
        }

        private void rb_NorthAve_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_NorthAve.Checked == true)
            {
                lblPrice.Text = "28.00";
            }
        }

        private void lblMagallanes_Click(object sender, EventArgs e)
        {

        }
    }
}
